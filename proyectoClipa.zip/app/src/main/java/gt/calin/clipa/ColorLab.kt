package gt.calin.clipa

import android.graphics.Bitmap

/** Filtros de color tipo "preset". Cada uno es una transformación de color en código. */
enum class Filter(val label: String) {
    NONE("Original"),
    VIVID("Vívido"),
    WARM("Cálido"),
    COOL("Frío"),
    CINE("Cine"),
    VINTAGE("Vintage"),
    SEPIA("Sepia"),
    BW("B/N"),
    NOIR("Noir"),
    FADED("Desvanecido"),
    GOLDEN("Dorado"),
    NEON("Neón"),
    PASTEL("Pastel"),
    DRAMA("Drama"),
    FOREST("Bosque"),
    ROSE("Rosa"),
    TEAL("Teal"),
    SUNSET("Atardecer"),
}

/** Efectos de video. Algunos se animan con el tiempo, otros son capas encima del video. */
enum class Fx(val label: String) {
    NONE("Ninguno"),
    PULSE("Latido"),
    BREATH("Respiro"),
    SHAKE("Vibración"),
    FLASH("Destello"),
    DISCO("Disco"),
    GLITCH("Glitch"),
    BLUR("Desenfoque"),
    VHS("VHS"),
    GRAIN("Grano"),
    BARS("Cine 2.35"),
    LEAK("Luz"),
    FRAME("Marco"),
}

/** Todo el "look" de un clip: color, ajustes, efecto y orientación. */
data class Look(
    val filter: Filter = Filter.NONE,
    val filterAmount: Float = 1f,
    val brightness: Float = 0f,
    val contrast: Float = 0f,
    val saturation: Float = 0f,
    val warmth: Float = 0f,
    val tint: Float = 0f,
    val fade: Float = 0f,
    val vignette: Float = 0f,
    val fx: Fx = Fx.NONE,
    val fxAmount: Float = 0.6f,
    val rotation: Int = 0,
    val mirror: Boolean = false,
    /** true = llenar el cuadro recortando; false = ajustar con barras negras. */
    val fill: Boolean = false,
) {
    val hasColor: Boolean
        get() = filter != Filter.NONE || brightness != 0f || contrast != 0f ||
            saturation != 0f || warmth != 0f || tint != 0f || fade != 0f

    /** Mismo look de color pero sin efecto ni orientación (para miniaturas de filtros). */
    fun colorOnly(): Look = copy(fx = Fx.NONE, rotation = 0, mirror = false, vignette = 0f)
}

private fun clamp01(v: Float): Float = if (v < 0f) 0f else if (v > 1f) 1f else v

private fun lumaOf(c: FloatArray): Float = 0.2126f * c[0] + 0.7152f * c[1] + 0.0722f * c[2]

private fun saturate(c: FloatArray, s: Float) {
    val l = lumaOf(c)
    c[0] = l + (c[0] - l) * s
    c[1] = l + (c[1] - l) * s
    c[2] = l + (c[2] - l) * s
}

private fun contrastBy(c: FloatArray, k: Float) {
    c[0] = (c[0] - 0.5f) * k + 0.5f
    c[1] = (c[1] - 0.5f) * k + 0.5f
    c[2] = (c[2] - 0.5f) * k + 0.5f
}

private fun addAll(c: FloatArray, v: Float) {
    c[0] += v
    c[1] += v
    c[2] += v
}

private fun gains(c: FloatArray, r: Float, g: Float, b: Float) {
    c[0] *= r
    c[1] *= g
    c[2] *= b
}

private fun clampAll(c: FloatArray) {
    c[0] = clamp01(c[0])
    c[1] = clamp01(c[1])
    c[2] = clamp01(c[2])
}

private fun toGray(c: FloatArray) {
    val l = lumaOf(c)
    c[0] = l
    c[1] = l
    c[2] = l
}

/** Aplica un filtro sobre un color (valores de 0 a 1), en el mismo arreglo. */
private fun applyFilter(f: Filter, c: FloatArray) {
    when (f) {
        Filter.NONE -> {}
        Filter.VIVID -> {
            saturate(c, 1.35f)
            clampAll(c)
            contrastBy(c, 1.12f)
        }
        Filter.WARM -> {
            gains(c, 1.08f, 1.0f, 0.9f)
            addAll(c, 0.015f)
            saturate(c, 1.05f)
        }
        Filter.COOL -> {
            gains(c, 0.9f, 1.0f, 1.1f)
            c[2] += 0.02f
        }
        Filter.CINE -> {
            val l = lumaOf(c)
            c[0] += (l - 0.5f) * 0.16f
            c[2] -= (l - 0.5f) * 0.16f
            c[1] += (0.5f - l) * 0.03f
            clampAll(c)
            saturate(c, 1.1f)
            contrastBy(c, 1.1f)
        }
        Filter.VINTAGE -> {
            contrastBy(c, 0.9f)
            addAll(c, 0.05f)
            gains(c, 1.06f, 0.98f, 0.86f)
            saturate(c, 0.8f)
        }
        Filter.SEPIA -> {
            val r = c[0]
            val g = c[1]
            val b = c[2]
            c[0] = 0.393f * r + 0.769f * g + 0.189f * b
            c[1] = 0.349f * r + 0.686f * g + 0.168f * b
            c[2] = 0.272f * r + 0.534f * g + 0.131f * b
        }
        Filter.BW -> toGray(c)
        Filter.NOIR -> {
            toGray(c)
            contrastBy(c, 1.5f)
            addAll(c, -0.04f)
        }
        Filter.FADED -> {
            saturate(c, 0.85f)
            contrastBy(c, 0.88f)
            addAll(c, 0.09f)
        }
        Filter.GOLDEN -> {
            gains(c, 1.12f, 1.03f, 0.8f)
            addAll(c, 0.03f)
            saturate(c, 1.1f)
        }
        Filter.NEON -> {
            saturate(c, 1.5f)
            clampAll(c)
            contrastBy(c, 1.2f)
            val l = lumaOf(c)
            c[2] += (1f - l) * 0.12f
            c[0] += (1f - l) * 0.06f
        }
        Filter.PASTEL -> {
            saturate(c, 0.7f)
            contrastBy(c, 0.85f)
            addAll(c, 0.1f)
        }
        Filter.DRAMA -> {
            contrastBy(c, 1.35f)
            saturate(c, 0.85f)
            clampAll(c)
            c[0] = Math.pow(c[0].toDouble(), 1.15).toFloat()
            c[1] = Math.pow(c[1].toDouble(), 1.15).toFloat()
            c[2] = Math.pow(c[2].toDouble(), 1.15).toFloat()
        }
        Filter.FOREST -> {
            gains(c, 0.92f, 1.08f, 0.95f)
            saturate(c, 1.1f)
        }
        Filter.ROSE -> {
            gains(c, 1.08f, 0.95f, 1.03f)
            addAll(c, 0.03f)
            saturate(c, 1.05f)
        }
        Filter.TEAL -> {
            gains(c, 0.85f, 1.0f, 1.1f)
            saturate(c, 1.1f)
        }
        Filter.SUNSET -> {
            gains(c, 1.15f, 0.98f, 0.8f)
            contrastBy(c, 1.1f)
        }
    }
    clampAll(c)
}

/** Aplica el look de color (filtro + ajustes) a un color. Reutiliza arreglos, sin crear basura. */
class ColorPipeline(private val look: Look) {
    private val tmp = FloatArray(3)

    fun apply(c: FloatArray) {
        var r = c[0]
        var g = c[1]
        var b = c[2]

        if (look.filter != Filter.NONE) {
            tmp[0] = r
            tmp[1] = g
            tmp[2] = b
            applyFilter(look.filter, tmp)
            val a = look.filterAmount
            r += (tmp[0] - r) * a
            g += (tmp[1] - g) * a
            b += (tmp[2] - b) * a
        }
        if (look.fade != 0f) {
            val f = look.fade
            r = r * (1f - f * 0.25f) + f * 0.1f
            g = g * (1f - f * 0.25f) + f * 0.1f
            b = b * (1f - f * 0.25f) + f * 0.1f
        }
        if (look.warmth != 0f) {
            r += look.warmth * 0.08f
            b -= look.warmth * 0.08f
        }
        if (look.tint != 0f) {
            g -= look.tint * 0.06f
            r += look.tint * 0.02f
            b += look.tint * 0.02f
        }
        if (look.brightness != 0f) {
            val d = look.brightness * 0.25f
            r += d
            g += d
            b += d
        }
        c[0] = r
        c[1] = g
        c[2] = b
        if (look.contrast != 0f) contrastBy(c, 1f + look.contrast * 0.7f)
        if (look.saturation != 0f) {
            clampAll(c)
            saturate(c, 1f + look.saturation)
        }
        clampAll(c)
    }
}

private fun to255(v: Float): Int = (v * 255f + 0.5f).toInt().coerceIn(0, 255)

object ColorLab {

    /** Cubo 3D de color para SingleColorLut. Devuelve null si el look no cambia el color. */
    fun buildCube(look: Look, size: Int = 33): Array<Array<IntArray>>? {
        if (!look.hasColor) return null
        val p = ColorPipeline(look)
        val cube = Array(size) { Array(size) { IntArray(size) } }
        val rgb = FloatArray(3)
        val inv = 1f / (size - 1)
        for (r in 0 until size) {
            for (g in 0 until size) {
                for (b in 0 until size) {
                    rgb[0] = r * inv
                    rgb[1] = g * inv
                    rgb[2] = b * inv
                    p.apply(rgb)
                    cube[r][g][b] = (0xFF shl 24) or (to255(rgb[0]) shl 16) or
                        (to255(rgb[1]) shl 8) or to255(rgb[2])
                }
            }
        }
        return cube
    }

    /** Aplica el look de color a una imagen (para miniaturas de filtros). */
    fun applyToBitmap(src: Bitmap, look: Look): Bitmap {
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        val p = ColorPipeline(look)
        val rgb = FloatArray(3)
        for (i in px.indices) {
            val c = px[i]
            rgb[0] = ((c shr 16) and 255) / 255f
            rgb[1] = ((c shr 8) and 255) / 255f
            rgb[2] = (c and 255) / 255f
            p.apply(rgb)
            px[i] = (c and 0xFF000000.toInt()) or (to255(rgb[0]) shl 16) or
                (to255(rgb[1]) shl 8) or to255(rgb[2])
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(px, 0, w, 0, 0, w, h)
        return out
    }
}
