package gt.calin.clipa

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Clic sin onda visual (para controles que ya tienen su propio estado). */
fun Modifier.tap(enabled: Boolean = true, onClick: () -> Unit): Modifier = composed {
    clickable(
        interactionSource = remember { MutableInteractionSource() },
        indication = null,
        enabled = enabled,
        onClick = onClick,
    )
}

@Composable
fun ToolButton(
    ic: Ic,
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    active: Boolean = false,
    tint: Color = Pal.Text,
    pro: Boolean = false,
) {
    Column(
        modifier
            .tap(onClick = onClick)
            .padding(horizontal = 6.dp, vertical = 6.dp)
            .width(60.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(contentAlignment = Alignment.TopEnd) {
            Box(
                Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (active) Pal.Accent.copy(alpha = 0.18f) else Color.Transparent),
                contentAlignment = Alignment.Center,
            ) {
                Glyph(ic, if (active) Pal.Accent else tint, size = 24.dp)
            }
            if (pro) {
                Box(
                    Modifier
                        .size(14.dp)
                        .clip(CircleShape)
                        .background(Pal.GoldBrush),
                    contentAlignment = Alignment.Center,
                ) {
                    Glyph(Ic.Crown, Color.Black, size = 9.dp)
                }
            }
        }
        Spacer(Modifier.height(2.dp))
        Text(
            label,
            color = if (active) Pal.Accent else Pal.Muted,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
            textAlign = TextAlign.Center,
        )
    }
}

@Composable
fun IconBtn(
    ic: Ic,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    tint: Color = Pal.Text,
    enabled: Boolean = true,
    box: Dp = 40.dp,
    glyph: Dp = 22.dp,
    bg: Color = Color.Transparent,
) {
    Box(
        modifier
            .size(box)
            .clip(CircleShape)
            .background(bg)
            .alpha(if (enabled) 1f else 0.3f)
            .tap(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Glyph(ic, tint, size = glyph)
    }
}

@Composable
fun ProBadge(modifier: Modifier = Modifier) {
    Row(
        modifier
            .clip(RoundedCornerShape(6.dp))
            .background(Pal.GoldBrush)
            .padding(horizontal = 5.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Glyph(Ic.Crown, Color.Black, size = 10.dp)
        Spacer(Modifier.width(2.dp))
        Text("PRO", color = Color.Black, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold)
    }
}

@Composable
fun Chip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    pro: Boolean = false,
) {
    Row(
        modifier
            .clip(RoundedCornerShape(50))
            .background(if (selected) Pal.Accent else Pal.Surface3)
            .tap(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            label,
            color = if (selected) Color.Black else Pal.Text,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
        )
        if (pro) {
            Spacer(Modifier.width(5.dp))
            Glyph(Ic.Crown, if (selected) Color.Black else Pal.Gold, size = 12.dp)
        }
    }
}

@Composable
fun GradientButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    brush: Brush = Pal.Brand,
    textColor: Color = Color.Black,
    height: Dp = 44.dp,
    ic: Ic? = null,
) {
    Row(
        modifier
            .height(height)
            .clip(RoundedCornerShape(50))
            .background(brush)
            .alpha(if (enabled) 1f else 0.4f)
            .tap(enabled = enabled, onClick = onClick)
            .padding(horizontal = 20.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (ic != null) {
            Glyph(ic, textColor, size = 18.dp)
            Spacer(Modifier.width(7.dp))
        }
        Text(text, color = textColor, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

/** Panel inferior con título y botón de listo. */
@Composable
fun PanelFrame(
    title: String,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit,
) {
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
            .background(Pal.Surface2)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = 18.dp, end = 6.dp, top = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                title,
                color = Pal.Text,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f),
            )
            IconBtn(Ic.Check, onClick = onClose, tint = Pal.Accent, box = 44.dp)
        }
        content()
    }
}

/** Control deslizante propio: más fino y claro que el de Material. */
@Composable
fun ClipaSlider(
    value: Float,
    onChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
    range: ClosedFloatingPointRange<Float> = 0f..1f,
    centerZero: Boolean = false,
) {
    val cb by rememberUpdatedState(onChange)
    val lo = range.start
    val hi = range.endInclusive
    Canvas(
        modifier
            .fillMaxWidth()
            .height(32.dp)
            .pointerInput(lo, hi) {
                detectTapGestures { pos ->
                    val pad = 12.dp.toPx()
                    val f = ((pos.x - pad) / (size.width - 2 * pad)).coerceIn(0f, 1f)
                    cb(lo + f * (hi - lo))
                }
            }
            .pointerInput(lo, hi) {
                detectDragGestures { change, _ ->
                    change.consume()
                    val pad = 12.dp.toPx()
                    val f = ((change.position.x - pad) / (size.width - 2 * pad)).coerceIn(0f, 1f)
                    cb(lo + f * (hi - lo))
                }
            }
    ) {
        val pad = 12.dp.toPx()
        val w = size.width - 2 * pad
        val cy = size.height / 2f
        val f = ((value - lo) / (hi - lo)).coerceIn(0f, 1f)
        val x = pad + f * w
        drawLine(Pal.Surface3, Offset(pad, cy), Offset(pad + w, cy), strokeWidth = 4.dp.toPx(), cap = StrokeCap.Round)
        val x0 = if (centerZero) pad + w / 2f else pad
        drawLine(Pal.Accent, Offset(x0, cy), Offset(x, cy), strokeWidth = 4.dp.toPx(), cap = StrokeCap.Round)
        if (centerZero) {
            drawLine(Pal.Muted, Offset(pad + w / 2f, cy - 6.dp.toPx()), Offset(pad + w / 2f, cy + 6.dp.toPx()), strokeWidth = 1.5.dp.toPx())
        }
        drawCircle(Color.White, 9.dp.toPx(), Offset(x, cy))
        drawCircle(Pal.Accent, 4.dp.toPx(), Offset(x, cy))
    }
}

/** Fila: etiqueta, valor y deslizador. */
@Composable
fun LabeledSlider(
    label: String,
    value: Float,
    onChange: (Float) -> Unit,
    valueText: String,
    modifier: Modifier = Modifier,
    range: ClosedFloatingPointRange<Float> = 0f..1f,
    centerZero: Boolean = false,
) {
    Column(modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = Pal.Muted, fontSize = 12.sp, modifier = Modifier.weight(1f))
            Text(valueText, color = Pal.Text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
        ClipaSlider(value, onChange, range = range, centerZero = centerZero)
    }
}

/** Marco de selección para tiles. */
fun Modifier.selectBorder(selected: Boolean, shape: androidx.compose.ui.graphics.Shape): Modifier =
    if (selected) this.border(2.dp, Pal.Accent, shape) else this.border(1.dp, Pal.Line, shape)
