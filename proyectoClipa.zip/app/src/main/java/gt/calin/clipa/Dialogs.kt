package gt.calin.clipa

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

@Composable
private fun DialogCard(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(26.dp))
            .background(Pal.Surface2)
            .border(1.dp, Pal.Line, RoundedCornerShape(26.dp))
            .padding(22.dp)
    ) {
        content()
    }
}

@Composable
fun ExportDialog(
    project: Project,
    isPro: Boolean,
    onDismiss: () -> Unit,
    onStart: (ExportQuality) -> Unit,
    onPaywall: () -> Unit,
) {
    var q by remember { mutableStateOf(ExportQuality.P1080) }
    val totalSec = project.totalMs / 1000.0

    Dialog(onDismissRequest = onDismiss) {
        DialogCard {
            Text("Exportar video", color = Pal.Text, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
            Text(
                "${project.aspect.label}  ·  ${formatTime(project.totalMs)}",
                color = Pal.Muted,
                fontSize = 13.sp,
            )
            Spacer(Modifier.height(14.dp))

            for (opt in ExportQuality.entries) {
                val (w, h) = project.aspect.sizeFor(opt.shortSide)
                val mb = ((opt.bitrate + 128_000) * totalSec / 8.0 / 1_000_000.0)
                val selected = q == opt
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (selected) Pal.Accent.copy(alpha = 0.12f) else Pal.Surface3)
                        .border(
                            if (selected) 2.dp else 1.dp,
                            if (selected) Pal.Accent else Pal.Line,
                            RoundedCornerShape(16.dp),
                        )
                        .tap { q = opt }
                        .padding(horizontal = 14.dp, vertical = 11.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(
                        Modifier
                            .size(20.dp)
                            .clip(CircleShape)
                            .border(2.dp, if (selected) Pal.Accent else Pal.Muted, CircleShape)
                            .padding(4.dp)
                            .background(if (selected) Pal.Accent else Color.Transparent, CircleShape)
                    )
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(opt.label, color = Pal.Text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                            if (opt.pro) {
                                Spacer(Modifier.width(6.dp))
                                ProBadge()
                            }
                        }
                        Text("$w×$h  ·  ${opt.note}", color = Pal.Muted, fontSize = 11.sp)
                    }
                    Text(
                        "≈ " + (if (mb < 10) "%.1f".format(mb) else "%.0f".format(mb)) + " MB",
                        color = Pal.Muted,
                        fontSize = 12.sp,
                    )
                }
            }

            if (q.hevc) {
                Spacer(Modifier.height(8.dp))
                Text(
                    "Los videos 2K/4K tardan más y calientan el teléfono. Si tu cel no soporta " +
                        "esa resolución, Clipa exportará en la más alta que acepte.",
                    color = Pal.Muted,
                    fontSize = 12.sp,
                )
            }
            Spacer(Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onDismiss) { Text("Cancelar", color = Pal.Muted) }
                Spacer(Modifier.weight(1f))
                val locked = q.pro && !isPro
                GradientButton(
                    if (locked) "Desbloquear PRO" else "Exportar",
                    onClick = { if (locked) onPaywall() else onStart(q) },
                    brush = if (locked) Pal.GoldBrush else Pal.Brand,
                    ic = if (locked) Ic.Crown else Ic.Export,
                )
            }
        }
    }
}

@Composable
fun ExportProgressDialog(progress: Int, onCancel: () -> Unit) {
    Dialog(
        onDismissRequest = {},
        properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false),
    ) {
        DialogCard {
            Text("Exportando…", color = Pal.Text, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(18.dp))
            Text(
                "${progress.coerceIn(0, 100)}%",
                color = Pal.Accent,
                fontSize = 40.sp,
                fontWeight = FontWeight.ExtraBold,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(12.dp))
            LinearProgressIndicator(
                progress = { progress.coerceIn(0, 100) / 100f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(50)),
                color = Pal.Accent,
                trackColor = Pal.Surface3,
            )
            Spacer(Modifier.height(12.dp))
            Text(
                "Mantén la app abierta y la pantalla encendida mientras exporta.",
                color = Pal.Muted,
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(8.dp))
            TextButton(onClick = onCancel, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                Text("Cancelar", color = Pal.Danger)
            }
        }
    }
}

@Composable
fun ExportDoneDialog(state: ExportState.Done, onClose: () -> Unit) {
    val ctx = LocalContext.current
    Dialog(onDismissRequest = onClose) {
        DialogCard {
            Box(
                Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(Pal.Brand)
                    .align(Alignment.CenterHorizontally),
                contentAlignment = Alignment.Center,
            ) {
                Glyph(Ic.Check, Color.Black, size = 30.dp)
            }
            Spacer(Modifier.height(14.dp))
            Text(
                "¡Video guardado!",
                color = Pal.Text,
                fontSize = 20.sp,
                fontWeight = FontWeight.ExtraBold,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(4.dp))
            val res = if (state.widthPx > 0) "${state.widthPx}×${state.heightPx}  ·  " else ""
            Text(
                res + "Galería › Movies › Clipa",
                color = Pal.Muted,
                fontSize = 13.sp,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(18.dp))
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                GradientButton(
                    "Ver", onClick = { openVideo(ctx, state.uri) },
                    modifier = Modifier.weight(1f), ic = Ic.Play,
                )
                GradientButton(
                    "Compartir", onClick = { shareVideo(ctx, state.uri) },
                    modifier = Modifier.weight(1f), ic = Ic.Share,
                )
            }
            TextButton(onClick = onClose, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                Text("Listo", color = Pal.Muted)
            }
        }
    }
}

@Composable
fun ExportErrorDialog(message: String, onClose: () -> Unit) {
    Dialog(onDismissRequest = onClose) {
        DialogCard {
            Text("No se pudo exportar", color = Pal.Danger, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(10.dp))
            Text(message, color = Pal.Text, fontSize = 14.sp)
            Spacer(Modifier.height(14.dp))
            TextButton(onClick = onClose, modifier = Modifier.align(Alignment.End)) {
                Text("Entendido", color = Pal.Accent)
            }
        }
    }
}

@Composable
fun PaywallDialog(onDismiss: () -> Unit, onActivate: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        DialogCard {
            Box(
                Modifier
                    .size(60.dp)
                    .clip(CircleShape)
                    .background(Pal.GoldBrush)
                    .align(Alignment.CenterHorizontally),
                contentAlignment = Alignment.Center,
            ) {
                Glyph(Ic.Crown, Color.Black, size = 32.dp)
            }
            Spacer(Modifier.height(12.dp))
            Text(
                "Clipa PRO",
                color = Pal.Text,
                fontSize = 24.sp,
                fontWeight = FontWeight.ExtraBold,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(14.dp))
            val perks = listOf(
                "Exporta en 2K y 4K Ultra HD",
                "Filtros y efectos premium",
                "Música y sonidos exclusivos",
                "Estilos de texto premium",
            )
            for (p in perks) {
                Row(Modifier.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Glyph(Ic.Check, Pal.Accent, size = 20.dp)
                    Spacer(Modifier.width(10.dp))
                    Text(p, color = Pal.Text, fontSize = 14.sp)
                }
            }
            Spacer(Modifier.height(12.dp))
            Text(
                "Los pagos con Google Play (mensual, anual con 7 días gratis y de por vida) se " +
                    "activarán cuando la app se publique. Mientras tanto puedes probar PRO gratis.",
                color = Pal.Muted,
                fontSize = 12.sp,
            )
            Spacer(Modifier.height(16.dp))
            GradientButton(
                "Probar PRO ahora",
                onClick = onActivate,
                brush = Pal.GoldBrush,
                modifier = Modifier.fillMaxWidth(),
                ic = Ic.Crown,
            )
            TextButton(onClick = onDismiss, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                Text("Ahora no", color = Pal.Muted)
            }
        }
    }
}

@Composable
fun ConfirmDialog(
    title: String,
    message: String,
    confirm: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
) {
    Dialog(onDismissRequest = onDismiss) {
        DialogCard {
            Text(title, color = Pal.Text, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(8.dp))
            Text(message, color = Pal.Muted, fontSize = 14.sp)
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = onDismiss) { Text("Cancelar", color = Pal.Muted) }
                TextButton(onClick = onConfirm) { Text(confirm, color = Pal.Danger) }
            }
        }
    }
}

private fun openVideo(ctx: Context, uri: Uri) {
    try {
        ctx.startActivity(
            Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, "video/mp4")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        )
    } catch (e: Exception) {
        Toast.makeText(ctx, "No encontré una app para abrir el video", Toast.LENGTH_SHORT).show()
    }
}

private fun shareVideo(ctx: Context, uri: Uri) {
    try {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "video/mp4"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(send, "Compartir video"))
    } catch (e: Exception) {
        Toast.makeText(ctx, "No pude compartir el video", Toast.LENGTH_SHORT).show()
    }
}
