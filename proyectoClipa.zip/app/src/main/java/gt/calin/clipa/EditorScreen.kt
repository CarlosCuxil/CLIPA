@file:OptIn(ExperimentalMaterial3Api::class, UnstableApi::class)

package gt.calin.clipa

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlin.math.roundToInt

private val Bg = Color(0xFF0E0F13)
private val Panel = Color(0xFF181A20)
private val Panel2 = Color(0xFF262932)
private val Accent = Color(0xFF8B7CFF)
private val Pink = Color(0xFFFF5C93)
private val Mint = Color(0xFF2FBF86)
private val Muted = Color(0xFF9AA0AE)

private val TextColors = listOf(
    0xFFFFFFFF.toInt(),
    0xFFFFE066.toInt(),
    0xFF66E0FF.toInt(),
    0xFFFF7AB6.toInt(),
    0xFF7CFFB2.toInt(),
    0xFF000000.toInt(),
)

private enum class Tool { None, Trim, Text, Music }

@Composable
fun ClipaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            onPrimary = Color.White,
            background = Bg,
            onBackground = Color.White,
            surface = Panel,
            onSurface = Color.White,
            surfaceVariant = Panel2,
            onSurfaceVariant = Muted,
        ),
        content = content,
    )
}

@Composable
fun EditorScreen(vm: EditorViewModel) {
    val ctx = LocalContext.current
    val view = LocalView.current
    val exporting = vm.export is ExportState.Running
    SideEffect { view.keepScreenOn = exporting }

    var tool by rememberSaveable { mutableStateOf(Tool.None) }
    var showExportPicker by remember { mutableStateOf(false) }
    var textDialogOpen by remember { mutableStateOf(false) }
    var editingText by remember { mutableStateOf<TextItem?>(null) }

    val pickVideos = rememberLauncherForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(30)
    ) { uris -> if (uris.isNotEmpty()) vm.addVideos(uris) }

    val pickMusic = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> if (uri != null) vm.setMusic(uri) }

    val addVideo: () -> Unit = {
        pickVideos.launch(
            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
        )
    }
    val chooseMusic: () -> Unit = { pickMusic.launch(arrayOf("audio/*")) }

    val openAddText: () -> Unit = {
        if (vm.totalMs <= 0L) {
            Toast.makeText(ctx, "Primero agrega un video", Toast.LENGTH_SHORT).show()
        } else {
            editingText = null
            textDialogOpen = true
        }
    }
    val openEditText: (TextItem) -> Unit = { t ->
        editingText = t
        textDialogOpen = true
    }

    val hasClips = vm.clips.isNotEmpty()
    val hasSel = vm.selectedClip != null

    Column(
        Modifier
            .fillMaxSize()
            .background(Bg)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        TopBar(vm, onExport = { showExportPicker = true })

        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 12.dp),
            contentAlignment = Alignment.Center,
        ) {
            if (!hasClips) {
                EmptyState(onAdd = addVideo)
            } else {
                PreviewArea(vm, onEditText = openEditText)
            }
        }

        TransportBar(vm)
        TimelineView(vm, onEditText = openEditText)

        when (tool) {
            Tool.Trim -> TrimPanel(vm)
            Tool.Text -> TextPanel(vm, onAdd = openAddText, onEdit = openEditText)
            Tool.Music -> MusicPanel(vm, onPick = chooseMusic)
            Tool.None -> {}
        }

        Row(
            Modifier
                .fillMaxWidth()
                .background(Panel)
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 4.dp)
        ) {
            ToolButton("＋", "Video", true, false) { addVideo() }
            ToolButton("✂", "Dividir", hasClips, false) { vm.splitAtPlayhead() }
            ToolButton("✕", "Borrar", hasSel, false) { vm.deleteSelected() }
            ToolButton("◀", "Mover", hasSel, false) { vm.moveSelected(-1) }
            ToolButton("▶", "Mover", hasSel, false) { vm.moveSelected(1) }
            ToolButton("⟷", "Recortar", hasSel, tool == Tool.Trim) {
                tool = if (tool == Tool.Trim) Tool.None else Tool.Trim
            }
            ToolButton("T", "Texto", hasClips, tool == Tool.Text) {
                tool = if (tool == Tool.Text) Tool.None else Tool.Text
            }
            ToolButton("♪", "Música", hasClips, tool == Tool.Music) {
                tool = if (tool == Tool.Music) Tool.None else Tool.Music
            }
            ToolButton(if (vm.muteOriginal) "🔇" else "🔊", "Original", hasClips, false) {
                vm.toggleMuteOriginal()
            }
        }
    }

    if (textDialogOpen) {
        val ed = editingText
        val deleteAction: (() -> Unit)? = if (ed == null) {
            null
        } else {
            val action: () -> Unit = {
                vm.removeText(ed.id)
                textDialogOpen = false
                editingText = null
            }
            action
        }
        TextDialog(
            initial = ed,
            total = vm.totalMs,
            defaultStart = vm.positionMs,
            onDismiss = {
                textDialogOpen = false
                editingText = null
            },
            onConfirm = { txt, col, sz, s, e ->
                if (ed == null) vm.addText(txt, col, sz, s, e) else vm.updateText(ed.id, txt, col, sz, s, e)
                textDialogOpen = false
                editingText = null
            },
            onDelete = deleteAction,
        )
    }

    if (showExportPicker) {
        ExportPickerDialog(
            aspect = vm.aspect,
            onDismiss = { showExportPicker = false },
            onStart = { q ->
                showExportPicker = false
                vm.startExport(q)
            },
        )
    }

    when (val st = vm.export) {
        is ExportState.Running -> ExportProgressDialog(st.progress, onCancel = { vm.cancelExport() })
        is ExportState.Done -> AlertDialog(
            onDismissRequest = { vm.dismissExport() },
            title = { Text("¡Listo!") },
            text = { Text("Tu video quedó guardado en la galería, carpeta Películas/Clipa.") },
            confirmButton = {
                Row {
                    TextButton(onClick = { openVideo(ctx, st.uri) }) { Text("Ver") }
                    TextButton(onClick = { shareVideo(ctx, st.uri) }) { Text("Compartir") }
                }
            },
            dismissButton = { TextButton(onClick = { vm.dismissExport() }) { Text("Cerrar") } },
        )
        is ExportState.Error -> AlertDialog(
            onDismissRequest = { vm.dismissExport() },
            title = { Text("No se pudo exportar") },
            text = { Text(st.message) },
            confirmButton = { TextButton(onClick = { vm.dismissExport() }) { Text("Entendido") } },
        )
        ExportState.Idle -> {}
    }
}

// ---------------------------------------------------------------------------------------------
// Barra superior, vacío, vista previa
// ---------------------------------------------------------------------------------------------

@Composable
private fun TopBar(vm: EditorViewModel, onExport: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("Clipa", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Color.White)
        Spacer(Modifier.width(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Aspect.entries.forEach { a ->
                Chip(a.label, vm.aspect == a) { vm.changeAspect(a) }
            }
        }
        Spacer(Modifier.weight(1f))
        Button(onClick = onExport, enabled = vm.clips.isNotEmpty()) { Text("Exportar") }
    }
}

@Composable
private fun Chip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(if (selected) Accent else Panel2)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 5.dp)
    ) {
        Text(label, fontSize = 12.sp, color = Color.White)
    }
}

@Composable
private fun EmptyState(onAdd: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Empieza tu proyecto", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Spacer(Modifier.height(6.dp))
        Text("Elige uno o varios videos de tu galería", color = Muted, fontSize = 14.sp)
        Spacer(Modifier.height(16.dp))
        Button(onClick = onAdd) { Text("＋ Agregar videos") }
    }
}

@Composable
private fun PreviewArea(vm: EditorViewModel, onEditText: (TextItem) -> Unit) {
    BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        val ratio = vm.aspect.ratio
        var w = maxWidth
        var h = w / ratio
        if (h > maxHeight) {
            h = maxHeight
            w = h * ratio
        }
        val density = LocalDensity.current
        val wPx = with(density) { w.toPx() }
        val hPx = with(density) { h.toPx() }

        Box(
            Modifier
                .size(w, h)
                .clip(RoundedCornerShape(8.dp))
                .background(Color.Black)
        ) {
            AndroidView(
                factory = { c ->
                    PlayerView(c).apply {
                        player = vm.player
                        useController = false
                        resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                        setShutterBackgroundColor(android.graphics.Color.BLACK)
                    }
                },
                modifier = Modifier.fillMaxSize(),
            )

            val pos = vm.positionMs
            vm.texts.filter { pos >= it.startMs && pos < it.endMs }.forEach { t ->
                key(t.id) {
                    PreviewText(
                        t = t,
                        wPx = wPx,
                        hPx = hPx,
                        onDrag = { dx, dy -> vm.moveText(t.id, dx, dy) },
                        onEdit = { onEditText(t) },
                    )
                }
            }
        }
    }
}

@Composable
private fun PreviewText(
    t: TextItem,
    wPx: Float,
    hPx: Float,
    onDrag: (Float, Float) -> Unit,
    onEdit: () -> Unit,
) {
    val density = LocalDensity.current
    var boxSize by remember { mutableStateOf(IntSize.Zero) }
    val sizePx = t.sizeFrac * hPx

    Box(
        Modifier
            .offset {
                IntOffset(
                    (t.x * wPx - boxSize.width / 2f).roundToInt(),
                    (t.y * hPx - boxSize.height / 2f).roundToInt(),
                )
            }
            .onSizeChanged { boxSize = it }
            .pointerInput(t.id, wPx, hPx) {
                detectDragGestures { change, drag ->
                    change.consume()
                    onDrag(drag.x / wPx, drag.y / hPx)
                }
            }
            .pointerInput(t.id) {
                detectTapGestures(onDoubleTap = { onEdit() })
            }
    ) {
        Text(
            text = t.text,
            color = Color(t.color),
            fontSize = with(density) { sizePx.toSp() },
            fontWeight = FontWeight.Bold,
            softWrap = false,
            overflow = TextOverflow.Visible,
            textAlign = TextAlign.Center,
            style = TextStyle(shadow = Shadow(Color.Black, Offset(0f, sizePx * 0.04f), sizePx * 0.08f)),
        )
    }
}

// ---------------------------------------------------------------------------------------------
// Transporte y línea de tiempo
// ---------------------------------------------------------------------------------------------

@Composable
private fun TransportBar(vm: EditorViewModel) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(if (vm.clips.isEmpty()) Panel2 else Accent)
                .clickable(enabled = vm.clips.isNotEmpty()) { vm.togglePlay() },
            contentAlignment = Alignment.Center,
        ) {
            Text(if (vm.playing) "❚❚" else "▶", color = Color.White, fontSize = 15.sp)
        }
        Spacer(Modifier.width(10.dp))
        Text(
            "${formatTime(vm.positionMs)} / ${formatTime(vm.totalMs)}",
            color = Muted,
            fontSize = 13.sp,
        )
        Slider(
            value = vm.positionMs.toFloat(),
            onValueChange = { vm.seekTo(it.toLong()) },
            valueRange = 0f..maxOf(vm.totalMs, 1L).toFloat(),
            enabled = vm.clips.isNotEmpty(),
            modifier = Modifier
                .weight(1f)
                .padding(start = 8.dp),
        )
    }
}

@Composable
private fun TimelineView(vm: EditorViewModel, onEditText: (TextItem) -> Unit) {
    val total = maxOf(vm.totalMs, 1L).toFloat()

    BoxWithConstraints(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .height(96.dp)
    ) {
        val tw = maxWidth

        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            // Pista de video
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Panel)
            ) {
                vm.clips.forEachIndexed { i, c ->
                    val sel = c.id == vm.selectedClipId
                    Box(
                        Modifier
                            .weight(maxOf(c.lengthMs, 1L).toFloat())
                            .fillMaxHeight()
                            .padding(1.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (sel) Accent else Panel2)
                            .clickable { vm.selectClip(c.id) },
                        contentAlignment = Alignment.Center,
                    ) {
                        Text("${i + 1}", fontSize = 11.sp, color = Color.White, maxLines = 1)
                    }
                }
            }

            // Pista de texto
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(20.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Panel)
            ) {
                vm.texts.forEach { t ->
                    Box(
                        Modifier
                            .offset(x = tw * (t.startMs / total))
                            .width(tw * ((t.endMs - t.startMs) / total))
                            .fillMaxHeight()
                            .padding(1.dp)
                            .clip(RoundedCornerShape(5.dp))
                            .background(Pink)
                            .clickable { onEditText(t) },
                        contentAlignment = Alignment.CenterStart,
                    ) {
                        Text(
                            t.text,
                            fontSize = 10.sp,
                            color = Color.White,
                            maxLines = 1,
                            modifier = Modifier.padding(horizontal = 4.dp),
                        )
                    }
                }
            }

            // Pista de música
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(20.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Panel)
            ) {
                val m = vm.music
                if (m != null) {
                    Box(
                        Modifier
                            .width(tw * minOf(1f, m.durationMs / total))
                            .fillMaxHeight()
                            .padding(1.dp)
                            .clip(RoundedCornerShape(5.dp))
                            .background(Mint),
                        contentAlignment = Alignment.CenterStart,
                    ) {
                        Text(
                            "♪ ${m.name}",
                            fontSize = 10.sp,
                            color = Color.White,
                            maxLines = 1,
                            modifier = Modifier.padding(horizontal = 4.dp),
                        )
                    }
                }
            }
        }

        // Cabezal
        Box(
            Modifier
                .offset(x = tw * (vm.positionMs / total) - 1.dp)
                .width(2.dp)
                .fillMaxHeight()
                .background(Color.White)
        )
    }
}

// ---------------------------------------------------------------------------------------------
// Paneles de herramientas
// ---------------------------------------------------------------------------------------------

@Composable
private fun Hint(text: String) {
    Text(text, color = Muted, fontSize = 13.sp)
}

@Composable
private fun TrimPanel(vm: EditorViewModel) {
    val c = vm.selectedClip
    Column(
        Modifier
            .fillMaxWidth()
            .background(Panel)
            .padding(12.dp)
    ) {
        if (c == null) {
            Hint("Selecciona un clip en la línea de tiempo")
        } else {
            var range by remember(c.id, c.startMs, c.endMs) {
                mutableStateOf(c.startMs.toFloat()..c.endMs.toFloat())
            }
            val seconds = (range.endInclusive - range.start) / 1000f
            Text(
                "Recortar: ${formatTimeTenths(range.start.toLong())} – " +
                    "${formatTimeTenths(range.endInclusive.toLong())}  (${"%.1f".format(seconds)} s)",
                color = Color.White,
                fontSize = 13.sp,
            )
            RangeSlider(
                value = range,
                onValueChange = { range = it },
                valueRange = 0f..c.sourceDurationMs.toFloat(),
                onValueChangeFinished = {
                    vm.setTrim(c.id, range.start.toLong(), range.endInclusive.toLong())
                },
            )
        }
    }
}

@Composable
private fun TextPanel(vm: EditorViewModel, onAdd: () -> Unit, onEdit: (TextItem) -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .background(Panel)
            .padding(12.dp)
    ) {
        Button(onClick = onAdd) { Text("＋ Agregar texto en el cabezal") }
        Spacer(Modifier.height(6.dp))
        if (vm.texts.isEmpty()) {
            Hint("Arrastra el texto sobre el video para moverlo. Doble toque para editarlo.")
        } else {
            Column(
                Modifier
                    .heightIn(max = 110.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                vm.texts.forEach { t ->
                    Text(
                        "“${t.text}”   ${formatTime(t.startMs)} – ${formatTime(t.endMs)}",
                        color = Color.White,
                        fontSize = 14.sp,
                        maxLines = 1,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onEdit(t) }
                            .padding(vertical = 6.dp),
                    )
                }
            }
        }
    }
}

@Composable
private fun MusicPanel(vm: EditorViewModel, onPick: () -> Unit) {
    val m = vm.music
    Column(
        Modifier
            .fillMaxWidth()
            .background(Panel)
            .padding(12.dp)
    ) {
        if (m == null) {
            Button(onClick = onPick) { Text("＋ Elegir música de tu cel") }
            Spacer(Modifier.height(6.dp))
            Hint("La música empieza al inicio del video y se corta cuando termina.")
        } else {
            Text("♪ ${m.name}", color = Color.White, fontSize = 14.sp, maxLines = 1)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Volumen", color = Muted, fontSize = 13.sp)
                Slider(
                    value = m.volume,
                    onValueChange = { vm.setMusicVolume(it) },
                    valueRange = 0f..1f,
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 8.dp),
                )
                TextButton(onClick = { vm.removeMusic() }) { Text("Quitar", color = Pink) }
            }
        }
    }
}

@Composable
private fun ToolButton(
    icon: String,
    label: String,
    enabled: Boolean,
    selected: Boolean,
    onClick: () -> Unit,
) {
    val tint = when {
        !enabled -> Color(0xFF555A66)
        selected -> Accent
        else -> Color.White
    }
    Column(
        Modifier
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(icon, fontSize = 20.sp, color = tint)
        Text(label, fontSize = 11.sp, color = tint)
    }
}

// ---------------------------------------------------------------------------------------------
// Diálogos
// ---------------------------------------------------------------------------------------------

@Composable
private fun TextDialog(
    initial: TextItem?,
    total: Long,
    defaultStart: Long,
    onDismiss: () -> Unit,
    onConfirm: (String, Int, Float, Long, Long) -> Unit,
    onDelete: (() -> Unit)?,
) {
    var text by remember { mutableStateOf(initial?.text ?: "") }
    var color by remember { mutableIntStateOf(initial?.color ?: Color.White.toArgb()) }
    var size by remember { mutableFloatStateOf(initial?.sizeFrac ?: 0.07f) }

    val startDefault = initial?.startMs ?: defaultStart.coerceAtMost((total - 500L).coerceAtLeast(0L))
    val endDefault = initial?.endMs ?: (startDefault + 3000L).coerceAtMost(total)
    var range by remember { mutableStateOf(startDefault.toFloat()..endDefault.toFloat()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Nuevo texto" else "Editar texto") },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.verticalScroll(rememberScrollState()),
            ) {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    label = { Text("Texto") },
                    modifier = Modifier.fillMaxWidth(),
                )
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    TextColors.forEach { c ->
                        Box(
                            Modifier
                                .size(30.dp)
                                .clip(CircleShape)
                                .background(Color(c))
                                .border(
                                    if (c == color) 3.dp else 1.dp,
                                    if (c == color) Accent else Muted,
                                    CircleShape,
                                )
                                .clickable { color = c }
                        )
                    }
                }
                Text("Tamaño", color = Muted, fontSize = 13.sp)
                Slider(value = size, onValueChange = { size = it }, valueRange = 0.03f..0.15f)
                Text(
                    "Se ve de ${formatTimeTenths(range.start.toLong())} a " +
                        formatTimeTenths(range.endInclusive.toLong()),
                    color = Muted,
                    fontSize = 13.sp,
                )
                RangeSlider(
                    value = range,
                    onValueChange = { range = it },
                    valueRange = 0f..maxOf(total, 1L).toFloat(),
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (text.isNotBlank()) {
                    val s = range.start.toLong()
                    val e = maxOf(range.endInclusive.toLong(), s + 300L)
                    onConfirm(text.trim(), color, size, s, e)
                }
            }) { Text("Listo") }
        },
        dismissButton = {
            Row {
                if (onDelete != null) {
                    TextButton(onClick = onDelete) { Text("Borrar", color = Pink) }
                }
                TextButton(onClick = onDismiss) { Text("Cancelar") }
            }
        },
    )
}

@Composable
private fun ExportPickerDialog(
    aspect: Aspect,
    onDismiss: () -> Unit,
    onStart: (ExportQuality) -> Unit,
) {
    var q by remember { mutableStateOf(ExportQuality.P1080) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Exportar video") },
        text = {
            Column {
                ExportQuality.entries.forEach { opt ->
                    val (w, h) = aspect.sizeFor(opt.shortSide)
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { q = opt },
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(selected = q == opt, onClick = { q = opt })
                        Text("${opt.label}  ·  $w×$h", color = Color.White)
                    }
                }
                Spacer(Modifier.height(6.dp))
                Hint("Mantén la app abierta mientras exporta.")
            }
        },
        confirmButton = { TextButton(onClick = { onStart(q) }) { Text("Exportar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
    )
}

@Composable
private fun ExportProgressDialog(progress: Int, onCancel: () -> Unit) {
    AlertDialog(
        onDismissRequest = {},
        title = { Text("Exportando…") },
        text = {
            Column {
                LinearProgressIndicator(
                    progress = { progress.coerceIn(0, 100) / 100f },
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(8.dp))
                Text("$progress %", color = Muted)
            }
        },
        confirmButton = { TextButton(onClick = onCancel) { Text("Cancelar") } },
    )
}

private fun openVideo(ctx: Context, uri: Uri) {
    try {
        ctx.startActivity(
            Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, "video/mp4")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        )
    } catch (e: Exception) {
        Toast.makeText(ctx, "No encontré una app para abrir el video", Toast.LENGTH_SHORT).show()
    }
}

private fun shareVideo(ctx: Context, uri: Uri) {
    try {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "video/mp4"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(send, "Compartir video"))
    } catch (e: Exception) {
        Toast.makeText(ctx, "No pude compartir el video", Toast.LENGTH_SHORT).show()
    }
}
