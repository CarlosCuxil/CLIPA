@file:OptIn(UnstableApi::class)

package gt.calin.clipa

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlin.math.hypot
import kotlin.math.max

enum class Tool { None, Edit, Audio, Text, Sticker, Effects, Filters, Adjust, Format }

@Composable
fun EditorScreen(vm: EditorViewModel, onHome: () -> Unit) {
    val ctx = LocalContext.current
    val view = LocalView.current
    val exporting = vm.export is ExportState.Running
    SideEffect { view.keepScreenOn = exporting }

    var tool by rememberSaveable { mutableStateOf(Tool.None) }
    var showExport by remember { mutableStateOf(false) }
    var showPaywall by remember { mutableStateOf(false) }
    var confirmLeave by remember { mutableStateOf(false) }

    val pickVideos = rememberLauncherForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(30)
    ) { uris -> if (uris.isNotEmpty()) vm.addVideos(uris) }

    val pickAudio = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> if (uri != null) vm.importAudio(uri) }

    val addVideo: () -> Unit = {
        pickVideos.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
    }
    val chooseAudio: () -> Unit = { pickAudio.launch(arrayOf("audio/*")) }
    val paywall: () -> Unit = { showPaywall = true }

    fun openTool(t: Tool) {
        if (vm.clips.isEmpty()) {
            Toast.makeText(ctx, "Primero agrega un video", Toast.LENGTH_SHORT).show()
            return
        }
        vm.stopAudition()
        if (vm.selection == null && t != Tool.Audio) {
            vm.currentClip?.let { vm.select(SelClip(it.id)) }
        }
        tool = t
    }

    BackHandler {
        if (tool != Tool.None) {
            vm.stopAudition()
            tool = Tool.None
        } else {
            confirmLeave = true
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Pal.Bg)
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
    ) {
        TopBar(
            vm = vm,
            onBack = { confirmLeave = true },
            onPro = paywall,
            onExport = {
                if (vm.clips.isEmpty()) {
                    Toast.makeText(ctx, "Agrega un video para exportar", Toast.LENGTH_SHORT).show()
                } else {
                    vm.pause()
                    showExport = true
                }
            },
        )

        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 2.dp),
            contentAlignment = Alignment.Center,
        ) {
            if (vm.clips.isEmpty()) {
                EmptyState(onAdd = addVideo)
            } else {
                PreviewArea(vm, onEditText = { tool = Tool.Text })
            }
        }

        TransportRow(vm)

        TimelineView(vm = vm, onAddClip = addVideo)

        when (tool) {
            Tool.None -> Toolbar(vm, onTool = { openTool(it) })
            Tool.Edit -> EditPanel(vm, onClose = { tool = Tool.None })
            Tool.Audio -> AudioPanel(
                vm,
                onClose = {
                    vm.stopAudition()
                    tool = Tool.None
                },
                onPickAudio = chooseAudio,
                onPaywall = paywall,
            )
            Tool.Text -> TextPanel(vm, onClose = { tool = Tool.None }, onPaywall = paywall)
            Tool.Sticker -> StickerPanel(vm, onClose = { tool = Tool.None })
            Tool.Effects -> EffectsPanel(vm, onClose = { tool = Tool.None }, onPaywall = paywall)
            Tool.Filters -> FiltersPanel(vm, onClose = { tool = Tool.None }, onPaywall = paywall)
            Tool.Adjust -> AdjustPanel(vm, onClose = { tool = Tool.None })
            Tool.Format -> FormatPanel(vm, onClose = { tool = Tool.None })
        }
    }

    if (showExport) {
        ExportDialog(
            project = vm.project,
            isPro = vm.isPro,
            onDismiss = { showExport = false },
            onStart = { q ->
                showExport = false
                vm.startExport(q)
            },
            onPaywall = {
                showExport = false
                showPaywall = true
            },
        )
    }

    when (val e = vm.export) {
        is ExportState.Running -> ExportProgressDialog(e.progress, onCancel = { vm.cancelExport() })
        is ExportState.Done -> ExportDoneDialog(
            state = e,
            onClose = { vm.dismissExport() },
        )
        is ExportState.Error -> ExportErrorDialog(e.message, onClose = { vm.dismissExport() })
        ExportState.Idle -> {}
    }

    if (showPaywall) {
        PaywallDialog(
            onDismiss = { showPaywall = false },
            onActivate = {
                vm.changePro(true)
                showPaywall = false
                Toast.makeText(ctx, "PRO activado (modo de prueba)", Toast.LENGTH_SHORT).show()
            },
        )
    }

    if (confirmLeave) {
        ConfirmDialog(
            title = "¿Salir del editor?",
            message = "Tu proyecto se queda abierto mientras la app siga en memoria, pero todavía no se guarda en el teléfono.",
            confirm = "Salir",
            onConfirm = {
                confirmLeave = false
                vm.pause()
                onHome()
            },
            onDismiss = { confirmLeave = false },
        )
    }
}

@Composable
private fun TopBar(vm: EditorViewModel, onBack: () -> Unit, onPro: () -> Unit, onExport: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .height(54.dp)
            .padding(horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconBtn(Ic.Back, onClick = onBack)
        Spacer(Modifier.weight(1f))
        if (!vm.isPro) {
            Row(
                Modifier
                    .clip(RoundedCornerShape(50))
                    .background(Pal.Surface2)
                    .tap(onClick = onPro)
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Glyph(Ic.Crown, Pal.Gold, size = 14.dp)
                Spacer(Modifier.width(4.dp))
                Text("PRO", color = Pal.Gold, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
            }
            Spacer(Modifier.width(8.dp))
        }
        GradientButton("Exportar", onClick = onExport, height = 36.dp, ic = Ic.Export)
        Spacer(Modifier.width(6.dp))
    }
}

@Composable
private fun EmptyState(onAdd: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .size(84.dp)
                .clip(CircleShape)
                .background(Pal.BrandDiagonal)
                .tap(onClick = onAdd),
            contentAlignment = Alignment.Center,
        ) {
            Glyph(Ic.Plus, Color.Black, size = 40.dp)
        }
        Spacer(Modifier.height(14.dp))
        Text("Agrega tus videos", color = Pal.Text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text("Toca el botón para empezar", color = Pal.Muted, fontSize = 13.sp)
    }
}

@Composable
private fun PreviewArea(vm: EditorViewModel, onEditText: () -> Unit) {
    BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        val ratio = vm.aspect.ratio
        var w = maxWidth
        var h = w / ratio
        if (h > maxHeight) {
            h = maxHeight
            w = h * ratio
        }

        Box(
            Modifier
                .size(w, h)
                .clip(RoundedCornerShape(8.dp))
                .background(Color.Black)
        ) {
            AndroidView(
                factory = { c ->
                    PlayerView(c).apply {
                        player = vm.player
                        useController = false
                        resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FILL
                        setShutterBackgroundColor(android.graphics.Color.BLACK)
                    }
                },
                modifier = Modifier.fillMaxSize(),
            )

            Canvas(
                Modifier
                    .fillMaxSize()
                    .pointerInput(Unit) {
                        var mode = 0
                        var id = -1L
                        var cx = 0f
                        var cy = 0f
                        var startSize = 0f
                        var startDist = 1f
                        var px = 0f
                        var py = 0f
                        detectDragGestures(
                            onDragStart = { off ->
                                val sw = size.width.toFloat()
                                val sh = size.height.toFloat()
                                val pos = vm.positionMs
                                mode = 0
                                val sel = vm.selectedText
                                var handled = false
                                if (sel != null && pos >= sel.startMs && pos < sel.endMs) {
                                    val r = TextRenderer.bounds(sel, sw, sh)
                                    if (hypot(off.x - r.right, off.y - r.bottom) < 30.dp.toPx()) {
                                        mode = 2
                                        id = sel.id
                                        cx = sel.x * sw
                                        cy = sel.y * sh
                                        startSize = sel.sizeFrac
                                        startDist = max(1f, hypot(off.x - cx, off.y - cy))
                                        px = off.x
                                        py = off.y
                                        handled = true
                                    }
                                }
                                if (!handled) {
                                    val hit = vm.texts.lastOrNull {
                                        pos >= it.startMs && pos < it.endMs &&
                                            TextRenderer.bounds(it, sw, sh).contains(off.x, off.y)
                                    }
                                    if (hit != null) {
                                        mode = 1
                                        id = hit.id
                                        vm.select(SelText(hit.id))
                                    }
                                }
                            },
                            onDrag = { change, drag ->
                                if (mode == 1) {
                                    change.consume()
                                    vm.moveText(id, drag.x / size.width, drag.y / size.height)
                                } else if (mode == 2) {
                                    change.consume()
                                    px += drag.x
                                    py += drag.y
                                    val dist = hypot(px - cx, py - cy)
                                    val ns = (startSize * dist / startDist).coerceIn(0.02f, 0.5f)
                                    vm.updateText(id, "size") { it.copy(sizeFrac = ns) }
                                }
                            },
                        )
                    }
                    .pointerInput(Unit) {
                        detectTapGestures(
                            onTap = { off ->
                                val sw = size.width.toFloat()
                                val sh = size.height.toFloat()
                                val pos = vm.positionMs
                                val hit = vm.texts.lastOrNull {
                                    pos >= it.startMs && pos < it.endMs &&
                                        TextRenderer.bounds(it, sw, sh).contains(off.x, off.y)
                                }
                                if (hit != null) {
                                    vm.select(SelText(hit.id))
                                } else if (vm.selection is SelText) {
                                    vm.select(null)
                                } else {
                                    vm.togglePlay()
                                }
                            },
                            onDoubleTap = { off ->
                                val sw = size.width.toFloat()
                                val sh = size.height.toFloat()
                                val pos = vm.positionMs
                                val hit = vm.texts.lastOrNull {
                                    pos >= it.startMs && pos < it.endMs &&
                                        TextRenderer.bounds(it, sw, sh).contains(off.x, off.y)
                                }
                                if (hit != null && !hit.sticker) {
                                    vm.select(SelText(hit.id))
                                    onEditText()
                                }
                            },
                        )
                    }
            ) {
                val pos = vm.positionMs
                val sw = size.width
                val sh = size.height
                val items = vm.texts
                drawIntoCanvas { c ->
                    for (t in items) {
                        if (pos >= t.startMs && pos < t.endMs) TextRenderer.draw(c.nativeCanvas, t, sw, sh)
                    }
                }
                val sel = vm.selectedText
                if (sel != null && pos >= sel.startMs && pos < sel.endMs) {
                    val r = TextRenderer.bounds(sel, sw, sh)
                    drawRect(
                        Pal.Accent,
                        Offset(r.left, r.top),
                        Size(r.width(), r.height()),
                        style = Stroke(width = 1.5.dp.toPx()),
                    )
                    drawCircle(Pal.Accent, 8.dp.toPx(), Offset(r.right, r.bottom))
                    drawCircle(Color.White, 3.5.dp.toPx(), Offset(r.right, r.bottom))
                }
            }
        }
    }
}

@Composable
private fun TransportRow(vm: EditorViewModel) {
    Row(
        Modifier
            .fillMaxWidth()
            .height(48.dp)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
            Text(
                formatTimeTenths(vm.positionMs),
                color = Pal.Text,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
            )
            Text(
                "  /  " + formatTimeTenths(vm.totalMs),
                color = Pal.Muted,
                fontSize = 13.sp,
            )
        }
        IconBtn(
            if (vm.playing) Ic.Pause else Ic.Play,
            onClick = { vm.togglePlay() },
            tint = Color.Black,
            bg = Color.White,
            box = 40.dp,
            glyph = 22.dp,
        )
        Row(Modifier.weight(1f), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
            IconBtn(Ic.Undo, onClick = { vm.undo() }, enabled = vm.canUndo, box = 40.dp)
            IconBtn(Ic.Redo, onClick = { vm.redo() }, enabled = vm.canRedo, box = 40.dp)
        }
    }
}

@Composable
private fun Toolbar(vm: EditorViewModel, onTool: (Tool) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(Pal.Surface)
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 4.dp, vertical = 2.dp),
    ) {
        ToolButton(Ic.Scissors, "Dividir", onClick = { vm.splitAtPlayhead() })
        ToolButton(
            Ic.Trash, "Eliminar",
            onClick = { if (vm.selection != null) vm.deleteSelected() },
            tint = if (vm.selection != null) Pal.Danger else Pal.Muted,
        )
        Box(
            Modifier
                .padding(vertical = 14.dp, horizontal = 4.dp)
                .width(1.dp)
                .height(36.dp)
                .background(Pal.Line)
        )
        ToolButton(Ic.Pencil, "Editar", onClick = { onTool(Tool.Edit) })
        ToolButton(Ic.Music, "Audio", onClick = { onTool(Tool.Audio) })
        ToolButton(Ic.Text, "Texto", onClick = { onTool(Tool.Text) })
        ToolButton(Ic.Sticker, "Pegatinas", onClick = { onTool(Tool.Sticker) })
        ToolButton(Ic.Fx, "Efectos", onClick = { onTool(Tool.Effects) })
        ToolButton(Ic.Filter, "Filtros", onClick = { onTool(Tool.Filters) })
        ToolButton(Ic.Adjust, "Ajustar", onClick = { onTool(Tool.Adjust) })
        ToolButton(Ic.Format, "Formato", onClick = { onTool(Tool.Format) })
    }
}
