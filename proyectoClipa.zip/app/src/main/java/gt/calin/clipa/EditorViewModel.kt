@file:OptIn(UnstableApi::class)

package gt.calin.clipa

import android.app.Application
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.SeekParameters
import androidx.media3.transformer.Composition
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.abs
import kotlin.math.min

class EditorViewModel(app: Application) : AndroidViewModel(app) {

    private val ctx: Context = app.applicationContext
    private val prefs = ctx.getSharedPreferences("clipa", Context.MODE_PRIVATE)

    // ---- Estado observable por la interfaz ----
    var project by mutableStateOf(Project())
        private set
    var selection by mutableStateOf<Sel?>(null)
        private set
    var positionMs by mutableLongStateOf(0L)
        private set
    var playing by mutableStateOf(false)
        private set
    var export by mutableStateOf<ExportState>(ExportState.Idle)
        private set
    var isPro by mutableStateOf(prefs.getBoolean("pro", false))
        private set
    var thumbs by mutableStateOf<Map<Uri, ThumbSet>>(emptyMap())
        private set
    var canUndo by mutableStateOf(false)
        private set
    var canRedo by mutableStateOf(false)
        private set
    var generatingSound by mutableStateOf<String?>(null)
        private set
    var auditioning by mutableStateOf<String?>(null)
        private set

    val clips: List<Clip> get() = project.clips
    val texts: List<TextItem> get() = project.texts
    val audios: List<AudioClip> get() = project.audios
    val aspect: Aspect get() = project.aspect
    val muteOriginal: Boolean get() = project.muteOriginal
    val totalMs: Long get() = project.totalMs

    val selectedClip: Clip? get() = (selection as? SelClip)?.let { s -> clips.firstOrNull { it.id == s.id } }
    val selectedText: TextItem? get() = (selection as? SelText)?.let { s -> texts.firstOrNull { it.id == s.id } }
    val selectedAudio: AudioClip? get() = (selection as? SelAudio)?.let { s -> audios.firstOrNull { it.id == s.id } }

    /** Clip que está bajo el cabezal. */
    val currentClip: Clip?
        get() {
            val list = clips
            if (list.isEmpty()) return null
            val t = positionMs
            var acc = 0L
            for (c in list) {
                if (t < acc + c.lengthMs) return c
                acc += c.lengthMs
            }
            return list.last()
        }

    // ---- Reproductores ----
    val player: ExoPlayer = ExoPlayer.Builder(ctx).build()
    private val auditionPlayer: ExoPlayer = ExoPlayer.Builder(ctx).build()
    private val audioPlayers = HashMap<Long, ExoPlayer>()
    private val audioKeys = HashMap<Long, String>()

    private var nextId = 1L
    private var transformer: Transformer? = null
    private var progressJob: Job? = null
    private var fxJob: Job? = null
    private var appliedFxKey: Pair<Look, Aspect>? = null
    private var fxFailed = false

    // ---- Deshacer / rehacer ----
    private val undoStack = ArrayList<Project>()
    private val redoStack = ArrayList<Project>()
    private var lastEditKey: String? = null
    private var lastEditAt = 0L

    init {
        val (pw, ph) = Aspect.R9_16.sizeFor(PREVIEW_SHORT)
        // Los efectos se declaran antes de preparar el reproductor.
        player.setVideoEffects(FxEngine.effects(Look(), pw, ph))

        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                playing = isPlaying
                if (isPlaying) syncAudio(currentGlobalPos()) else pauseAllAudio()
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) {
                    pauseAllAudio()
                    positionMs = totalMs
                }
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                applyPreviewEffects()
                applyVolume()
            }

            override fun onPlayerError(error: PlaybackException) {
                if (!fxFailed) {
                    // Si falla la vista previa con efectos, se reintenta sin ellos.
                    fxFailed = true
                    toast("La vista previa se verá sin efectos (la exportación sí los incluye).")
                    player.setVideoEffects(emptyList())
                    player.prepare()
                } else {
                    toast("No se pudo reproducir este video")
                }
            }
        })

        auditionPlayer.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) auditioning = null
            }
        })

        // Actualiza el cabezal y los sonidos mientras se reproduce.
        viewModelScope.launch {
            while (true) {
                delay(33)
                if (player.isPlaying) {
                    val p = currentGlobalPos()
                    positionMs = p
                    syncAudio(p)
                }
            }
        }
    }

    // ---- Tiempo ----

    private fun currentGlobalPos(): Long {
        val list = clips
        val i = player.currentMediaItemIndex
        if (list.isEmpty() || i < 0 || i >= list.size) return 0L
        return (list.offsetOf(i) + player.currentPosition.coerceAtLeast(0L)).coerceAtMost(totalMs)
    }

    fun seekTo(ms: Long) {
        val list = clips
        if (list.isEmpty()) return
        val t = ms.coerceIn(0L, totalMs)
        var acc = 0L
        var idx = list.lastIndex
        var local = list.last().lengthMs
        for ((k, c) in list.withIndex()) {
            if (t < acc + c.lengthMs) {
                idx = k
                local = t - acc
                break
            }
            acc += c.lengthMs
        }
        player.seekTo(idx, local)
        positionMs = t
        if (player.isPlaying) syncAudio(t)
    }

    fun beginScrub() {
        player.pause()
        player.setSeekParameters(SeekParameters.CLOSEST_SYNC)
    }

    fun scrubTo(ms: Long) {
        seekTo(ms)
    }

    fun endScrub() {
        player.setSeekParameters(SeekParameters.EXACT)
        seekTo(positionMs)
    }

    fun togglePlay() {
        if (clips.isEmpty()) return
        if (player.isPlaying) {
            player.pause()
        } else {
            if (positionMs >= totalMs - 50) seekTo(0)
            player.play()
        }
    }

    fun pause() {
        player.pause()
    }

    private fun toast(msg: String) {
        Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
    }

    // ---- Reproductor de video ----

    private fun rebuildPlayer() {
        player.pause()
        val keep = positionMs
        val list = clips
        if (list.isEmpty()) {
            player.clearMediaItems()
            positionMs = 0L
            return
        }
        player.setMediaItems(list.map { it.toMediaItem() })
        player.prepare()
        seekTo(keep)
        applyPreviewEffects()
        applyVolume()
    }

    private fun applyPreviewEffects() {
        if (fxFailed) return
        val idx = player.currentMediaItemIndex.coerceAtLeast(0)
        val clip = clips.getOrNull(idx) ?: return
        val key = Pair(clip.look, aspect)
        if (key == appliedFxKey) return
        appliedFxKey = key
        val (w, h) = aspect.sizeFor(PREVIEW_SHORT)
        player.setVideoEffects(FxEngine.effects(clip.look, w, h))
        if (!player.isPlaying) player.seekTo(player.currentMediaItemIndex, player.currentPosition)
    }

    private fun scheduleEffects() {
        fxJob?.cancel()
        fxJob = viewModelScope.launch {
            delay(150)
            applyPreviewEffects()
        }
    }

    private fun applyVolume() {
        val idx = player.currentMediaItemIndex.coerceAtLeast(0)
        val c = clips.getOrNull(idx)
        player.volume = if (muteOriginal) 0f else (c?.volume ?: 1f)
    }

    // ---- Audio (sonidos y música sobre la línea de tiempo) ----

    private fun syncAudioPlayers() {
        val ids = audios.map { it.id }.toSet()
        for (id in audioPlayers.keys.toList()) {
            if (id !in ids) {
                audioPlayers.remove(id)?.release()
                audioKeys.remove(id)
            }
        }
        for (a in audios) {
            val key = "${a.uri}|${a.trimStartMs}|${a.trimEndMs}"
            val p = audioPlayers.getOrPut(a.id) { ExoPlayer.Builder(ctx).build() }
            if (audioKeys[a.id] != key) {
                p.setMediaItem(a.toMediaItem(Long.MAX_VALUE))
                p.prepare()
                audioKeys[a.id] = key
            }
            p.volume = a.volume
        }
        if (player.isPlaying) syncAudio(currentGlobalPos())
    }

    private fun syncAudio(pos: Long) {
        for (a in audios) {
            val p = audioPlayers[a.id] ?: continue
            val local = pos - a.startMs
            if (local >= 0 && local < a.lengthMs) {
                if (!p.isPlaying) {
                    p.seekTo(local)
                    p.play()
                } else if (abs(p.currentPosition - local) > 280) {
                    p.seekTo(local)
                }
            } else if (p.isPlaying) {
                p.pause()
            }
        }
    }

    private fun pauseAllAudio() {
        for (p in audioPlayers.values) if (p.isPlaying) p.pause()
    }

    // ---- Núcleo de edición con deshacer ----

    private fun clampTexts(p: Project): Project {
        val total = p.totalMs
        if (p.texts.isEmpty()) return p
        val fixed = p.texts.filter { it.startMs < total || total == 0L }
            .map { if (total > 0 && it.endMs > total) it.copy(endMs = total) else it }
        return if (fixed == p.texts) p else p.copy(texts = fixed)
    }

    private fun edit(key: String? = null, transform: (Project) -> Project) {
        val old = project
        val updated = clampTexts(transform(old))
        if (updated == old) return
        val now = System.currentTimeMillis()
        val coalesce = key != null && key == lastEditKey && now - lastEditAt < 1200
        if (!coalesce) {
            undoStack.add(old)
            if (undoStack.size > 60) undoStack.removeAt(0)
            redoStack.clear()
        }
        lastEditKey = key
        lastEditAt = now
        commit(updated)
        refreshUndoFlags()
    }

    private fun commit(new: Project) {
        val old = project
        project = new

        val sel = selection
        if (sel != null) {
            val valid = when (sel) {
                is SelClip -> new.clips.any { it.id == sel.id }
                is SelText -> new.texts.any { it.id == sel.id }
                is SelAudio -> new.audios.any { it.id == sel.id }
            }
            if (!valid) selection = null
        }

        val oldMedia = old.clips.map { Triple(it.uri, it.startMs, it.endMs) }
        val newMedia = new.clips.map { Triple(it.uri, it.startMs, it.endMs) }
        if (oldMedia != newMedia) {
            rebuildPlayer()
        } else {
            if (old.clips.map { it.look } != new.clips.map { it.look } || old.aspect != new.aspect) {
                scheduleEffects()
            }
            if (old.muteOriginal != new.muteOriginal || old.clips.map { it.volume } != new.clips.map { it.volume }) {
                applyVolume()
            }
        }
        if (old.audios != new.audios) syncAudioPlayers()
        if (positionMs > new.totalMs) positionMs = new.totalMs
    }

    private fun refreshUndoFlags() {
        canUndo = undoStack.isNotEmpty()
        canRedo = redoStack.isNotEmpty()
    }

    fun undo() {
        if (undoStack.isEmpty()) return
        redoStack.add(project)
        val prev = undoStack.removeAt(undoStack.lastIndex)
        lastEditKey = null
        commit(prev)
        refreshUndoFlags()
    }

    fun redo() {
        if (redoStack.isEmpty()) return
        undoStack.add(project)
        val next = redoStack.removeAt(redoStack.lastIndex)
        lastEditKey = null
        commit(next)
        refreshUndoFlags()
    }

    fun select(s: Sel?) {
        selection = s
    }

    // ---- Proyecto ----

    fun newProject() {
        player.pause()
        player.clearMediaItems()
        for (p in audioPlayers.values) p.release()
        audioPlayers.clear()
        audioKeys.clear()
        undoStack.clear()
        redoStack.clear()
        refreshUndoFlags()
        project = Project()
        selection = null
        positionMs = 0L
        appliedFxKey = null
        export = ExportState.Idle
    }

    // ---- Clips ----

    fun addVideos(uris: List<Uri>) {
        viewModelScope.launch {
            val added = withContext(Dispatchers.IO) {
                uris.mapNotNull { u ->
                    val d = probeDuration(u)
                    if (d > 0) Clip(nextId++, u, d, 0L, d) else null
                }
            }
            if (added.isEmpty()) {
                toast("No pude leer ese video")
                return@launch
            }
            edit { it.copy(clips = it.clips + added) }
            if (selection == null) selection = SelClip(added.first().id)
            for (c in added) loadThumbs(c.uri, c.sourceDurationMs)
        }
    }

    private fun loadThumbs(uri: Uri, durationMs: Long) {
        if (thumbs.containsKey(uri)) return
        viewModelScope.launch {
            val set = withContext(Dispatchers.IO) { Thumbs.load(ctx, uri, durationMs) }
            if (set != null) thumbs = thumbs + (uri to set)
        }
    }

    private fun probeDuration(uri: Uri): Long {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, uri)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } catch (e: Exception) {
            0L
        } finally {
            r.release()
        }
    }

    /** Fotograma pequeño del clip bajo el cabezal (para las vistas previas de filtros). */
    fun currentFrame(): Bitmap? {
        val list = clips
        if (list.isEmpty()) return null
        val c = selectedClip ?: currentClip ?: return null
        val set = thumbs[c.uri] ?: return null
        val off = list.offsetOf(list.indexOfFirst { it.id == c.id })
        val inClip = (positionMs - off).coerceIn(0L, c.lengthMs)
        return set.bitmaps.getOrNull(set.indexAt(c.startMs + inClip))
    }

    fun splitAtPlayhead() {
        val pos = positionMs
        var acc = 0L
        for ((i, c) in clips.withIndex()) {
            if (pos > acc + 250 && pos < acc + c.lengthMs - 250) {
                val cut = c.startMs + (pos - acc)
                val a = c.copy(endMs = cut)
                val b = c.copy(id = nextId++, startMs = cut)
                edit {
                    val list = it.clips.toMutableList()
                    list[i] = a
                    list.add(i + 1, b)
                    it.copy(clips = list)
                }
                selection = SelClip(b.id)
                return
            }
            acc += c.lengthMs
        }
        toast("Pon el cabezal dentro de un clip para dividir")
    }

    fun deleteSelected() {
        when (val s = selection) {
            is SelClip -> {
                val i = clips.indexOfFirst { it.id == s.id }
                if (i < 0) return
                edit { it.copy(clips = it.clips.filter { c -> c.id != s.id }) }
                selection = clips.getOrNull(i)?.let { SelClip(it.id) } ?: clips.lastOrNull()?.let { SelClip(it.id) }
            }
            is SelText -> edit { it.copy(texts = it.texts.filter { t -> t.id != s.id }) }
            is SelAudio -> edit { it.copy(audios = it.audios.filter { a -> a.id != s.id }) }
            null -> {}
        }
    }

    fun duplicateSelected() {
        when (val s = selection) {
            is SelClip -> {
                val i = clips.indexOfFirst { it.id == s.id }
                if (i < 0) return
                val copy = clips[i].copy(id = nextId++)
                edit {
                    val list = it.clips.toMutableList()
                    list.add(i + 1, copy)
                    it.copy(clips = list)
                }
                selection = SelClip(copy.id)
            }
            is SelText -> {
                val t = texts.firstOrNull { it.id == s.id } ?: return
                val copy = t.copy(id = nextId++, x = (t.x + 0.06f).coerceAtMost(0.95f), y = (t.y + 0.06f).coerceAtMost(0.95f))
                edit { it.copy(texts = it.texts + copy) }
                selection = SelText(copy.id)
            }
            is SelAudio -> {
                val a = audios.firstOrNull { it.id == s.id } ?: return
                val copy = a.copy(id = nextId++, startMs = a.endMs)
                edit { it.copy(audios = it.audios + copy) }
                selection = SelAudio(copy.id)
            }
            null -> {}
        }
    }

    fun moveSelectedClip(delta: Int) {
        val s = selection as? SelClip ?: return
        val i = clips.indexOfFirst { it.id == s.id }
        val j = i + delta
        if (i < 0 || j < 0 || j >= clips.size) return
        edit {
            val list = it.clips.toMutableList()
            val tmp = list[i]
            list[i] = list[j]
            list[j] = tmp
            it.copy(clips = list)
        }
    }

    fun setTrim(id: Long, startMs: Long, endMs: Long) {
        val c = clips.firstOrNull { it.id == id } ?: return
        val s = startMs.coerceIn(0L, (c.sourceDurationMs - MIN_CLIP_MS).coerceAtLeast(0L))
        val e = endMs.coerceIn(s + MIN_CLIP_MS, c.sourceDurationMs)
        edit("trim$id") { p -> p.copy(clips = p.clips.map { if (it.id == id) it.copy(startMs = s, endMs = e) else it }) }
    }

    fun updateLook(id: Long, key: String, change: (Look) -> Look) {
        edit("look$id$key") { p ->
            p.copy(clips = p.clips.map { if (it.id == id) it.copy(look = change(it.look)) else it })
        }
    }

    fun applyLookToAll(id: Long) {
        val src = clips.firstOrNull { it.id == id } ?: return
        edit { p -> p.copy(clips = p.clips.map { it.copy(look = src.look) }) }
        toast("Aplicado a todos los clips")
    }

    fun setClipVolume(id: Long, v: Float) {
        edit("vol$id") { p -> p.copy(clips = p.clips.map { if (it.id == id) it.copy(volume = v) else it }) }
    }

    fun toggleMuteOriginal() {
        edit { it.copy(muteOriginal = !it.muteOriginal) }
    }

    fun changeAspect(a: Aspect) {
        edit { it.copy(aspect = a) }
    }

    // ---- Texto y pegatinas ----

    fun addText(text: String, color: Int, font: TextFont, style: TextStyleKind): Long {
        val start = positionMs.coerceAtMost((totalMs - 500).coerceAtLeast(0L))
        val end = min(totalMs, start + 3000L).coerceAtLeast(start + 500L)
        val item = TextItem(nextId++, text, start, end, color, 0.07f, 0.5f, 0.5f, font, style, false)
        edit { it.copy(texts = it.texts + item) }
        selection = SelText(item.id)
        return item.id
    }

    fun addSticker(emoji: String) {
        if (totalMs <= 0L) {
            toast("Primero agrega un video")
            return
        }
        val start = positionMs.coerceAtMost((totalMs - 500).coerceAtLeast(0L))
        val end = min(totalMs, start + 3000L).coerceAtLeast(start + 500L)
        val item = TextItem(nextId++, emoji, start, end, 0xFFFFFFFF.toInt(), 0.14f, 0.5f, 0.45f, TextFont.MODERN, TextStyleKind.CLASSIC, true)
        edit { it.copy(texts = it.texts + item) }
        selection = SelText(item.id)
    }

    fun updateText(id: Long, key: String, change: (TextItem) -> TextItem) {
        edit("text$id$key") { p -> p.copy(texts = p.texts.map { if (it.id == id) change(it) else it }) }
    }

    fun moveText(id: Long, dx: Float, dy: Float) {
        updateText(id, "move") {
            it.copy(x = (it.x + dx).coerceIn(0.02f, 0.98f), y = (it.y + dy).coerceIn(0.02f, 0.98f))
        }
    }

    fun setTextTime(id: Long, startMs: Long, endMs: Long) {
        val total = totalMs
        val s = startMs.coerceIn(0L, (total - 200).coerceAtLeast(0L))
        val e = endMs.coerceIn(s + 200, total.coerceAtLeast(s + 200))
        updateText(id, "time") { it.copy(startMs = s, endMs = e) }
    }

    // ---- Sonidos ----

    fun addSound(def: SoundDef) {
        if (clips.isEmpty()) {
            toast("Primero agrega un video")
            return
        }
        if (audios.size >= MAX_AUDIOS) {
            toast("Máximo $MAX_AUDIOS sonidos por proyecto")
            return
        }
        viewModelScope.launch {
            generatingSound = def.id
            try {
                val file = withContext(Dispatchers.IO) { SoundLab.fileFor(File(ctx.cacheDir, "sounds"), def) }
                val clip = AudioClip(
                    id = nextId++,
                    uri = Uri.fromFile(file),
                    name = def.name,
                    kind = if (def.isMusic) AudioKind.MUSIC else AudioKind.SFX,
                    sourceDurationMs = def.durationMs,
                    trimStartMs = 0L,
                    trimEndMs = def.durationMs,
                    startMs = positionMs,
                    volume = if (def.isMusic) 0.7f else 1f,
                )
                edit { it.copy(audios = it.audios + clip) }
                selection = SelAudio(clip.id)
            } catch (e: Exception) {
                toast("No pude preparar ese sonido")
            } finally {
                generatingSound = null
            }
        }
    }

    fun importAudio(uri: Uri) {
        if (clips.isEmpty()) {
            toast("Primero agrega un video")
            return
        }
        if (audios.size >= MAX_AUDIOS) {
            toast("Máximo $MAX_AUDIOS sonidos por proyecto")
            return
        }
        viewModelScope.launch {
            val (dur, name) = withContext(Dispatchers.IO) { probeDuration(uri) to displayName(uri) }
            if (dur <= 0) {
                toast("No pude leer ese audio")
                return@launch
            }
            val clip = AudioClip(nextId++, uri, name, AudioKind.IMPORTED, dur, 0L, dur, positionMs, 0.8f)
            edit { it.copy(audios = it.audios + clip) }
            selection = SelAudio(clip.id)
        }
    }

    private fun displayName(uri: Uri): String {
        return try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
                ?: "Audio"
        } catch (e: Exception) {
            "Audio"
        }
    }

    fun moveAudio(id: Long, newStartMs: Long) {
        edit("amove$id") { p ->
            p.copy(audios = p.audios.map { if (it.id == id) it.copy(startMs = newStartMs.coerceAtLeast(0L)) else it })
        }
    }

    /** Recorta un audio moviendo sus bordes. Los deltas son en milisegundos. */
    fun trimAudio(id: Long, deltaStartMs: Long, deltaEndMs: Long) {
        edit("atrim$id") { p ->
            p.copy(audios = p.audios.map {
                if (it.id == id) {
                    val ts = (it.trimStartMs + deltaStartMs).coerceIn(0L, (it.trimEndMs - 200).coerceAtLeast(0L))
                    val te = (it.trimEndMs + deltaEndMs).coerceIn(ts + 200, it.sourceDurationMs)
                    it.copy(trimStartMs = ts, trimEndMs = te, startMs = (it.startMs + (ts - it.trimStartMs)).coerceAtLeast(0L))
                } else it
            })
        }
    }

    fun setAudioVolume(id: Long, v: Float) {
        edit("avol$id") { p -> p.copy(audios = p.audios.map { if (it.id == id) it.copy(volume = v) else it }) }
    }

    fun toggleAudition(def: SoundDef) {
        if (auditioning == def.id) {
            stopAudition()
            return
        }
        viewModelScope.launch {
            player.pause()
            generatingSound = def.id
            try {
                val file = withContext(Dispatchers.IO) { SoundLab.fileFor(File(ctx.cacheDir, "sounds"), def) }
                auditionPlayer.setMediaItem(MediaItem.fromUri(Uri.fromFile(file)))
                auditionPlayer.prepare()
                auditionPlayer.play()
                auditioning = def.id
            } catch (e: Exception) {
                toast("No pude reproducir ese sonido")
            } finally {
                generatingSound = null
            }
        }
    }

    fun stopAudition() {
        auditionPlayer.stop()
        auditioning = null
    }

    // ---- PRO ----

    fun changePro(value: Boolean) {
        isPro = value
        prefs.edit().putBoolean("pro", value).apply()
    }

    // ---- Exportar ----

    fun startExport(quality: ExportQuality) {
        if (clips.isEmpty()) return
        if (quality.pro && !isPro) return
        player.pause()
        stopAudition()
        export = ExportState.Running(0)

        val snapshot = project
        val outFile = File(ctx.cacheDir, "export_${System.currentTimeMillis()}.mp4")
        var dims = Pair(0, 0)

        val listener = object : Transformer.Listener {
            override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                val w = if (exportResult.width > 0) exportResult.width else dims.first
                val h = if (exportResult.height > 0) exportResult.height else dims.second
                saveToGallery(outFile, w, h)
            }

            override fun onError(
                composition: Composition,
                exportResult: ExportResult,
                exportException: ExportException,
            ) {
                outFile.delete()
                export = ExportState.Error(
                    "No se pudo exportar (${exportException.errorCodeName}). " +
                        "Prueba con una calidad menor o con menos efectos."
                )
            }
        }

        val job = try {
            Exporter(ctx).start(snapshot, quality, outFile.absolutePath, listener)
        } catch (e: Exception) {
            export = ExportState.Error("No se pudo iniciar la exportación: ${e.message}")
            return
        }
        dims = Pair(job.width, job.height)
        val t = job.transformer
        transformer = t

        progressJob?.cancel()
        progressJob = viewModelScope.launch {
            val holder = ProgressHolder()
            while (isActive && export is ExportState.Running) {
                if (t.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE) {
                    export = ExportState.Running(holder.progress)
                }
                delay(250)
            }
        }
    }

    private fun saveToGallery(file: File, w: Int, h: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val resolver = ctx.contentResolver
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, "Clipa_${System.currentTimeMillis()}.mp4")
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/Clipa")
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }
                val collection = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                val uri = resolver.insert(collection, values) ?: error("No se pudo crear el archivo")
                resolver.openOutputStream(uri)?.use { out ->
                    file.inputStream().use { it.copyTo(out) }
                } ?: error("No se pudo escribir el archivo")
                values.clear()
                values.put(MediaStore.Video.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
                file.delete()
                withContext(Dispatchers.Main) { export = ExportState.Done(uri, w, h) }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    export = ExportState.Error("No se pudo guardar en la galería: ${e.message}")
                }
            }
        }
    }

    fun cancelExport() {
        transformer?.cancel()
        progressJob?.cancel()
        export = ExportState.Idle
    }

    fun dismissExport() {
        export = ExportState.Idle
    }

    override fun onCleared() {
        transformer?.cancel()
        player.release()
        auditionPlayer.release()
        for (p in audioPlayers.values) p.release()
        audioPlayers.clear()
        super.onCleared()
    }

    companion object {
        const val MIN_CLIP_MS = 300L
        const val MAX_AUDIOS = 16
        const val PREVIEW_SHORT = 720
    }
}
