@file:OptIn(UnstableApi::class)

package gt.calin.clipa

import android.app.Application
import android.content.ContentValues
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.Composition
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class EditorViewModel(app: Application) : AndroidViewModel(app) {

    private val ctx = app.applicationContext

    // ---- Estado observable por la interfaz ----
    var clips by mutableStateOf<List<Clip>>(emptyList())
        private set
    var selectedClipId by mutableStateOf<Long?>(null)
        private set
    var texts by mutableStateOf<List<TextItem>>(emptyList())
        private set
    var music by mutableStateOf<MusicTrack?>(null)
        private set
    var aspect by mutableStateOf(Aspect.R9_16)
        private set
    var muteOriginal by mutableStateOf(false)
        private set
    var positionMs by mutableLongStateOf(0L)
        private set
    var playing by mutableStateOf(false)
        private set
    var export by mutableStateOf<ExportState>(ExportState.Idle)
        private set

    val totalMs: Long get() = clips.sumOf { it.lengthMs }
    val selectedClip: Clip? get() = clips.firstOrNull { it.id == selectedClipId }

    // ---- Reproductores ----
    val player: ExoPlayer = ExoPlayer.Builder(ctx).build()
    private val musicPlayer: ExoPlayer = ExoPlayer.Builder(ctx).build()

    private var nextId = 1L
    private var transformer: Transformer? = null
    private var progressJob: Job? = null

    init {
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                playing = isPlaying
                if (isPlaying) syncMusicPlay() else musicPlayer.pause()
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) {
                    musicPlayer.pause()
                    positionMs = totalMs
                }
            }
        })

        // Actualiza la posición del cabezal mientras se reproduce.
        viewModelScope.launch {
            while (true) {
                delay(33)
                if (player.isPlaying) positionMs = currentGlobalPos()
            }
        }
    }

    // ---- Utilidades de tiempo ----

    private fun currentGlobalPos(): Long {
        val list = clips
        val i = player.currentMediaItemIndex
        if (list.isEmpty() || i < 0 || i >= list.size) return 0L
        var off = 0L
        for (k in 0 until i) off += list[k].lengthMs
        return (off + player.currentPosition.coerceAtLeast(0L)).coerceAtMost(totalMs)
    }

    fun seekTo(ms: Long) {
        val list = clips
        if (list.isEmpty()) return
        val t = ms.coerceIn(0L, totalMs)
        var acc = 0L
        var idx = list.lastIndex
        var local = list.last().lengthMs
        for ((k, c) in list.withIndex()) {
            if (t < acc + c.lengthMs) {
                idx = k
                local = t - acc
                break
            }
            acc += c.lengthMs
        }
        player.seekTo(idx, local)
        positionMs = t
        if (player.isPlaying) syncMusicPlay()
    }

    fun togglePlay() {
        if (clips.isEmpty()) return
        if (player.isPlaying) {
            player.pause()
        } else {
            if (positionMs >= totalMs - 50) seekTo(0)
            player.play()
        }
    }

    private fun syncMusicPlay() {
        val m = music ?: return
        val p = currentGlobalPos()
        if (p < m.durationMs) {
            musicPlayer.volume = m.volume
            musicPlayer.seekTo(p)
            musicPlayer.play()
        } else {
            musicPlayer.pause()
        }
    }

    private fun rebuildPlayer() {
        player.pause()
        val keep = positionMs
        if (clips.isEmpty()) {
            player.clearMediaItems()
            positionMs = 0L
            return
        }
        player.setMediaItems(clips.map { it.toMediaItem() })
        player.prepare()
        seekTo(keep)
    }

    private fun toast(msg: String) {
        Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
    }

    // ---- Clips ----

    fun addVideos(uris: List<Uri>) {
        viewModelScope.launch {
            val added = withContext(Dispatchers.IO) {
                uris.mapNotNull { u ->
                    val d = probeDuration(u)
                    if (d > 0) Clip(nextId++, u, d, 0L, d) else null
                }
            }
            if (added.isEmpty()) {
                toast("No pude leer ese video")
                return@launch
            }
            clips = clips + added
            if (selectedClipId == null) selectedClipId = added.first().id
            rebuildPlayer()
        }
    }

    private fun probeDuration(uri: Uri): Long {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, uri)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } catch (e: Exception) {
            0L
        } finally {
            r.release()
        }
    }

    fun selectClip(id: Long) {
        selectedClipId = id
    }

    fun splitAtPlayhead() {
        val pos = positionMs
        var acc = 0L
        for ((i, c) in clips.withIndex()) {
            if (pos > acc + 250 && pos < acc + c.lengthMs - 250) {
                val cut = c.startMs + (pos - acc)
                val a = c.copy(endMs = cut)
                val b = c.copy(id = nextId++, startMs = cut)
                val list = clips.toMutableList()
                list[i] = a
                list.add(i + 1, b)
                clips = list
                selectedClipId = b.id
                rebuildPlayer()
                return
            }
            acc += c.lengthMs
        }
        toast("Pon el cabezal dentro de un clip para dividir")
    }

    fun deleteSelected() {
        val id = selectedClipId ?: return
        val i = clips.indexOfFirst { it.id == id }
        if (i < 0) return
        val list = clips.toMutableList()
        list.removeAt(i)
        clips = list
        selectedClipId = list.getOrNull(i)?.id ?: list.lastOrNull()?.id
        clampTexts()
        rebuildPlayer()
    }

    fun moveSelected(delta: Int) {
        val id = selectedClipId ?: return
        val i = clips.indexOfFirst { it.id == id }
        val j = i + delta
        if (i < 0 || j < 0 || j >= clips.size) return
        val list = clips.toMutableList()
        val tmp = list[i]
        list[i] = list[j]
        list[j] = tmp
        clips = list
        rebuildPlayer()
    }

    fun setTrim(id: Long, startMs: Long, endMs: Long) {
        val c = clips.firstOrNull { it.id == id } ?: return
        val s = startMs.coerceIn(0L, (c.sourceDurationMs - MIN_CLIP_MS).coerceAtLeast(0L))
        val e = endMs.coerceIn(s + MIN_CLIP_MS, c.sourceDurationMs)
        clips = clips.map { if (it.id == id) it.copy(startMs = s, endMs = e) else it }
        clampTexts()
        rebuildPlayer()
    }

    // ---- Texto ----

    private fun clampTexts() {
        val total = totalMs
        texts = texts
            .filter { it.startMs < total }
            .map { if (it.endMs > total) it.copy(endMs = total) else it }
    }

    fun addText(text: String, color: Int, sizeFrac: Float, startMs: Long, endMs: Long) {
        texts = texts + TextItem(nextId++, text, startMs, endMs, color, sizeFrac, 0.5f, 0.5f)
    }

    fun updateText(id: Long, text: String, color: Int, sizeFrac: Float, startMs: Long, endMs: Long) {
        texts = texts.map {
            if (it.id == id) it.copy(
                text = text, color = color, sizeFrac = sizeFrac, startMs = startMs, endMs = endMs
            ) else it
        }
    }

    fun removeText(id: Long) {
        texts = texts.filter { it.id != id }
    }

    fun moveText(id: Long, dx: Float, dy: Float) {
        texts = texts.map {
            if (it.id == id) it.copy(
                x = (it.x + dx).coerceIn(0.02f, 0.98f),
                y = (it.y + dy).coerceIn(0.02f, 0.98f),
            ) else it
        }
    }

    // ---- Música y audio ----

    fun setMusic(uri: Uri) {
        viewModelScope.launch {
            val (dur, name) = withContext(Dispatchers.IO) { probeDuration(uri) to displayName(uri) }
            if (dur <= 0) {
                toast("No pude leer ese audio")
                return@launch
            }
            music = MusicTrack(uri, name, dur)
            musicPlayer.setMediaItem(MediaItem.fromUri(uri))
            musicPlayer.prepare()
            musicPlayer.volume = music!!.volume
            if (player.isPlaying) syncMusicPlay()
        }
    }

    private fun displayName(uri: Uri): String {
        return try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
                ?: "Música"
        } catch (e: Exception) {
            "Música"
        }
    }

    fun removeMusic() {
        music = null
        musicPlayer.stop()
        musicPlayer.clearMediaItems()
    }

    fun setMusicVolume(v: Float) {
        val m = music ?: return
        music = m.copy(volume = v)
        musicPlayer.volume = v
    }

    fun toggleMuteOriginal() {
        muteOriginal = !muteOriginal
        player.volume = if (muteOriginal) 0f else 1f
    }

    fun setAspect(a: Aspect) {
        aspect = a
    }

    // ---- Exportar ----

    fun startExport(quality: ExportQuality) {
        if (clips.isEmpty()) return
        player.pause()
        export = ExportState.Running(0)

        val outFile = File(ctx.cacheDir, "export_${System.currentTimeMillis()}.mp4")
        val listener = object : Transformer.Listener {
            override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                saveToGallery(outFile)
            }

            override fun onError(
                composition: Composition,
                exportResult: ExportResult,
                exportException: ExportException,
            ) {
                outFile.delete()
                export = ExportState.Error(
                    "No se pudo exportar (${exportException.errorCodeName}). " +
                        "Prueba en 720p o con menos efectos."
                )
            }
        }

        val t = try {
            Exporter(ctx).start(
                clips, texts, music, muteOriginal, aspect, quality, outFile.absolutePath, listener
            )
        } catch (e: Exception) {
            export = ExportState.Error("No se pudo iniciar la exportación: ${e.message}")
            return
        }
        transformer = t

        progressJob?.cancel()
        progressJob = viewModelScope.launch {
            val holder = ProgressHolder()
            while (isActive && export is ExportState.Running) {
                if (t.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE) {
                    export = ExportState.Running(holder.progress)
                }
                delay(250)
            }
        }
    }

    private fun saveToGallery(file: File) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val resolver = ctx.contentResolver
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, "Clipa_${System.currentTimeMillis()}.mp4")
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/Clipa")
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }
                val collection = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                val uri = resolver.insert(collection, values) ?: error("No se pudo crear el archivo")
                resolver.openOutputStream(uri)?.use { out ->
                    file.inputStream().use { it.copyTo(out) }
                } ?: error("No se pudo escribir el archivo")
                values.clear()
                values.put(MediaStore.Video.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
                file.delete()
                withContext(Dispatchers.Main) { export = ExportState.Done(uri) }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    export = ExportState.Error("No se pudo guardar en la galería: ${e.message}")
                }
            }
        }
    }

    fun cancelExport() {
        transformer?.cancel()
        progressJob?.cancel()
        export = ExportState.Idle
    }

    fun dismissExport() {
        export = ExportState.Idle
    }

    override fun onCleared() {
        transformer?.cancel()
        player.release()
        musicPlayer.release()
        super.onCleared()
    }

    companion object {
        const val MIN_CLIP_MS = 300L
    }
}
