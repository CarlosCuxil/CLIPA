@file:OptIn(UnstableApi::class)

package gt.calin.clipa

import android.content.Context
import androidx.media3.common.Effect
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.ChannelMixingAudioProcessor
import androidx.media3.common.audio.ChannelMixingMatrix
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import kotlin.math.min

class ExportJob(val transformer: Transformer, val width: Int, val height: Int)

class Exporter(private val ctx: Context) {

    private fun volumeMixer(v: Float): AudioProcessor {
        val mixer = ChannelMixingAudioProcessor()
        mixer.putChannelMixingMatrix(ChannelMixingMatrix.create(1, 2).scaleBy(v))
        mixer.putChannelMixingMatrix(ChannelMixingMatrix.create(2, 2).scaleBy(v))
        return mixer
    }

    /** Arma la composición y arranca la exportación. Debe llamarse desde el hilo principal. */
    fun start(
        project: Project,
        quality: ExportQuality,
        outPath: String,
        listener: Transformer.Listener,
    ): ExportJob {
        val (w, h) = project.aspect.sizeFor(quality.shortSide)
        val totalMs = project.totalMs

        val videoItems = project.clips.map { c ->
            val audioProcs: List<AudioProcessor> =
                if (!project.muteOriginal && c.volume < 0.999f) listOf(volumeMixer(c.volume)) else emptyList()
            EditedMediaItem.Builder(c.toMediaItem())
                .setRemoveAudio(project.muteOriginal)
                .setEffects(Effects(audioProcs, FxEngine.effects(c.look, w, h)))
                .build()
        }

        val sequences = mutableListOf(EditedMediaItemSequence.Builder(videoItems).build())

        for (a in project.audios) {
            val room = totalMs - a.startMs
            if (room <= 50L) continue
            val len = min(a.lengthMs, room)
            val item = EditedMediaItem.Builder(a.toMediaItem(len))
                .setRemoveVideo(true)
                .setEffects(Effects(listOf(volumeMixer(a.volume)), emptyList<Effect>()))
                .build()
            val sb = EditedMediaItemSequence.Builder()
            if (a.startMs > 0L) sb.addGap(a.startMs * 1000L)
            sb.addItem(item)
            sequences.add(sb.build())
        }

        val compositionBuilder = Composition.Builder(sequences)

        val visible = project.texts.filter {
            it.startMs < totalMs && (it.sticker || it.text.isNotBlank())
        }
        if (visible.isNotEmpty()) {
            val overlay = TimedTextOverlay.create(visible, w, h)
            compositionBuilder.setEffects(
                Effects(
                    emptyList(),
                    listOf<Effect>(OverlayEffect(listOf<TextureOverlay>(overlay))),
                )
            )
        }

        val encoderFactory = DefaultEncoderFactory.Builder(ctx)
            .setRequestedVideoEncoderSettings(
                VideoEncoderSettings.Builder().setBitrate(quality.bitrate).build()
            )
            .build()

        val transformer = Transformer.Builder(ctx)
            .setVideoMimeType(if (quality.hevc) MimeTypes.VIDEO_H265 else MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .setEncoderFactory(encoderFactory)
            .addListener(listener)
            .build()

        transformer.start(compositionBuilder.build(), outPath)
        return ExportJob(transformer, w, h)
    }
}
