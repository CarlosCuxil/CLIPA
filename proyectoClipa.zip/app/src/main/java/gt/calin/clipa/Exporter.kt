@file:OptIn(UnstableApi::class)

package gt.calin.clipa

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.ChannelMixingAudioProcessor
import androidx.media3.common.audio.ChannelMixingMatrix
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.Presentation
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings

/**
 * Dibuja los textos que estén activos en cada instante sobre un cuadro transparente
 * del mismo tamaño que el video exportado.
 */
class TimedTextOverlay(
    private val texts: List<TextItem>,
    private val width: Int,
    private val height: Int,
) : BitmapOverlay() {

    private val blank: Bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    private var cacheKey: String? = null
    private var cacheBitmap: Bitmap = blank

    override fun getBitmap(presentationTimeUs: Long): Bitmap {
        val tMs = presentationTimeUs / 1000
        val active = texts.filter { tMs >= it.startMs && tMs < it.endMs }
        if (active.isEmpty()) return blank
        val key = active.joinToString(",") { it.id.toString() }
        if (key == cacheKey) return cacheBitmap

        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        for (t in active) drawText(canvas, t)
        cacheKey = key
        cacheBitmap = bmp
        return bmp
    }

    private fun drawText(canvas: Canvas, t: TextItem) {
        val size = t.sizeFrac * height
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = t.color
            textSize = size
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            setShadowLayer(size * 0.08f, 0f, size * 0.04f, 0xFF000000.toInt())
        }
        val lines = t.text.split("\n")
        val lineH = paint.fontSpacing
        val top = t.y * height - lines.size * lineH / 2f
        for ((i, line) in lines.withIndex()) {
            val baseline = top + i * lineH - paint.ascent()
            canvas.drawText(line, t.x * width, baseline, paint)
        }
    }
}

class Exporter(private val ctx: Context) {

    /** Arma la composición y arranca la exportación. Debe llamarse desde el hilo principal. */
    fun start(
        clips: List<Clip>,
        texts: List<TextItem>,
        music: MusicTrack?,
        muteOriginal: Boolean,
        aspect: Aspect,
        quality: ExportQuality,
        outPath: String,
        listener: Transformer.Listener,
    ): Transformer {
        val (w, h) = aspect.sizeFor(quality.shortSide)
        val totalMs = clips.sumOf { it.lengthMs }

        val presentation = Presentation.createForWidthAndHeight(w, h, Presentation.LAYOUT_SCALE_TO_FIT)

        val videoItems = clips.map { c ->
            EditedMediaItem.Builder(c.toMediaItem())
                .setRemoveAudio(muteOriginal)
                .setEffects(Effects(emptyList(), listOf<Effect>(presentation)))
                .build()
        }

        val sequences = mutableListOf(EditedMediaItemSequence.Builder(videoItems).build())

        if (music != null) {
            val clipping = MediaItem.ClippingConfiguration.Builder().setStartPositionMs(0)
            if (music.durationMs > totalMs) clipping.setEndPositionMs(totalMs)
            val musicMediaItem = MediaItem.Builder()
                .setUri(music.uri)
                .setClippingConfiguration(clipping.build())
                .build()

            val mixer = ChannelMixingAudioProcessor()
            mixer.putChannelMixingMatrix(ChannelMixingMatrix.create(1, 2).scaleBy(music.volume))
            mixer.putChannelMixingMatrix(ChannelMixingMatrix.create(2, 2).scaleBy(music.volume))

            val audioItem = EditedMediaItem.Builder(musicMediaItem)
                .setRemoveVideo(true)
                .setEffects(Effects(listOf<AudioProcessor>(mixer), emptyList()))
                .build()
            sequences.add(EditedMediaItemSequence.Builder(audioItem).build())
        }

        val compositionBuilder = Composition.Builder(sequences)

        val visibleTexts = texts.filter { it.startMs < totalMs && it.text.isNotBlank() }
        if (visibleTexts.isNotEmpty()) {
            val overlay = TimedTextOverlay(visibleTexts, w, h)
            compositionBuilder.setEffects(
                Effects(
                    emptyList(),
                    listOf<Effect>(OverlayEffect(listOf<TextureOverlay>(overlay))),
                )
            )
        }

        val encoderFactory = DefaultEncoderFactory.Builder(ctx)
            .setRequestedVideoEncoderSettings(
                VideoEncoderSettings.Builder().setBitrate(quality.bitrate).build()
            )
            .build()

        val transformer = Transformer.Builder(ctx)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .setEncoderFactory(encoderFactory)
            .addListener(listener)
            .build()

        transformer.start(compositionBuilder.build(), outPath)
        return transformer
    }
}
