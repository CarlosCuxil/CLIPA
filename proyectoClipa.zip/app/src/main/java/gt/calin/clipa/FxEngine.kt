@file:OptIn(UnstableApi::class)

package gt.calin.clipa

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import androidx.media3.common.Effect
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.GaussianBlur
import androidx.media3.effect.MatrixTransformation
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.Presentation
import androidx.media3.effect.RgbMatrix
import androidx.media3.effect.ScaleAndRotateTransformation
import androidx.media3.effect.SingleColorLut
import androidx.media3.effect.TextureOverlay
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Overlay hecho de un bitmap pequeño que se estira para cubrir todo el cuadro.
 * Así los textos y capas no gastan memoria de más en 2K/4K.
 */
abstract class ScaledBitmapOverlay(
    frameW: Int,
    frameH: Int,
    protected val bw: Int,
    protected val bh: Int,
) : BitmapOverlay() {
    private val settings: OverlaySettings = OverlaySettings.Builder()
        .setScale(frameW.toFloat() / bw, frameH.toFloat() / bh)
        .build()

    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings = settings
}

/** Textos y pegatinas del proyecto, dibujados sobre un cuadro transparente. */
class TimedTextOverlay(
    private val items: List<TextItem>,
    private val frameW: Int,
    private val frameH: Int,
    bw: Int,
    bh: Int,
) : ScaledBitmapOverlay(frameW, frameH, bw, bh) {

    private val blank: Bitmap = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
    private var cacheKey: String? = null
    private var cacheBitmap: Bitmap = blank

    override fun getBitmap(presentationTimeUs: Long): Bitmap {
        val tMs = presentationTimeUs / 1000
        val active = items.filter { tMs >= it.startMs && tMs < it.endMs }
        if (active.isEmpty()) return blank
        val key = active.joinToString(",") { it.id.toString() }
        if (key == cacheKey) return cacheBitmap

        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        canvas.scale(bw.toFloat() / frameW, bh.toFloat() / frameH)
        for (t in active) TextRenderer.draw(canvas, t, frameW.toFloat(), frameH.toFloat())
        cacheKey = key
        cacheBitmap = bmp
        return bmp
    }

    companion object {
        /** Tamaño del bitmap de texto: lado corto máximo 1440 px. */
        fun create(items: List<TextItem>, w: Int, h: Int): TimedTextOverlay {
            val s = min(1f, 1440f / min(w, h))
            val bw = max(16, (w * s).toInt())
            val bh = max(16, (h * s).toInt())
            return TimedTextOverlay(items, w, h, bw, bh)
        }
    }
}

/** Capas visuales del look: viñeta, barras de cine, marco, luz, VHS y grano. */
class LookOverlay(
    private val look: Look,
    frameW: Int,
    frameH: Int,
    bw: Int,
    bh: Int,
) : ScaledBitmapOverlay(frameW, frameH, bw, bh) {

    private val animated = look.fx == Fx.VHS || look.fx == Fx.GRAIN || look.fx == Fx.LEAK
    private val bufA: Bitmap = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
    private val bufB: Bitmap = if (animated) Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888) else bufA
    private var current: Bitmap = bufA
    private var lastBucket = Long.MIN_VALUE
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val noisePixels = IntArray(bw * bh)

    override fun getBitmap(presentationTimeUs: Long): Bitmap {
        val bucket = if (animated) presentationTimeUs / 83_333L else 0L
        if (bucket == lastBucket) return current
        lastBucket = bucket

        val target = if (!animated) bufA else if (current === bufA) bufB else bufA
        target.eraseColor(0)
        val canvas = Canvas(target)
        paintLayers(canvas, presentationTimeUs / 1_000_000.0, bucket)
        current = target
        return target
    }

    private fun paintLayers(c: Canvas, t: Double, bucket: Long) {
        val w = bw.toFloat()
        val h = bh.toFloat()
        val a = look.fxAmount

        if (look.vignette > 0f) {
            val r = hypot(w, h) / 2f
            val alpha = (look.vignette * 215f).toInt().coerceIn(0, 255)
            paint.shader = RadialGradient(
                w / 2f, h / 2f, r,
                intArrayOf(0x00000000, 0x00000000, alpha shl 24),
                floatArrayOf(0f, 0.45f, 1f),
                Shader.TileMode.CLAMP,
            )
            c.drawRect(0f, 0f, w, h, paint)
            paint.shader = null
        }

        when (look.fx) {
            Fx.BARS -> {
                val visibleH = min(h, w / 2.35f)
                val bar = (h - visibleH) / 2f
                paint.color = 0xFF000000.toInt()
                if (bar > 0.5f) {
                    c.drawRect(0f, 0f, w, bar, paint)
                    c.drawRect(0f, h - bar, w, h, paint)
                } else {
                    // Cuadro más ancho que 2.35:1: barras a los lados.
                    val visibleW = min(w, h * 2.35f)
                    val side = (w - visibleW) / 2f
                    c.drawRect(0f, 0f, side, h, paint)
                    c.drawRect(w - side, 0f, w, h, paint)
                }
            }
            Fx.FRAME -> {
                val m = min(w, h) * (0.025f + 0.04f * a)
                paint.color = 0xFFFFFFFF.toInt()
                c.drawRect(0f, 0f, w, m, paint)
                c.drawRect(0f, 0f, m, h, paint)
                c.drawRect(w - m, 0f, w, h, paint)
                c.drawRect(0f, h - m * 2.4f, w, h, paint)
            }
            Fx.LEAK -> {
                val cx = w * (0.15f + 0.7f * (0.5f + 0.5f * sin(t * 0.7).toFloat()))
                val cy = h * (0.1f + 0.15f * sin(t * 0.43).toFloat())
                val pulse = 0.65f + 0.35f * sin(t * 1.9).toFloat()
                val alpha = (a * 170f * pulse).toInt().coerceIn(0, 255)
                paint.shader = RadialGradient(
                    cx, cy, max(w, h) * 0.85f,
                    intArrayOf((alpha shl 24) or 0xFF7A2E, ((alpha / 2) shl 24) or 0xFF2E7A, 0x00FF2E7A),
                    floatArrayOf(0f, 0.45f, 1f),
                    Shader.TileMode.CLAMP,
                )
                c.drawRect(0f, 0f, w, h, paint)
                paint.shader = null
            }
            Fx.VHS -> {
                // Líneas de barrido
                paint.color = ((50 * (0.4f + a * 0.6f)).toInt() shl 24)
                var y = 0f
                while (y < h) {
                    c.drawRect(0f, y, w, y + 1.2f, paint)
                    y += 4f
                }
                // Franjas de color en los bordes
                paint.color = ((60 * a).toInt() shl 24) or 0xFF2040
                c.drawRect(0f, 0f, w * 0.012f, h, paint)
                paint.color = ((60 * a).toInt() shl 24) or 0x20E0FF
                c.drawRect(w * 0.988f, 0f, w, h, paint)
                // Banda de seguimiento que sube
                val bandY = (1.0 - (t * 0.22) % 1.0).toFloat() * h
                paint.shader = LinearGradient(
                    0f, bandY - h * 0.05f, 0f, bandY + h * 0.05f,
                    intArrayOf(0x00FFFFFF, ((70 * a).toInt() shl 24) or 0xFFFFFF, 0x00FFFFFF),
                    floatArrayOf(0f, 0.5f, 1f),
                    Shader.TileMode.CLAMP,
                )
                c.drawRect(0f, bandY - h * 0.05f, w, bandY + h * 0.05f, paint)
                paint.shader = null
                // Ruido
                noise(c, bucket, (45 * a).toInt())
            }
            Fx.GRAIN -> noise(c, bucket, (20 + 70 * a).toInt())
            else -> {}
        }
    }

    private fun noise(c: Canvas, seed: Long, alpha: Int) {
        var s = (seed * 2654435761L + 12345L).toInt() or 1
        val px = noisePixels
        val a = alpha.coerceIn(0, 255) shl 24
        for (i in px.indices) {
            s = s xor (s shl 13)
            s = s xor (s ushr 17)
            s = s xor (s shl 5)
            val g = (s ushr 8) and 255
            px[i] = a or (g shl 16) or (g shl 8) or g
        }
        val tmp = Bitmap.createBitmap(px, bw, bh, Bitmap.Config.ARGB_8888)
        c.drawBitmap(tmp, 0f, 0f, null)
        tmp.recycle()
    }

    companion object {
        /** Lado corto del bitmap de capas. Igual en vista previa y exportación. */
        private const val SHORT = 540f

        fun create(look: Look, w: Int, h: Int): LookOverlay {
            val s = min(1f, SHORT / min(w, h))
            val bw = max(16, (w * s).toInt())
            val bh = max(16, (h * s).toInt())
            return LookOverlay(look, w, h, bw, bh)
        }
    }
}

object FxEngine {

    fun needsOverlay(look: Look): Boolean =
        look.vignette > 0f || look.fx == Fx.VHS || look.fx == Fx.GRAIN ||
            look.fx == Fx.BARS || look.fx == Fx.LEAK || look.fx == Fx.FRAME

    private fun hash01(n: Long): Float {
        val v = sin(n * 12.9898) * 43758.5453
        return (v - floor(v)).toFloat()
    }

    private fun uniform(s: Float, dx: Float, dy: Float): Matrix {
        val m = Matrix()
        m.setScale(s, s)
        m.postTranslate(dx, dy)
        return m
    }

    private fun colMajor(m: Array<FloatArray>): FloatArray {
        val out = FloatArray(16)
        for (r in 0 until 4) for (c in 0 until 4) out[c * 4 + r] = m[r][c]
        return out
    }

    private fun gainMatrix(g: Float): FloatArray = colMajor(
        arrayOf(
            floatArrayOf(g, 0f, 0f, 0f),
            floatArrayOf(0f, g, 0f, 0f),
            floatArrayOf(0f, 0f, g, 0f),
            floatArrayOf(0f, 0f, 0f, 1f),
        )
    )

    private fun tintMatrix(r: Float, g: Float, b: Float): FloatArray = colMajor(
        arrayOf(
            floatArrayOf(r, 0f, 0f, 0f),
            floatArrayOf(0f, g, 0f, 0f),
            floatArrayOf(0f, 0f, b, 0f),
            floatArrayOf(0f, 0f, 0f, 1f),
        )
    )

    private fun hueMatrix(angle: Double, amount: Float): FloatArray {
        val c = cos(angle).toFloat()
        val s = sin(angle).toFloat()
        val rot = arrayOf(
            floatArrayOf(0.213f + 0.787f * c - 0.213f * s, 0.715f - 0.715f * c - 0.715f * s, 0.072f - 0.072f * c + 0.928f * s, 0f),
            floatArrayOf(0.213f - 0.213f * c + 0.143f * s, 0.715f + 0.285f * c + 0.140f * s, 0.072f - 0.072f * c - 0.283f * s, 0f),
            floatArrayOf(0.213f - 0.213f * c - 0.787f * s, 0.715f - 0.715f * c + 0.715f * s, 0.072f + 0.928f * c + 0.072f * s, 0f),
            floatArrayOf(0f, 0f, 0f, 1f),
        )
        val m = Array(4) { FloatArray(4) }
        for (r in 0 until 4) for (k in 0 until 4) {
            val ident = if (r == k) 1f else 0f
            m[r][k] = ident + amount * (rot[r][k] - ident)
        }
        return colMajor(m)
    }

    /**
     * Efectos de video de un clip, en el orden correcto, terminando en el ajuste al lienzo.
     * Se usa igual para la vista previa y para exportar.
     */
    fun effects(look: Look, canvasW: Int, canvasH: Int): List<Effect> {
        val list = ArrayList<Effect>()
        val a = look.fxAmount

        if (look.rotation % 360 != 0) {
            list.add(
                ScaleAndRotateTransformation.Builder()
                    .setRotationDegrees(look.rotation.toFloat())
                    .build()
            )
        }
        if (look.mirror) {
            list.add(ScaleAndRotateTransformation.Builder().setScale(-1f, 1f).build())
        }

        val cube = ColorLab.buildCube(look)
        if (cube != null) list.add(SingleColorLut.createFromCube(cube))

        when (look.fx) {
            Fx.PULSE -> list.add(MatrixTransformation { us ->
                val t = us / 1_000_000.0
                val ph = (t * 2.0) % 1.0
                val s = 1f + 0.16f * a * exp(-ph * 5.0).toFloat()
                uniform(s, 0f, 0f)
            })
            Fx.BREATH -> list.add(MatrixTransformation { us ->
                val t = us / 1_000_000.0
                val s = 1f + 0.12f * a * (0.5f + 0.5f * sin(2 * PI * t / 3.2).toFloat())
                uniform(s, 0f, 0f)
            })
            Fx.SHAKE -> list.add(MatrixTransformation { us ->
                val t = us / 1_000_000.0
                val dx = (0.028f * a * sin(t * 47.0)).toFloat()
                val dy = (0.022f * a * sin(t * 61.0 + 1.0)).toFloat()
                uniform(1f + 0.07f * a, dx, dy)
            })
            Fx.GLITCH -> {
                list.add(MatrixTransformation { us ->
                    val k = (us / 1_000_000.0 * 7.0).toLong()
                    if (hash01(k) < 0.15f + 0.45f * a) {
                        val dx = (hash01(k + 101) - 0.5f) * 0.22f * a
                        val dy = (hash01(k + 202) - 0.5f) * 0.05f * a
                        uniform(1.08f, dx, dy)
                    } else {
                        Matrix()
                    }
                })
                list.add(RgbMatrix { us, _ ->
                    val k = (us / 1_000_000.0 * 7.0).toLong()
                    if (hash01(k) < 0.15f + 0.45f * a) {
                        tintMatrix(1f + 0.5f * a, 1f - 0.35f * a, 1f + 0.4f * a)
                    } else {
                        tintMatrix(1f, 1f, 1f)
                    }
                })
            }
            Fx.FLASH -> list.add(RgbMatrix { us, _ ->
                val t = us / 1_000_000.0
                val ph = (t * 2.0) % 1.0
                gainMatrix(1f + 1.4f * a * exp(-ph * 8.0).toFloat())
            })
            Fx.DISCO -> list.add(RgbMatrix { us, _ ->
                val t = us / 1_000_000.0
                hueMatrix(t * 2 * PI * 0.9, a)
            })
            else -> {}
        }

        list.add(
            Presentation.createForWidthAndHeight(
                canvasW,
                canvasH,
                if (look.fill) Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP else Presentation.LAYOUT_SCALE_TO_FIT,
            )
        )

        if (look.fx == Fx.BLUR) {
            val sigma = max(0.8f, a * 12f * min(canvasW, canvasH) / 1080f)
            list.add(GaussianBlur(sigma))
        }

        if (needsOverlay(look)) {
            list.add(OverlayEffect(listOf<TextureOverlay>(LookOverlay.create(look, canvasW, canvasH))))
        }
        return list
    }
}
