package gt.calin.clipa

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun HomeScreen(vm: EditorViewModel, onEnter: () -> Unit) {
    var showPaywall by remember { mutableStateOf(false) }

    val pick = rememberLauncherForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(30)
    ) { uris ->
        if (uris.isNotEmpty()) {
            vm.newProject()
            vm.addVideos(uris)
            onEnter()
        }
    }
    val startNew: () -> Unit = {
        pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF1A1036), Pal.Bg), endY = 1400f))
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 14.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Clipa",
                    style = TextStyle(
                        brush = Pal.Brand,
                        fontSize = 34.sp,
                        fontWeight = FontWeight.ExtraBold,
                    ),
                    modifier = Modifier.weight(1f),
                )
                if (vm.isPro) {
                    ProBadge()
                } else {
                    Row(
                        Modifier
                            .clip(RoundedCornerShape(50))
                            .background(Pal.GoldBrush)
                            .tap { showPaywall = true }
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Glyph(Ic.Crown, Color.Black, size = 16.dp)
                        Spacer(Modifier.width(6.dp))
                        Text("Obtener PRO", color = Color.Black, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
                    }
                }
            }
            Text(
                "Edita como un pro, desde tu cel.",
                color = Pal.Muted,
                fontSize = 14.sp,
                modifier = Modifier.padding(top = 2.dp),
            )

            Spacer(Modifier.height(22.dp))

            // Tarjeta principal
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(170.dp)
                    .clip(RoundedCornerShape(28.dp))
                    .background(Pal.BrandDiagonal)
                    .tap(onClick = startNew)
                    .padding(22.dp)
            ) {
                Column(Modifier.align(Alignment.CenterStart)) {
                    Text("Nuevo proyecto", color = Color.Black, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Importa tus videos y empieza a crear",
                        color = Color(0xCC000000),
                        fontSize = 14.sp,
                    )
                }
                Box(
                    Modifier
                        .align(Alignment.BottomEnd)
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(Color.Black),
                    contentAlignment = Alignment.Center,
                ) {
                    Glyph(Ic.Plus, Color.White, size = 28.dp)
                }
            }

            if (vm.clips.isNotEmpty()) {
                Spacer(Modifier.height(14.dp))
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(Pal.Surface2)
                        .border(1.dp, Pal.Line, RoundedCornerShape(20.dp))
                        .tap(onClick = onEnter)
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(
                        Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Pal.Surface3),
                        contentAlignment = Alignment.Center,
                    ) {
                        Glyph(Ic.Video, Pal.Accent, size = 24.dp)
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Continuar proyecto", color = Pal.Text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Text(
                            "${vm.clips.size} clips  ·  ${formatTime(vm.totalMs)}",
                            color = Pal.Muted,
                            fontSize = 12.sp,
                        )
                    }
                    Glyph(Ic.ArrowRight, Pal.Muted, size = 22.dp)
                }
            }

            Spacer(Modifier.height(26.dp))
            Text("Todo lo que incluye", color = Pal.Text, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))

            val stickers = Library.stickerPacks.sumOf { it.items.size }
            val tiles = listOf(
                Triple(Ic.Video, "4K Ultra HD", "Exporta hasta 2160p"),
                Triple(Ic.Filter, "${Filter.entries.size - 1} filtros", "Looks de cine y más"),
                Triple(Ic.Fx, "${Fx.entries.size - 1} efectos", "Glitch, VHS, luces…"),
                Triple(Ic.Music, "${SoundLab.all.size} sonidos", "Música y efectos"),
                Triple(Ic.Text, "Textos pro", "${TextStyleKind.entries.size} estilos, ${TextFont.entries.size} fuentes"),
                Triple(Ic.Sticker, "Pegatinas", "$stickers emojis"),
            )
            for (row in tiles.chunked(2)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    for (t in row) {
                        FeatureTile(t.first, t.second, t.third, Modifier.weight(1f))
                    }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
                Spacer(Modifier.height(12.dp))
            }

            if (!vm.isPro) {
                Spacer(Modifier.height(6.dp))
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(22.dp))
                        .background(Pal.Surface2)
                        .border(1.5.dp, Pal.Gold, RoundedCornerShape(22.dp))
                        .tap { showPaywall = true }
                        .padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(
                        Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(Pal.GoldBrush),
                        contentAlignment = Alignment.Center,
                    ) {
                        Glyph(Ic.Crown, Color.Black, size = 26.dp)
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Clipa PRO", color = Pal.Gold, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
                        Text(
                            "4K, efectos y sonidos premium",
                            color = Pal.Muted,
                            fontSize = 12.sp,
                        )
                    }
                    Glyph(Ic.ArrowRight, Pal.Gold, size = 22.dp)
                }
            }
            Spacer(Modifier.height(20.dp))
        }
    }

    if (showPaywall) {
        PaywallDialog(
            onDismiss = { showPaywall = false },
            onActivate = {
                vm.changePro(true)
                showPaywall = false
            },
        )
    }
}

@Composable
private fun FeatureTile(ic: Ic, title: String, subtitle: String, modifier: Modifier = Modifier) {
    Row(
        modifier
            .clip(RoundedCornerShape(18.dp))
            .background(Pal.Surface2)
            .border(1.dp, Pal.Line, RoundedCornerShape(18.dp))
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(38.dp)
                .clip(RoundedCornerShape(11.dp))
                .background(Pal.Surface3),
            contentAlignment = Alignment.Center,
        ) {
            Glyph(ic, Pal.Accent, size = 22.dp)
        }
        Spacer(Modifier.width(10.dp))
        Column {
            Text(title, color = Pal.Text, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Text(subtitle, color = Pal.Muted, fontSize = 11.sp, maxLines = 1)
        }
    }
}
