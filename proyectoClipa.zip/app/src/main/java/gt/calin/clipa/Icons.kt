package gt.calin.clipa

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.cos
import kotlin.math.sin

/** Íconos propios de Clipa, dibujados con trazos (sin librerías externas). */
enum class Ic {
    Back, Close, Check, Plus, Undo, Redo, Play, Pause, Scissors, Trash, Copy,
    ArrowLeft, ArrowRight, Volume, Mute, Rotate, Mirror, Text, Sticker, Music,
    Fx, Filter, Adjust, Format, Export, Crown, Share, Wave, Crop, Pencil,
    Folder, Home, Video, Info, Lock
}

@Composable
fun Glyph(ic: Ic, tint: Color, modifier: Modifier = Modifier, size: Dp = 24.dp) {
    Canvas(modifier.size(size)) {
        drawGlyph(ic, tint, this.size.minDimension)
    }
}

fun DrawScope.drawGlyph(ic: Ic, tint: Color, sizePx: Float) {
    val s = sizePx / 24f
    val stroke = Stroke(width = 1.9f * s, cap = StrokeCap.Round, join = StrokeJoin.Round)

    fun o(x: Float, y: Float) = Offset(x * s, y * s)

    fun line(x1: Float, y1: Float, x2: Float, y2: Float) {
        drawLine(tint, o(x1, y1), o(x2, y2), strokeWidth = stroke.width, cap = StrokeCap.Round)
    }

    fun poly(close: Boolean, fill: Boolean, vararg pts: Float) {
        val p = Path()
        p.moveTo(pts[0] * s, pts[1] * s)
        var i = 2
        while (i < pts.size) {
            p.lineTo(pts[i] * s, pts[i + 1] * s)
            i += 2
        }
        if (close) p.close()
        drawPath(p, tint, style = if (fill) Fill else stroke)
    }

    fun circle(cx: Float, cy: Float, r: Float, fill: Boolean) {
        drawCircle(tint, r * s, o(cx, cy), style = if (fill) Fill else stroke)
    }

    fun rrect(l: Float, t: Float, r: Float, b: Float, rad: Float, fill: Boolean) {
        drawRoundRect(
            tint, o(l, t), Size((r - l) * s, (b - t) * s), CornerRadius(rad * s, rad * s),
            style = if (fill) Fill else stroke,
        )
    }

    fun star(cx: Float, cy: Float, r: Float) {
        val p = Path()
        p.moveTo(cx * s, (cy - r) * s)
        p.quadraticTo(cx * s, cy * s, (cx + r) * s, cy * s)
        p.quadraticTo(cx * s, cy * s, cx * s, (cy + r) * s)
        p.quadraticTo(cx * s, cy * s, (cx - r) * s, cy * s)
        p.quadraticTo(cx * s, cy * s, cx * s, (cy - r) * s)
        p.close()
        drawPath(p, tint, style = Fill)
    }

    fun undoShape() {
        poly(false, false, 8f, 5f, 4f, 9f, 8f, 13f)
        val p = Path()
        p.moveTo(4f * s, 9f * s)
        p.lineTo(13f * s, 9f * s)
        p.cubicTo(18f * s, 9f * s, 20f * s, 12f * s, 20f * s, 15f * s)
        p.cubicTo(20f * s, 18f * s, 18f * s, 19f * s, 15f * s, 19f * s)
        p.lineTo(9f * s, 19f * s)
        drawPath(p, tint, style = stroke)
    }

    fun speaker() {
        poly(true, false, 4f, 10f, 8f, 10f, 13f, 6f, 13f, 18f, 8f, 14f, 4f, 14f)
    }

    when (ic) {
        Ic.Back -> poly(false, false, 15f, 5f, 8f, 12f, 15f, 19f)
        Ic.Close -> {
            line(6f, 6f, 18f, 18f)
            line(18f, 6f, 6f, 18f)
        }
        Ic.Check -> poly(false, false, 5f, 12.5f, 10f, 17.5f, 19f, 7f)
        Ic.Plus -> {
            line(12f, 5f, 12f, 19f)
            line(5f, 12f, 19f, 12f)
        }
        Ic.Undo -> undoShape()
        Ic.Redo -> scale(-1f, 1f, pivot = Offset(sizePx / 2f, sizePx / 2f)) { undoShape() }
        Ic.Play -> {
            poly(true, true, 8f, 5f, 19f, 12f, 8f, 19f)
            poly(true, false, 8f, 5f, 19f, 12f, 8f, 19f)
        }
        Ic.Pause -> {
            rrect(6.5f, 5f, 10.5f, 19f, 1.2f, true)
            rrect(13.5f, 5f, 17.5f, 19f, 1.2f, true)
        }
        Ic.Scissors -> {
            circle(7f, 17f, 2.6f, false)
            circle(17f, 17f, 2.6f, false)
            line(8.8f, 15.2f, 18f, 4f)
            line(15.2f, 15.2f, 6f, 4f)
        }
        Ic.Trash -> {
            line(5f, 7f, 19f, 7f)
            poly(false, false, 9f, 7f, 9f, 5f, 15f, 5f, 15f, 7f)
            poly(false, false, 7f, 7f, 8f, 19f, 16f, 19f, 17f, 7f)
            line(10f, 11f, 10f, 16f)
            line(14f, 11f, 14f, 16f)
        }
        Ic.Copy -> {
            rrect(9f, 9f, 19f, 19f, 2.2f, false)
            poly(false, false, 15f, 5f, 5f, 5f, 5f, 15f)
        }
        Ic.ArrowLeft -> {
            line(5f, 12f, 19f, 12f)
            poly(false, false, 11f, 6f, 5f, 12f, 11f, 18f)
        }
        Ic.ArrowRight -> {
            line(5f, 12f, 19f, 12f)
            poly(false, false, 13f, 6f, 19f, 12f, 13f, 18f)
        }
        Ic.Volume -> {
            speaker()
            val p = Path()
            p.moveTo(16f * s, 9f * s)
            p.cubicTo(18f * s, 10.5f * s, 18f * s, 13.5f * s, 16f * s, 15f * s)
            p.moveTo(18.5f * s, 6.5f * s)
            p.cubicTo(22f * s, 10f * s, 22f * s, 14f * s, 18.5f * s, 17.5f * s)
            drawPath(p, tint, style = stroke)
        }
        Ic.Mute -> {
            speaker()
            line(16f, 9f, 21f, 15f)
            line(21f, 9f, 16f, 15f)
        }
        Ic.Rotate -> {
            val cx = 12f
            val cy = 12f
            val r = 7f
            drawArc(
                tint, 30f, 280f, false,
                o(cx - r, cy - r), Size(2 * r * s, 2 * r * s), style = stroke,
            )
            // punta de flecha al final del arco (ángulo 310°)
            val ang = Math.toRadians(310.0)
            val ex = cx + r * cos(ang).toFloat()
            val ey = cy + r * sin(ang).toFloat()
            val dx = -sin(ang).toFloat()
            val dy = cos(ang).toFloat()
            val px = dy
            val py = -dx
            val tipX = ex + dx * 3f
            val tipY = ey + dy * 3f
            poly(
                false, false,
                ex + px * 3f, ey + py * 3f, tipX, tipY, ex - px * 3f, ey - py * 3f,
            )
        }
        Ic.Mirror -> {
            line(12f, 3.5f, 12f, 20.5f)
            poly(true, false, 9.5f, 7f, 3.5f, 17f, 9.5f, 17f)
            poly(true, true, 14.5f, 7f, 20.5f, 17f, 14.5f, 17f)
        }
        Ic.Text -> {
            line(5f, 6f, 19f, 6f)
            line(12f, 6f, 12f, 19f)
            line(9f, 19f, 15f, 19f)
        }
        Ic.Sticker -> {
            circle(12f, 12f, 8.2f, false)
            circle(9.2f, 10.5f, 1.1f, true)
            circle(14.8f, 10.5f, 1.1f, true)
            drawArc(tint, 25f, 130f, false, o(8f, 9f), Size(8f * s, 8f * s), style = stroke)
        }
        Ic.Music -> {
            circle(7.5f, 17f, 2.6f, true)
            circle(15.5f, 15f, 2.6f, true)
            line(10.1f, 17f, 10.1f, 6f)
            line(18.1f, 15f, 18.1f, 4f)
            line(10.1f, 6f, 18.1f, 4f)
        }
        Ic.Fx -> {
            star(10f, 11f, 7f)
            star(18.5f, 5.5f, 3f)
            star(18f, 18f, 3.4f)
        }
        Ic.Filter -> {
            circle(9.2f, 10f, 5.4f, false)
            circle(14.8f, 10f, 5.4f, false)
            circle(12f, 15f, 5.4f, false)
        }
        Ic.Adjust -> {
            line(4f, 7f, 20f, 7f)
            line(4f, 12f, 20f, 12f)
            line(4f, 17f, 20f, 17f)
            circle(9f, 7f, 2.3f, true)
            circle(15f, 12f, 2.3f, true)
            circle(8f, 17f, 2.3f, true)
        }
        Ic.Format -> {
            rrect(3.5f, 6f, 20.5f, 18f, 2.5f, false)
            rrect(8f, 9.2f, 16f, 14.8f, 1.2f, false)
        }
        Ic.Export -> {
            line(12f, 15f, 12f, 4f)
            poly(false, false, 7.5f, 8.5f, 12f, 4f, 16.5f, 8.5f)
            poly(false, false, 5f, 14f, 5f, 19f, 19f, 19f, 19f, 14f)
        }
        Ic.Crown -> {
            poly(true, true, 4f, 17f, 4f, 8f, 8.5f, 12f, 12f, 6f, 15.5f, 12f, 20f, 8f, 20f, 17f)
            line(4f, 19.8f, 20f, 19.8f)
        }
        Ic.Share -> {
            circle(6f, 12f, 2.6f, false)
            circle(18f, 6f, 2.6f, false)
            circle(18f, 18f, 2.6f, false)
            line(8.3f, 10.8f, 15.7f, 7.2f)
            line(8.3f, 13.2f, 15.7f, 16.8f)
        }
        Ic.Wave -> {
            line(4f, 10f, 4f, 14f)
            line(8f, 6f, 8f, 18f)
            line(12f, 3.5f, 12f, 20.5f)
            line(16f, 7f, 16f, 17f)
            line(20f, 10f, 20f, 14f)
        }
        Ic.Crop -> {
            poly(false, false, 7f, 3f, 7f, 17f, 21f, 17f)
            poly(false, false, 3f, 7f, 17f, 7f, 17f, 21f)
        }
        Ic.Pencil -> {
            poly(true, false, 4f, 20f, 5f, 15f, 15f, 5f, 19f, 9f, 9f, 19f)
            line(13f, 7f, 17f, 11f)
        }
        Ic.Folder -> {
            poly(true, false, 3.5f, 7f, 3.5f, 18f, 20.5f, 18f, 20.5f, 9f, 11f, 9f, 9.5f, 6f, 3.5f, 6f)
        }
        Ic.Home -> {
            poly(false, false, 4f, 11f, 12f, 4f, 20f, 11f)
            poly(false, false, 6f, 10f, 6f, 20f, 18f, 20f, 18f, 10f)
        }
        Ic.Video -> {
            rrect(3.5f, 6f, 20.5f, 18f, 2.5f, false)
            poly(true, true, 10.5f, 9.5f, 15f, 12f, 10.5f, 14.5f)
        }
        Ic.Info -> {
            circle(12f, 12f, 8.5f, false)
            line(12f, 11f, 12f, 16f)
            circle(12f, 8f, 0.4f, true)
        }
        Ic.Lock -> {
            rrect(5.5f, 10.5f, 18.5f, 20f, 2.2f, false)
            val p = Path()
            p.moveTo(8.5f * s, 10.5f * s)
            p.lineTo(8.5f * s, 8f * s)
            p.cubicTo(8.5f * s, 3.5f * s, 15.5f * s, 3.5f * s, 15.5f * s, 8f * s)
            p.lineTo(15.5f * s, 10.5f * s)
            drawPath(p, tint, style = stroke)
        }
    }
}
