package gt.calin.clipa

import androidx.compose.ui.graphics.Color

/** Contenido de la biblioteca: colores de texto, pegatinas, etc. */
object Library {

    /** Contenido de pago (PRO). */
    val proFilters: Set<Filter> = setOf(Filter.NEON, Filter.DRAMA, Filter.GOLDEN, Filter.SUNSET, Filter.TEAL, Filter.NOIR)
    val proFx: Set<Fx> = setOf(Fx.GLITCH, Fx.VHS, Fx.DISCO, Fx.LEAK, Fx.BLUR)
    val proTextStyles: Set<TextStyleKind> = setOf(TextStyleKind.NEON, TextStyleKind.RETRO)

    val textColors: List<Int> = listOf(
        0xFFFFFFFF.toInt(),
        0xFF000000.toInt(),
        0xFFFFE066.toInt(),
        0xFFFFA630.toInt(),
        0xFFFF5C5C.toInt(),
        0xFFFF4FA3.toInt(),
        0xFFB57CFF.toInt(),
        0xFF66E0FF.toInt(),
        0xFF19E3C1.toInt(),
        0xFF7CFF8A.toInt(),
    )

    class StickerPack(val name: String, val items: List<String>)

    val stickerPacks: List<StickerPack> = listOf(
        StickerPack(
            "Caritas",
            listOf(
                "😀", "😂", "🤣", "😍", "🥰", "😎", "🤩", "😘", "😜", "🤪", "😏", "😢",
                "😭", "😡", "🥶", "🥵", "😱", "🤯", "😴", "🤔", "🙄", "😇", "🤑", "🤠",
                "🥳", "😈", "👻", "💀", "🤡", "👽", "🤖", "💩",
            ),
        ),
        StickerPack(
            "Gestos",
            listOf(
                "👍", "👎", "👏", "🙌", "🙏", "💪", "✌️", "🤞", "🤟", "🤘", "👌", "🤙",
                "👋", "🖐️", "☝️", "👉", "👈", "👆", "👇", "✊", "👊", "🤝", "🫶", "🫰",
            ),
        ),
        StickerPack(
            "Amor",
            listOf(
                "❤️", "🧡", "💛", "💚", "💙", "💜", "🖤", "🤍", "💔", "❣️", "💕", "💞",
                "💓", "💗", "💖", "💘", "💝", "😻", "💋", "🌹", "💍", "🥂", "🍫", "🎁",
            ),
        ),
        StickerPack(
            "Fiesta",
            listOf(
                "🎉", "🎊", "🎈", "🎂", "🍾", "🥂", "🎁", "🎆", "🎇", "✨", "🌟", "⭐",
                "💫", "🪩", "🎵", "🎶", "🎤", "🎧", "🎸", "🥁", "🎬", "📸", "🏆", "🥇",
            ),
        ),
        StickerPack(
            "Fuego",
            listOf(
                "🔥", "💥", "⚡", "💯", "🚀", "💎", "👑", "🌈", "☀️", "🌙", "❄️", "🌊",
                "💧", "☁️", "🌪️", "⚠️", "❗", "❓", "✅", "❌", "➕", "➡️", "⬆️", "🆕",
            ),
        ),
        StickerPack(
            "Animales",
            listOf(
                "🐶", "🐱", "🐭", "🐹", "🐰", "🦊", "🐻", "🐼", "🐨", "🐯", "🦁", "🐮",
                "🐷", "🐸", "🐵", "🐔", "🐧", "🦄", "🐝", "🦋", "🐢", "🐙", "🐬", "🦈",
            ),
        ),
        StickerPack(
            "Comida",
            listOf(
                "🍕", "🍔", "🍟", "🌮", "🌯", "🍣", "🍜", "🍩", "🍪", "🍰", "🍦", "🍓",
                "🍉", "🍌", "🍎", "🥑", "🌽", "☕", "🍺", "🍹", "🍷", "🥤", "🍿", "🧁",
            ),
        ),
        StickerPack(
            "Viajes",
            listOf(
                "✈️", "🚗", "🏍️", "🚲", "🚢", "🚀", "🏖️", "🏝️", "🏔️", "🌋", "🗺️", "📍",
                "🏠", "🏙️", "🌆", "🌅", "⛺", "🎡", "🎢", "⚽", "🏀", "🎮", "🛍️", "📱",
            ),
        ),
    )

    class FxStyle(val a: Color, val b: Color)

    fun fxStyle(f: Fx): FxStyle = when (f) {
        Fx.NONE -> FxStyle(Color(0xFF2A2A36), Color(0xFF3A3A4A))
        Fx.PULSE -> FxStyle(Color(0xFFFF4FA3), Color(0xFFFF8A3D))
        Fx.BREATH -> FxStyle(Color(0xFF19E3C1), Color(0xFF2E86FF))
        Fx.SHAKE -> FxStyle(Color(0xFFFFC857), Color(0xFFFF5C5C))
        Fx.FLASH -> FxStyle(Color(0xFFFFFFFF), Color(0xFFFFE066))
        Fx.DISCO -> FxStyle(Color(0xFFFF4FA3), Color(0xFF7C5CFF))
        Fx.GLITCH -> FxStyle(Color(0xFF00E5FF), Color(0xFFFF2E63))
        Fx.BLUR -> FxStyle(Color(0xFF6C7A99), Color(0xFFB8C4E0))
        Fx.VHS -> FxStyle(Color(0xFF4B3F72), Color(0xFFD7263D))
        Fx.GRAIN -> FxStyle(Color(0xFF555555), Color(0xFF999999))
        Fx.BARS -> FxStyle(Color(0xFF111111), Color(0xFF444444))
        Fx.LEAK -> FxStyle(Color(0xFFFF8A3D), Color(0xFFFF2E63))
        Fx.FRAME -> FxStyle(Color(0xFFEFEFEF), Color(0xFFBBBBBB))
    }
}
