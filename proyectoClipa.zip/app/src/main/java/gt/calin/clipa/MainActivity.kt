package gt.calin.clipa

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue

class MainActivity : ComponentActivity() {

    private val vm: EditorViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )
        setContent {
            ClipaTheme {
                App(vm)
            }
        }
    }

    override fun onPause() {
        vm.pause()
        super.onPause()
    }
}

@Composable
private fun App(vm: EditorViewModel) {
    var inEditor by rememberSaveable { mutableStateOf(false) }
    if (inEditor) {
        EditorScreen(vm, onHome = { inEditor = false })
    } else {
        HomeScreen(vm, onEnter = { inEditor = true })
    }
}
