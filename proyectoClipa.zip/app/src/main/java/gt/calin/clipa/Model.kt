@file:OptIn(UnstableApi::class)

package gt.calin.clipa

import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import kotlin.math.roundToInt

data class Clip(
    val id: Long,
    val uri: Uri,
    val sourceDurationMs: Long,
    val startMs: Long,
    val endMs: Long,
) {
    val lengthMs: Long get() = endMs - startMs

    /** MediaItem recortado. Se usa igual en la vista previa y en la exportación. */
    fun toMediaItem(): MediaItem {
        val clipping = MediaItem.ClippingConfiguration.Builder()
            .setStartPositionMs(startMs)
        // Si llega hasta el final real del video, no se fija el final para evitar desfaces de redondeo.
        if (endMs < sourceDurationMs) clipping.setEndPositionMs(endMs)
        return MediaItem.Builder()
            .setUri(uri)
            .setClippingConfiguration(clipping.build())
            .build()
    }
}

data class TextItem(
    val id: Long,
    val text: String,
    val startMs: Long,
    val endMs: Long,
    val color: Int,
    /** Tamaño del texto como fracción del alto del video. */
    val sizeFrac: Float,
    /** Centro del texto, de 0 a 1 sobre el ancho y alto del video. */
    val x: Float,
    val y: Float,
)

data class MusicTrack(
    val uri: Uri,
    val name: String,
    val durationMs: Long,
    val volume: Float = 0.8f,
)

enum class Aspect(val label: String, val rw: Int, val rh: Int) {
    R9_16("9:16", 9, 16),
    R16_9("16:9", 16, 9),
    R1_1("1:1", 1, 1),
    R4_5("4:5", 4, 5);

    val ratio: Float get() = rw.toFloat() / rh

    /** Ancho y alto (pares) para un lado corto dado. */
    fun sizeFor(shortSide: Int): Pair<Int, Int> {
        val w: Int
        val h: Int
        if (rw <= rh) {
            w = shortSide
            h = (shortSide.toFloat() * rh / rw).roundToInt()
        } else {
            h = shortSide
            w = (shortSide.toFloat() * rw / rh).roundToInt()
        }
        return Pair((w / 2) * 2, (h / 2) * 2)
    }
}

enum class ExportQuality(val label: String, val shortSide: Int, val bitrate: Int) {
    P720("720p", 720, 6_000_000),
    P1080("1080p", 1080, 10_000_000),
}

sealed interface ExportState {
    data object Idle : ExportState
    data class Running(val progress: Int) : ExportState
    data class Done(val uri: Uri) : ExportState
    data class Error(val message: String) : ExportState
}

fun formatTime(ms: Long): String {
    val totalSec = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(totalSec / 60, totalSec % 60)
}

fun formatTimeTenths(ms: Long): String {
    val v = ms.coerceAtLeast(0)
    val totalSec = v / 1000
    return "%d:%02d.%d".format(totalSec / 60, totalSec % 60, (v % 1000) / 100)
}
