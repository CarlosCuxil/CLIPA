@file:OptIn(UnstableApi::class)

package gt.calin.clipa

import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import kotlin.math.roundToInt

data class Clip(
    val id: Long,
    val uri: Uri,
    val sourceDurationMs: Long,
    val startMs: Long,
    val endMs: Long,
    val look: Look = Look(),
    /** Volumen del audio original de este clip, de 0 a 1. */
    val volume: Float = 1f,
) {
    val lengthMs: Long get() = endMs - startMs

    /** MediaItem recortado. Se usa igual en la vista previa y en la exportación. */
    fun toMediaItem(): MediaItem {
        val clipping = MediaItem.ClippingConfiguration.Builder()
            .setStartPositionMs(startMs)
        // Si llega hasta el final real del video, no se fija el final para evitar desfases de redondeo.
        if (endMs < sourceDurationMs) clipping.setEndPositionMs(endMs)
        return MediaItem.Builder()
            .setUri(uri)
            .setClippingConfiguration(clipping.build())
            .build()
    }
}

enum class AudioKind { MUSIC, SFX, IMPORTED }

/** Un sonido colocado en la línea de tiempo. */
data class AudioClip(
    val id: Long,
    val uri: Uri,
    val name: String,
    val kind: AudioKind,
    val sourceDurationMs: Long,
    val trimStartMs: Long,
    val trimEndMs: Long,
    /** Dónde empieza en la línea de tiempo del proyecto. */
    val startMs: Long,
    val volume: Float = 1f,
) {
    val lengthMs: Long get() = trimEndMs - trimStartMs
    val endMs: Long get() = startMs + lengthMs

    fun toMediaItem(maxLengthMs: Long): MediaItem {
        val len = lengthMs.coerceAtMost(maxLengthMs)
        val clipping = MediaItem.ClippingConfiguration.Builder().setStartPositionMs(trimStartMs)
        if (trimStartMs + len < sourceDurationMs) clipping.setEndPositionMs(trimStartMs + len)
        return MediaItem.Builder()
            .setUri(uri)
            .setClippingConfiguration(clipping.build())
            .build()
    }
}

enum class TextFont(val label: String, val family: String) {
    MODERN("Moderna", "sans-serif"),
    IMPACT("Impacto", "sans-serif-black"),
    CONDENSED("Compacta", "sans-serif-condensed"),
    SERIF("Clásica", "serif"),
    MONO("Máquina", "monospace"),
    HAND("Manuscrita", "cursive"),
}

enum class TextStyleKind(val label: String) {
    CLASSIC("Clásico"),
    OUTLINE("Contorno"),
    BOX("Caja"),
    NEON("Neón"),
    RETRO("Retro"),
}

/** Texto o pegatina (emoji) sobre el video. */
data class TextItem(
    val id: Long,
    val text: String,
    val startMs: Long,
    val endMs: Long,
    val color: Int,
    /** Tamaño como fracción del alto del video. */
    val sizeFrac: Float,
    /** Centro, de 0 a 1 sobre el ancho y alto del video. */
    val x: Float,
    val y: Float,
    val font: TextFont = TextFont.MODERN,
    val style: TextStyleKind = TextStyleKind.CLASSIC,
    val sticker: Boolean = false,
)

enum class Aspect(val label: String, val rw: Int, val rh: Int) {
    R9_16("9:16", 9, 16),
    R16_9("16:9", 16, 9),
    R1_1("1:1", 1, 1),
    R4_5("4:5", 4, 5),
    R3_4("3:4", 3, 4),
    R21_9("21:9", 21, 9);

    val ratio: Float get() = rw.toFloat() / rh

    /** Ancho y alto (pares) para un lado corto dado. */
    fun sizeFor(shortSide: Int): Pair<Int, Int> {
        val w: Int
        val h: Int
        if (rw <= rh) {
            w = shortSide
            h = (shortSide.toFloat() * rh / rw).roundToInt()
        } else {
            h = shortSide
            w = (shortSide.toFloat() * rw / rh).roundToInt()
        }
        return Pair((w / 2) * 2, (h / 2) * 2)
    }
}

enum class ExportQuality(
    val label: String,
    val shortSide: Int,
    val bitrate: Int,
    val hevc: Boolean,
    val pro: Boolean,
    val note: String,
) {
    P720("720p", 720, 6_000_000, false, false, "Rápido y ligero"),
    P1080("1080p Full HD", 1080, 12_000_000, false, false, "Ideal para redes sociales"),
    P2K("2K", 1440, 22_000_000, true, true, "Más detalle, archivo mayor"),
    P4K("4K Ultra HD", 2160, 45_000_000, true, true, "Máxima calidad (tarda más)"),
}

/** Todo lo que se puede deshacer/rehacer. */
data class Project(
    val clips: List<Clip> = emptyList(),
    val texts: List<TextItem> = emptyList(),
    val audios: List<AudioClip> = emptyList(),
    val aspect: Aspect = Aspect.R9_16,
    val muteOriginal: Boolean = false,
) {
    val totalMs: Long get() = clips.sumOf { it.lengthMs }
}

sealed interface Sel
data class SelClip(val id: Long) : Sel
data class SelText(val id: Long) : Sel
data class SelAudio(val id: Long) : Sel

sealed interface ExportState {
    data object Idle : ExportState
    data class Running(val progress: Int) : ExportState
    data class Done(val uri: Uri, val widthPx: Int, val heightPx: Int) : ExportState
    data class Error(val message: String) : ExportState
}

/** Posición (ms) donde empieza el clip i dentro de la línea de tiempo. */
fun List<Clip>.offsetOf(index: Int): Long {
    var off = 0L
    for (k in 0 until index.coerceAtMost(size)) off += this[k].lengthMs
    return off
}

fun formatTime(ms: Long): String {
    val totalSec = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(totalSec / 60, totalSec % 60)
}

fun formatTimeTenths(ms: Long): String {
    val v = ms.coerceAtLeast(0)
    val totalSec = v / 1000
    return "%d:%02d.%d".format(totalSec / 60, totalSec % 60, (v % 1000) / 100)
}
