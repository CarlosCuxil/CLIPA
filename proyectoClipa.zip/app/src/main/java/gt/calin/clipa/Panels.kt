package gt.calin.clipa

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

@Composable
private fun Hint(text: String) {
    Text(
        text,
        color = Pal.Muted,
        fontSize = 13.sp,
        textAlign = TextAlign.Center,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 18.dp),
    )
}

// ---------------------------------------------------------------------------------------------
// Editar
// ---------------------------------------------------------------------------------------------

@Composable
fun EditPanel(vm: EditorViewModel, onClose: () -> Unit) {
    PanelFrame("Editar", onClose) {
        val sel = vm.selection
        val clip = vm.selectedClip
        val txt = vm.selectedText
        val au = vm.selectedAudio

        Row(
            Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 6.dp)
        ) {
            if (clip != null) {
                ToolButton(Ic.Scissors, "Dividir", onClick = { vm.splitAtPlayhead() })
                ToolButton(Ic.Copy, "Duplicar", onClick = { vm.duplicateSelected() })
                ToolButton(Ic.ArrowLeft, "Antes", onClick = { vm.moveSelectedClip(-1) })
                ToolButton(Ic.ArrowRight, "Después", onClick = { vm.moveSelectedClip(1) })
                ToolButton(
                    Ic.Rotate, "Girar",
                    onClick = { vm.updateLook(clip.id, "rot") { it.copy(rotation = (it.rotation + 90) % 360) } },
                )
                ToolButton(
                    Ic.Mirror, "Espejo",
                    onClick = { vm.updateLook(clip.id, "mir") { it.copy(mirror = !it.mirror) } },
                    active = clip.look.mirror,
                )
                ToolButton(
                    Ic.Crop, "Rellenar",
                    onClick = { vm.updateLook(clip.id, "fill") { it.copy(fill = !it.fill) } },
                    active = clip.look.fill,
                )
                ToolButton(Ic.Trash, "Eliminar", onClick = { vm.deleteSelected() }, tint = Pal.Danger)
            } else if (sel is SelText || sel is SelAudio) {
                ToolButton(Ic.Copy, "Duplicar", onClick = { vm.duplicateSelected() })
                ToolButton(Ic.Trash, "Eliminar", onClick = { vm.deleteSelected() }, tint = Pal.Danger)
            }
        }

        if (clip != null) {
            LabeledSlider(
                "Volumen del clip",
                clip.volume,
                { v -> vm.setClipVolume(clip.id, v) },
                "${(clip.volume * 100).roundToInt()}%",
            )
        }
        if (txt != null) {
            LabeledSlider(
                "Tamaño",
                txt.sizeFrac,
                { v -> vm.updateText(txt.id, "size") { t -> t.copy(sizeFrac = v) } },
                "${(txt.sizeFrac * 100).roundToInt()}",
                range = 0.02f..0.4f,
            )
        }
        if (au != null) {
            LabeledSlider(
                "Volumen",
                au.volume,
                { v -> vm.setAudioVolume(au.id, v) },
                "${(au.volume * 100).roundToInt()}%",
            )
        }
        if (sel == null) Hint("Toca un clip, texto o sonido de la línea de tiempo para editarlo.")
        Spacer(Modifier.height(8.dp))
    }
}

// ---------------------------------------------------------------------------------------------
// Audio
// ---------------------------------------------------------------------------------------------

@Composable
fun AudioPanel(
    vm: EditorViewModel,
    onClose: () -> Unit,
    onPickAudio: () -> Unit,
    onPaywall: () -> Unit,
) {
    var tab by remember { mutableIntStateOf(0) }
    var cat by remember { mutableStateOf("Todos") }

    PanelFrame("Audio", onClose) {
        Row(
            Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Chip("Música", tab == 0, { tab = 0 })
            Chip("Efectos de sonido", tab == 1, { tab = 1 })
            Chip("Mi audio", tab == 2, { tab = 2 })
        }
        Spacer(Modifier.height(8.dp))

        when (tab) {
            0 -> SoundList(vm, SoundLab.music, onPaywall)
            1 -> {
                val cats = listOf("Todos") + SoundLab.sfx.map { it.category }.distinct()
                Row(
                    Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 14.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    for (c in cats) {
                        Text(
                            c,
                            color = if (cat == c) Pal.Accent else Pal.Muted,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier
                                .tap { cat = c }
                                .padding(horizontal = 6.dp, vertical = 4.dp),
                        )
                    }
                }
                val list = if (cat == "Todos") SoundLab.sfx else SoundLab.sfx.filter { it.category == cat }
                SoundList(vm, list, onPaywall)
            }
            else -> {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .height(176.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    Glyph(Ic.Folder, Pal.Muted, size = 36.dp)
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "Usa música o audios de tu teléfono",
                        color = Pal.Muted,
                        fontSize = 13.sp,
                    )
                    Spacer(Modifier.height(14.dp))
                    GradientButton("Elegir audio", onClick = onPickAudio, ic = Ic.Plus)
                }
            }
        }
    }
}

@Composable
private fun SoundList(vm: EditorViewModel, list: List<SoundDef>, onPaywall: () -> Unit) {
    LazyColumn(
        Modifier
            .fillMaxWidth()
            .height(176.dp)
    ) {
        items(list, key = { it.id }) { def ->
            SoundRow(vm, def, onPaywall)
        }
    }
}

@Composable
private fun SoundRow(vm: EditorViewModel, def: SoundDef, onPaywall: () -> Unit) {
    val busy = vm.generatingSound == def.id
    val playingThis = vm.auditioning == def.id
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(Pal.Surface3)
                .tap { vm.toggleAudition(def) },
            contentAlignment = Alignment.Center,
        ) {
            if (busy) {
                CircularProgressIndicator(
                    modifier = Modifier.size(18.dp),
                    strokeWidth = 2.dp,
                    color = Pal.Accent,
                )
            } else {
                Glyph(if (playingThis) Ic.Pause else Ic.Play, Pal.Text, size = 18.dp)
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(def.name, color = Pal.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                if (def.premium) {
                    Spacer(Modifier.width(6.dp))
                    ProBadge()
                }
            }
            Text(
                "${def.category} · ${formatTime(def.durationMs)}",
                color = Pal.Muted,
                fontSize = 11.sp,
            )
        }
        IconBtn(
            Ic.Plus,
            onClick = {
                if (def.premium && !vm.isPro) onPaywall() else {
                    vm.stopAudition()
                    vm.addSound(def)
                }
            },
            tint = Color.Black,
            bg = Pal.Accent,
            box = 34.dp,
            glyph = 18.dp,
        )
    }
}

// ---------------------------------------------------------------------------------------------
// Texto
// ---------------------------------------------------------------------------------------------

@Composable
fun TextPanel(vm: EditorViewModel, onClose: () -> Unit, onPaywall: () -> Unit) {
    val sel = vm.selectedText?.takeIf { !it.sticker }
    var draftText by remember { mutableStateOf("") }
    var draftColor by remember { mutableIntStateOf(Library.textColors[0]) }
    var draftFont by remember { mutableStateOf(TextFont.MODERN) }
    var draftStyle by remember { mutableStateOf(TextStyleKind.CLASSIC) }

    val text = sel?.text ?: draftText
    val color = sel?.color ?: draftColor
    val font = sel?.font ?: draftFont
    val style = sel?.style ?: draftStyle

    PanelFrame(if (sel != null) "Editar texto" else "Nuevo texto", onClose) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            TextField(
                value = text,
                onValueChange = { v ->
                    if (sel != null) vm.updateText(sel.id, "txt") { t -> t.copy(text = v) } else draftText = v
                },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Escribe tu texto", color = Pal.Muted) },
                maxLines = 3,
                shape = RoundedCornerShape(14.dp),
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Pal.Surface3,
                    unfocusedContainerColor = Pal.Surface3,
                    focusedTextColor = Pal.Text,
                    unfocusedTextColor = Pal.Text,
                    cursorColor = Pal.Accent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                ),
            )
            if (sel == null) {
                Spacer(Modifier.width(8.dp))
                GradientButton(
                    "Añadir",
                    onClick = {
                        vm.addText(draftText.trim(), draftColor, draftFont, draftStyle)
                        draftText = ""
                    },
                    enabled = draftText.isNotBlank() && vm.totalMs > 0,
                    height = 44.dp,
                )
            }
        }
        Spacer(Modifier.height(8.dp))

        Row(
            Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            for (s in TextStyleKind.entries) {
                val locked = s in Library.proTextStyles && !vm.isPro
                Chip(
                    s.label, style == s,
                    onClick = {
                        if (locked) onPaywall()
                        else if (sel != null) vm.updateText(sel.id, "style") { t -> t.copy(style = s) }
                        else draftStyle = s
                    },
                    pro = s in Library.proTextStyles,
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(
            Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            for (f in TextFont.entries) {
                Chip(
                    f.label, font == f,
                    onClick = {
                        if (sel != null) vm.updateText(sel.id, "font") { t -> t.copy(font = f) } else draftFont = f
                    },
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(
            Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            for (c in Library.textColors) {
                Box(
                    Modifier
                        .size(30.dp)
                        .clip(CircleShape)
                        .background(Color(c))
                        .border(if (color == c) 3.dp else 1.dp, if (color == c) Pal.Accent else Pal.Line, CircleShape)
                        .tap {
                            if (sel != null) vm.updateText(sel.id, "color") { t -> t.copy(color = c) } else draftColor = c
                        }
                )
            }
        }
        if (sel != null) {
            Spacer(Modifier.height(4.dp))
            LabeledSlider(
                "Tamaño",
                sel.sizeFrac,
                { v -> vm.updateText(sel.id, "size") { t -> t.copy(sizeFrac = v) } },
                "${(sel.sizeFrac * 100).roundToInt()}",
                range = 0.02f..0.4f,
            )
        }
        Spacer(Modifier.height(10.dp))
    }
}

// ---------------------------------------------------------------------------------------------
// Pegatinas
// ---------------------------------------------------------------------------------------------

@Composable
fun StickerPanel(vm: EditorViewModel, onClose: () -> Unit) {
    var pack by remember { mutableIntStateOf(0) }
    PanelFrame("Pegatinas", onClose) {
        Row(
            Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            for ((i, p) in Library.stickerPacks.withIndex()) {
                Chip(p.name, pack == i, { pack = i })
            }
        }
        Spacer(Modifier.height(6.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(7),
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
                .padding(horizontal = 8.dp),
        ) {
            items(Library.stickerPacks[pack].items) { e ->
                Box(
                    Modifier
                        .padding(2.dp)
                        .height(44.dp)
                        .tap { vm.addSticker(e) },
                    contentAlignment = Alignment.Center,
                ) {
                    Text(e, fontSize = 26.sp)
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Efectos
// ---------------------------------------------------------------------------------------------

@Composable
fun EffectsPanel(vm: EditorViewModel, onClose: () -> Unit, onPaywall: () -> Unit) {
    PanelFrame("Efectos de video", onClose) {
        val clip = vm.selectedClip ?: vm.currentClip
        if (clip == null) {
            Hint("Agrega un video para usar efectos.")
            return@PanelFrame
        }
        LazyRow(
            Modifier.fillMaxWidth(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(Fx.entries.toList(), key = { it.name }) { fx ->
                val st = Library.fxStyle(fx)
                val selected = clip.look.fx == fx
                val pro = fx in Library.proFx
                Column(
                    Modifier
                        .width(68.dp)
                        .tap {
                            if (pro && !vm.isPro) onPaywall()
                            else vm.updateLook(clip.id, "fx") { l -> l.copy(fx = fx) }
                        },
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Box(
                        Modifier
                            .size(68.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Brush.linearGradient(listOf(st.a, st.b)))
                            .border(
                                if (selected) 2.5.dp else 1.dp,
                                if (selected) Pal.Accent else Pal.Line,
                                RoundedCornerShape(14.dp),
                            ),
                        contentAlignment = Alignment.Center,
                    ) {
                        Glyph(
                            if (fx == Fx.NONE) Ic.Close else Ic.Fx,
                            if (fx == Fx.FLASH || fx == Fx.FRAME) Color.Black else Color.White,
                            size = 28.dp,
                        )
                        if (pro) {
                            Box(Modifier.align(Alignment.TopEnd).padding(4.dp)) { ProBadge() }
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        fx.label,
                        color = if (selected) Pal.Accent else Pal.Muted,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                    )
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        if (clip.look.fx != Fx.NONE && clip.look.fx != Fx.BARS) {
            LabeledSlider(
                "Intensidad",
                clip.look.fxAmount,
                { v -> vm.updateLook(clip.id, "fxa") { l -> l.copy(fxAmount = v) } },
                "${(clip.look.fxAmount * 100).roundToInt()}",
            )
        }
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.End,
        ) {
            Chip("Aplicar a todos", false, { vm.applyLookToAll(clip.id) })
        }
        Spacer(Modifier.height(4.dp))
    }
}

// ---------------------------------------------------------------------------------------------
// Filtros
// ---------------------------------------------------------------------------------------------

@Composable
fun FiltersPanel(vm: EditorViewModel, onClose: () -> Unit, onPaywall: () -> Unit) {
    PanelFrame("Filtros", onClose) {
        val clip = vm.selectedClip ?: vm.currentClip
        if (clip == null) {
            Hint("Agrega un video para usar filtros.")
            return@PanelFrame
        }
        val base = remember { vm.currentFrame() }
        var previews by remember { mutableStateOf<Map<Filter, ImageBitmap>>(emptyMap()) }
        LaunchedEffect(base) {
            if (base != null) {
                previews = withContext(Dispatchers.Default) {
                    val src = base.copy(Bitmap.Config.ARGB_8888, false)
                    val out = LinkedHashMap<Filter, ImageBitmap>()
                    for (f in Filter.entries) {
                        out[f] = ColorLab.applyToBitmap(src, Look(filter = f)).asImageBitmap()
                    }
                    out
                }
            }
        }
        LazyRow(
            Modifier.fillMaxWidth(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(Filter.entries.toList(), key = { it.name }) { f ->
                val selected = clip.look.filter == f
                val pro = f in Library.proFilters
                Column(
                    Modifier
                        .width(66.dp)
                        .tap {
                            if (pro && !vm.isPro) onPaywall()
                            else vm.updateLook(clip.id, "filter") { l ->
                                l.copy(filter = f, filterAmount = if (l.filter != f) 1f else l.filterAmount)
                            }
                        },
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Box(
                        Modifier
                            .size(66.dp, 88.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Pal.Surface3)
                            .border(
                                if (selected) 2.5.dp else 1.dp,
                                if (selected) Pal.Accent else Pal.Line,
                                RoundedCornerShape(12.dp),
                            ),
                    ) {
                        val img = previews[f]
                        if (img != null) {
                            Image(
                                bitmap = img,
                                contentDescription = f.label,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize(),
                            )
                        }
                        if (pro) {
                            Box(Modifier.align(Alignment.TopEnd).padding(3.dp)) { ProBadge() }
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        f.label,
                        color = if (selected) Pal.Accent else Pal.Muted,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                    )
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        if (clip.look.filter != Filter.NONE) {
            LabeledSlider(
                "Intensidad",
                clip.look.filterAmount,
                { v -> vm.updateLook(clip.id, "fa") { l -> l.copy(filterAmount = v) } },
                "${(clip.look.filterAmount * 100).roundToInt()}",
            )
        }
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.End,
        ) {
            Chip("Aplicar a todos", false, { vm.applyLookToAll(clip.id) })
        }
        Spacer(Modifier.height(4.dp))
    }
}

// ---------------------------------------------------------------------------------------------
// Ajustar
// ---------------------------------------------------------------------------------------------

private class AdjustParam(
    val label: String,
    val min: Float,
    val max: Float,
    val centered: Boolean,
    val get: (Look) -> Float,
    val set: (Look, Float) -> Look,
)

private val adjustParams: List<AdjustParam> = listOf(
    AdjustParam("Brillo", -1f, 1f, true, { it.brightness }, { l, v -> l.copy(brightness = v) }),
    AdjustParam("Contraste", -1f, 1f, true, { it.contrast }, { l, v -> l.copy(contrast = v) }),
    AdjustParam("Saturación", -1f, 1f, true, { it.saturation }, { l, v -> l.copy(saturation = v) }),
    AdjustParam("Calidez", -1f, 1f, true, { it.warmth }, { l, v -> l.copy(warmth = v) }),
    AdjustParam("Tinte", -1f, 1f, true, { it.tint }, { l, v -> l.copy(tint = v) }),
    AdjustParam("Desvanecer", 0f, 1f, false, { it.fade }, { l, v -> l.copy(fade = v) }),
    AdjustParam("Viñeta", 0f, 1f, false, { it.vignette }, { l, v -> l.copy(vignette = v) }),
)

@Composable
fun AdjustPanel(vm: EditorViewModel, onClose: () -> Unit) {
    var idx by remember { mutableIntStateOf(0) }
    PanelFrame("Ajustar", onClose) {
        val clip = vm.selectedClip ?: vm.currentClip
        if (clip == null) {
            Hint("Agrega un video para ajustar el color.")
            return@PanelFrame
        }
        Row(
            Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            for ((i, p) in adjustParams.withIndex()) {
                Chip(p.label, idx == i, { idx = i })
            }
        }
        Spacer(Modifier.height(10.dp))
        val p = adjustParams[idx]
        val v = p.get(clip.look)
        LabeledSlider(
            p.label,
            v,
            { nv -> vm.updateLook(clip.id, "adj$idx") { l -> p.set(l, nv) } },
            "${(v * 100).roundToInt()}",
            range = p.min..p.max,
            centerZero = p.centered,
        )
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End),
        ) {
            Chip("Restablecer", false, {
                vm.updateLook(clip.id, "adjreset") { l ->
                    l.copy(
                        brightness = 0f, contrast = 0f, saturation = 0f,
                        warmth = 0f, tint = 0f, fade = 0f, vignette = 0f,
                    )
                }
            })
            Chip("Aplicar a todos", false, { vm.applyLookToAll(clip.id) })
        }
        Spacer(Modifier.height(30.dp))
    }
}

// ---------------------------------------------------------------------------------------------
// Formato
// ---------------------------------------------------------------------------------------------

@Composable
fun FormatPanel(vm: EditorViewModel, onClose: () -> Unit) {
    PanelFrame("Formato", onClose) {
        Text(
            "Proporción del video",
            color = Pal.Muted,
            fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 16.dp),
        )
        Spacer(Modifier.height(8.dp))
        LazyRow(
            Modifier.fillMaxWidth(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(Aspect.entries.toList(), key = { it.name }) { a ->
                val selected = vm.aspect == a
                Column(
                    Modifier
                        .width(62.dp)
                        .tap { vm.changeAspect(a) },
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Box(
                        Modifier
                            .size(62.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Pal.Surface3)
                            .border(
                                if (selected) 2.dp else 1.dp,
                                if (selected) Pal.Accent else Pal.Line,
                                RoundedCornerShape(12.dp),
                            ),
                        contentAlignment = Alignment.Center,
                    ) {
                        val r = a.ratio
                        val bw = if (r >= 1f) 38.dp else 38.dp * r
                        val bh = if (r >= 1f) 38.dp / r else 38.dp
                        Box(
                            Modifier
                                .size(bw, bh)
                                .clip(RoundedCornerShape(3.dp))
                                .background(if (selected) Pal.Accent else Pal.Muted)
                        )
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        a.label,
                        color = if (selected) Pal.Accent else Pal.Muted,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                    )
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp)
                .tap { vm.toggleMuteOriginal() },
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Glyph(if (vm.muteOriginal) Ic.Mute else Ic.Volume, Pal.Text, size = 22.dp)
            Spacer(Modifier.width(12.dp))
            Text(
                "Silenciar audio original",
                color = Pal.Text,
                fontSize = 14.sp,
                modifier = Modifier.weight(1f),
            )
            Box(
                Modifier
                    .width(46.dp)
                    .height(26.dp)
                    .clip(RoundedCornerShape(50))
                    .background(if (vm.muteOriginal) Pal.Accent else Pal.Surface3)
                    .padding(3.dp),
                contentAlignment = if (vm.muteOriginal) Alignment.CenterEnd else Alignment.CenterStart,
            ) {
                Box(
                    Modifier
                        .size(20.dp)
                        .clip(CircleShape)
                        .background(Color.White)
                )
            }
        }
        Spacer(Modifier.height(30.dp))
    }
}
