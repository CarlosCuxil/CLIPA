package gt.calin.clipa

import java.io.ByteArrayOutputStream
import java.io.File
import java.util.Random
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.tanh

/** Un sonido de la biblioteca. Se sintetiza en el teléfono la primera vez que se usa. */
class SoundDef(
    val id: String,
    val name: String,
    val category: String,
    val isMusic: Boolean,
    val durationMs: Long,
    val premium: Boolean,
)

private const val SR = 44100

private class Biquad {
    private var b0 = 1.0
    private var b1 = 0.0
    private var b2 = 0.0
    private var a1 = 0.0
    private var a2 = 0.0
    private var x1 = 0.0
    private var x2 = 0.0
    private var y1 = 0.0
    private var y2 = 0.0

    private fun safe(f: Double): Double = f.coerceIn(20.0, SR * 0.45)

    fun lowpass(f: Double, q: Double) {
        val w = 2 * PI * safe(f) / SR
        val c = cos(w)
        val a = sin(w) / (2 * q)
        val a0 = 1 + a
        b0 = (1 - c) / 2 / a0
        b1 = (1 - c) / a0
        b2 = b0
        a1 = -2 * c / a0
        a2 = (1 - a) / a0
    }

    fun highpass(f: Double, q: Double) {
        val w = 2 * PI * safe(f) / SR
        val c = cos(w)
        val a = sin(w) / (2 * q)
        val a0 = 1 + a
        b0 = (1 + c) / 2 / a0
        b1 = -(1 + c) / a0
        b2 = b0
        a1 = -2 * c / a0
        a2 = (1 - a) / a0
    }

    fun bandpass(f: Double, q: Double) {
        val w = 2 * PI * safe(f) / SR
        val c = cos(w)
        val a = sin(w) / (2 * q)
        val a0 = 1 + a
        b0 = a / a0
        b1 = 0.0
        b2 = -a / a0
        a1 = -2 * c / a0
        a2 = (1 - a) / a0
    }

    fun process(x: Double): Double {
        val y = b0 * x + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2
        x2 = x1
        x1 = x
        y2 = y1
        y1 = y
        return y
    }
}

private fun mtof(m: Int): Double = 440.0 * 2.0.pow((m - 69) / 12.0)

private fun samples(sec: Double): Int = (sec * SR).toInt()

private fun mixInto(dst: FloatArray, src: FloatArray, start: Int, gain: Float) {
    if (start >= dst.size) return
    val n = min(src.size, dst.size - start)
    for (i in 0 until n) dst[start + i] += src[i] * gain
}

// ---------------------------------------------------------------- instrumentos

private fun kickHit(): FloatArray {
    val n = samples(0.38)
    val out = FloatArray(n)
    var phase = 0.0
    for (i in 0 until n) {
        val t = i.toDouble() / SR
        val f = 48 + 120 * exp(-t * 30)
        phase += 2 * PI * f / SR
        out[i] = (sin(phase) * exp(-t * 8.5)).toFloat()
    }
    return out
}

private fun snareHit(rnd: Random): FloatArray {
    val n = samples(0.28)
    val out = FloatArray(n)
    val bp = Biquad()
    bp.bandpass(1900.0, 0.7)
    for (i in 0 until n) {
        val t = i.toDouble() / SR
        val noise = bp.process(rnd.nextDouble() * 2 - 1) * 1.8
        val tone = sin(2 * PI * 185 * t) * exp(-t * 32) * 0.5
        out[i] = (noise * exp(-t * 20) * 0.7 + tone).toFloat()
    }
    return out
}

private fun hatHit(rnd: Random, open: Boolean): FloatArray {
    val n = samples(if (open) 0.25 else 0.08)
    val out = FloatArray(n)
    val hp = Biquad()
    hp.highpass(7500.0, 0.8)
    for (i in 0 until n) {
        val t = i.toDouble() / SR
        out[i] = (hp.process(rnd.nextDouble() * 2 - 1) * exp(-t * (if (open) 16 else 65)) * 0.6).toFloat()
    }
    return out
}

private fun clapHit(rnd: Random): FloatArray {
    val n = samples(0.35)
    val out = FloatArray(n)
    val bp = Biquad()
    bp.bandpass(1500.0, 0.9)
    for (i in 0 until n) {
        val t = i.toDouble() / SR
        var e = exp(-t * 14)
        // tres golpes rápidos al inicio
        for (k in 0..2) {
            val d = t - k * 0.011
            if (d >= 0) e += exp(-d * 120) * 0.8
        }
        out[i] = (bp.process(rnd.nextDouble() * 2 - 1) * e * 0.8).toFloat()
    }
    return out
}

private fun pluckNote(freq: Double, dur: Double, bright: Double = 1.0): FloatArray {
    val n = samples(dur)
    val out = FloatArray(n)
    for (i in 0 until n) {
        val t = i.toDouble() / SR
        val att = min(1.0, t / 0.003)
        var s = 0.0
        for (h in 1..5) {
            s += sin(2 * PI * freq * h * t) / h.toDouble().pow(1.2 + (1.0 - bright)) * exp(-t * (3.0 + h * 1.6))
        }
        out[i] = (s * att * 0.6).toFloat()
    }
    return out
}

private fun padNote(freq: Double, dur: Double): FloatArray {
    val n = samples(dur + 0.5)
    val out = FloatArray(n)
    val lp = Biquad()
    lp.lowpass(1500.0, 0.7)
    for (i in 0 until n) {
        val t = i.toDouble() / SR
        var s = 0.0
        for (d in doubleArrayOf(-0.004, 0.0, 0.004)) {
            val f = freq * (1 + d)
            val ph = (f * t) % 1.0
            s += (ph * 2 - 1) * 0.33
        }
        val att = min(1.0, t / 0.35)
        val rel = if (t > dur) max(0.0, 1.0 - (t - dur) / 0.5) else 1.0
        out[i] = (lp.process(s) * att * rel * 0.5).toFloat()
    }
    return out
}

private fun bassNote(freq: Double, dur: Double, punchy: Boolean): FloatArray {
    val n = samples(dur)
    val out = FloatArray(n)
    for (i in 0 until n) {
        val t = i.toDouble() / SR
        val att = min(1.0, t / 0.006)
        val rel = if (t > dur - 0.04) max(0.0, (dur - t) / 0.04) else 1.0
        val decay = if (punchy) exp(-t * 3.2) else exp(-t * 1.1)
        val s = sin(2 * PI * freq * t) + 0.35 * sin(4 * PI * freq * t)
        out[i] = (tanh(s * 1.3) * att * rel * decay * 0.7).toFloat()
    }
    return out
}

private fun leadNote(freq: Double, dur: Double): FloatArray {
    val n = samples(dur)
    val out = FloatArray(n)
    for (i in 0 until n) {
        val t = i.toDouble() / SR
        val att = min(1.0, t / 0.02)
        val rel = if (t > dur - 0.08) max(0.0, (dur - t) / 0.08) else 1.0
        val vib = 1 + 0.004 * sin(2 * PI * 5.5 * t)
        val ph = 2 * PI * freq * vib * t
        val s = sin(ph) + 0.3 * sin(3 * ph) + 0.12 * sin(5 * ph)
        out[i] = (s * att * rel * 0.35).toFloat()
    }
    return out
}

// ---------------------------------------------------------------- música

private class Style(
    val id: String,
    val name: String,
    val bpm: Int,
    val prog: List<IntArray>,
    val kick: String,
    val snare: String,
    val hat: String,
    val bass: String,
    val arp: String,
    val lead: String,
    val padGain: Float,
    val pluckGain: Float,
    val leadGain: Float,
    val bassGain: Float,
    val punchyBass: Boolean,
    val clap: Boolean = false,
    val swing: Double = 0.0,
    val premium: Boolean = false,
)

private fun chord(root: Int, vararg offs: Int): IntArray = IntArray(offs.size) { root + offs[it] }

private val STYLES: List<Style> = listOf(
    Style(
        "lofi", "Lo-fi suave", 80,
        listOf(chord(57, 0, 3, 7, 10), chord(53, 0, 4, 7, 11), chord(48, 0, 4, 7, 11), chord(55, 0, 4, 7, 10)),
        "x.....x..x......", "....x.......x...", "x.x.x.x.x.x.x.x.",
        "x.....x...x.....", "x.x.x.x.x.x.x.x.", "..x.....x.......",
        0.55f, 0.55f, 0.35f, 0.8f, false, swing = 0.14,
    ),
    Style(
        "poppy", "Pop alegre", 118,
        listOf(chord(60, 0, 4, 7), chord(55, 0, 4, 7), chord(57, 0, 3, 7), chord(53, 0, 4, 7)),
        "x...x...x...x...", "....x.......x...", "..x...x...x...x.",
        "x..x..x.x..x..x.", "x.x.x.x.x.x.x.x.", "x...x.x.x...x...",
        0.35f, 0.6f, 0.55f, 0.8f, true, clap = true,
    ),
    Style(
        "epic", "Épico cine", 90,
        listOf(chord(57, 0, 3, 7), chord(53, 0, 4, 7), chord(48, 0, 4, 7), chord(55, 0, 4, 7)),
        "x.......x.......", "............x...", "................",
        "x...............", "x...x...x...x...", "x.......x.......",
        0.95f, 0.35f, 0.55f, 0.9f, false,
    ),
    Style(
        "trap", "Trap oscuro", 140,
        listOf(chord(48, 0, 3, 7), chord(44, 0, 4, 7), chord(46, 0, 4, 7), chord(43, 0, 3, 7)),
        "x.....x...x.....", "........x.......", "x.x.x.x.x.x.xxxx",
        "x.....x...x.....", "................", "..x...x.....x...",
        0.4f, 0.0f, 0.4f, 1.0f, true, swing = 0.0, premium = true,
    ),
    Style(
        "ukulele", "Ukelele feliz", 110,
        listOf(chord(67, 0, 4, 7), chord(62, 0, 4, 7), chord(64, 0, 3, 7), chord(60, 0, 4, 7)),
        "x.......x.......", "........x.......", "x.x.x.x.x.x.x.x.",
        "x.......x.......", "x.xxx.xxx.xxx.xx", "x..x..x.........",
        0.0f, 0.75f, 0.45f, 0.55f, true, clap = true, swing = 0.06,
    ),
    Style(
        "synth", "Synthwave", 105,
        listOf(chord(57, 0, 3, 7), chord(53, 0, 4, 7), chord(60, 0, 4, 7), chord(55, 0, 4, 7)),
        "x...x...x...x...", "....x.......x...", "..x...x...x...x.",
        "x.xxx.xxx.xxx.xx", "xxxxxxxxxxxxxxxx", "x..x..x...x.....",
        0.5f, 0.45f, 0.5f, 0.75f, true, premium = true,
    ),
    Style(
        "ambient", "Ambiente calma", 70,
        listOf(chord(60, 0, 4, 7, 11), chord(57, 0, 3, 7, 10), chord(53, 0, 4, 7, 11), chord(55, 0, 4, 7, 14)),
        "................", "................", "................",
        "x...............", "x.......x.......", "x...............",
        1.0f, 0.4f, 0.0f, 0.6f, false,
    ),
    Style(
        "regga", "Reggaetón", 96,
        listOf(chord(62, 0, 3, 7), chord(55, 0, 4, 7), chord(60, 0, 4, 7), chord(57, 0, 3, 7)),
        "x...x...x...x...", "...x..x....x..x.", "x.x.x.x.x.x.x.x.",
        "x..x..x.x..x..x.", "x..x..x...x.x...", "x..x..x.........",
        0.35f, 0.5f, 0.45f, 0.95f, true, premium = true,
    ),
)

private fun styleBars(s: Style): Int {
    val barSec = 4.0 * 60.0 / s.bpm
    val need = ceil(28.0 / barSec).toInt()
    val n = s.prog.size
    return ((need + n - 1) / n) * n
}

private fun styleDurationMs(s: Style): Long = (styleBars(s) * 4.0 * 60.0 / s.bpm * 1000).toLong()

private fun renderStyle(s: Style): FloatArray {
    val rnd = Random(s.id.hashCode().toLong())
    val bars = styleBars(s)
    val stepSec = 60.0 / s.bpm / 4.0
    val barSec = stepSec * 16
    val total = samples(bars * barSec + 1.0)
    val buf = FloatArray(total)

    val kick = kickHit()
    val snare = snareHit(rnd)
    val hatC = hatHit(rnd, false)
    val hatO = hatHit(rnd, true)
    val clap = clapHit(rnd)

    for (bar in 0 until bars) {
        val ch = s.prog[bar % s.prog.size]
        val barStart = bar * barSec

        if (s.padGain > 0f) {
            for (note in ch) {
                mixInto(buf, padNote(mtof(note), barSec), samples(barStart), s.padGain * 0.35f)
            }
        }

        for (step in 0 until 16) {
            val swingOff = if (step % 2 == 1) s.swing * stepSec else 0.0
            val tStart = barStart + step * stepSec + swingOff
            val at = samples(tStart)

            if (s.kick[step] == 'x') mixInto(buf, kick, at, 0.9f)
            if (s.snare[step] == 'x') {
                mixInto(buf, snare, at, 0.55f)
                if (s.clap) mixInto(buf, clap, at, 0.35f)
            }
            if (s.hat[step] == 'x') {
                val open = (step % 8 == 6) && s.id != "trap"
                mixInto(buf, if (open) hatO else hatC, at, if (step % 4 == 2) 0.32f else 0.22f)
            }
            if (s.bass[step] == 'x' && s.bassGain > 0f) {
                val root = ch[0] - 24
                val octave = if (step % 8 == 6) 12 else 0
                mixInto(buf, bassNote(mtof(root + octave), stepSec * 3, s.punchyBass), at, s.bassGain * 0.55f)
            }
            if (s.arp[step] != '.' && s.pluckGain > 0f) {
                val idx = (step / 1) % ch.size
                val note = ch[idx] + 12
                mixInto(buf, pluckNote(mtof(note), stepSec * 4, 1.0), at, s.pluckGain * 0.4f)
            }
            if (s.lead[step] == 'x' && s.leadGain > 0f) {
                val note = ch[rnd.nextInt(ch.size)] + 24
                mixInto(buf, leadNote(mtof(note), stepSec * 3), at, s.leadGain * 0.45f)
            }
        }
    }
    return finalize(buf, 0.88f, fadeOutSec = 0.8)
}

private fun finalize(buf: FloatArray, peakTarget: Float, fadeOutSec: Double): FloatArray {
    var peak = 0f
    for (v in buf) peak = max(peak, abs(v))
    val k = if (peak > 0f) peakTarget / peak else 1f
    val fadeIn = samples(0.01)
    val fadeOut = samples(fadeOutSec)
    for (i in buf.indices) {
        var v = buf[i] * k
        v = tanh(v * 1.1).toFloat()
        if (i < fadeIn) v *= i.toFloat() / fadeIn
        val fromEnd = buf.size - i
        if (fromEnd < fadeOut) v *= fromEnd.toFloat() / fadeOut
        buf[i] = v
    }
    return buf
}

// ---------------------------------------------------------------- efectos de sonido

private class Sfx(val id: String, val name: String, val category: String, val dur: Double, val premium: Boolean = false)

private val SFX_LIST: List<Sfx> = listOf(
    Sfx("whoosh", "Whoosh", "Transición", 0.9),
    Sfx("swish", "Swish rápido", "Transición", 0.45),
    Sfx("riser", "Subida tensión", "Transición", 3.0),
    Sfx("downer", "Caída", "Transición", 1.6),
    Sfx("scratch", "Scratch disco", "Transición", 0.7, true),
    Sfx("pop", "Pop", "Interfaz", 0.18),
    Sfx("click", "Click", "Interfaz", 0.08),
    Sfx("notif", "Notificación", "Interfaz", 0.8),
    Sfx("shutter", "Cámara", "Interfaz", 0.35),
    Sfx("typing", "Teclado", "Interfaz", 1.4),
    Sfx("ding", "Ding", "Alerta", 1.4),
    Sfx("bell", "Campana", "Alerta", 2.4),
    Sfx("success", "Éxito", "Alerta", 1.1),
    Sfx("error", "Error", "Alerta", 0.7),
    Sfx("alarm", "Alarma", "Alerta", 1.6, true),
    Sfx("coin", "Moneda", "Juego", 0.6),
    Sfx("laser", "Láser", "Juego", 0.6),
    Sfx("sparkle", "Destello mágico", "Juego", 1.4),
    Sfx("glitch", "Glitch", "Juego", 0.8, true),
    Sfx("boom", "Explosión", "Impacto", 2.0),
    Sfx("bassdrop", "Bass drop", "Impacto", 2.2, true),
    Sfx("heart", "Latidos", "Impacto", 2.4),
    Sfx("kick", "Bombo", "Percusión", 0.4),
    Sfx("snare", "Caja", "Percusión", 0.3),
    Sfx("clap", "Aplauso seco", "Percusión", 0.4),
    Sfx("applause", "Aplausos", "Ambiente", 3.5),
    Sfx("wind", "Viento", "Ambiente", 4.0),
    Sfx("waves", "Olas", "Ambiente", 5.0, true),
)

private fun sweepNoise(dur: Double, f0: Double, f1: Double, q: Double, peakAt: Double, rnd: Random): FloatArray {
    val n = samples(dur)
    val out = FloatArray(n)
    val bp = Biquad()
    for (i in 0 until n) {
        val p = i.toDouble() / n
        if (i % 64 == 0) {
            val f = f0 * (f1 / f0).pow(p)
            bp.bandpass(f, q)
        }
        val e = if (p < peakAt) p / peakAt else (1 - p) / (1 - peakAt)
        out[i] = (bp.process(rnd.nextDouble() * 2 - 1) * e * e * 2.2).toFloat()
    }
    return out
}

private fun tone(buf: FloatArray, freq: Double, startSec: Double, dur: Double, decay: Double, gain: Float, harm: Boolean = true) {
    val start = samples(startSec)
    val n = samples(dur)
    for (i in 0 until n) {
        val idx = start + i
        if (idx >= buf.size) break
        val t = i.toDouble() / SR
        val att = min(1.0, t / 0.004)
        var s = sin(2 * PI * freq * t)
        if (harm) s += 0.3 * sin(2 * PI * freq * 2 * t) + 0.1 * sin(2 * PI * freq * 3 * t)
        buf[idx] += (s * att * exp(-t * decay) * gain).toFloat()
    }
}

private fun renderSfx(def: Sfx): FloatArray {
    val rnd = Random(def.id.hashCode().toLong())
    val n = samples(def.dur)
    var b = FloatArray(n)
    when (def.id) {
        "whoosh" -> b = sweepNoise(def.dur, 250.0, 4200.0, 1.1, 0.45, rnd)
        "swish" -> b = sweepNoise(def.dur, 900.0, 6000.0, 1.5, 0.35, rnd)
        "riser" -> {
            val noise = sweepNoise(def.dur, 200.0, 7000.0, 0.9, 0.97, rnd)
            for (i in 0 until n) {
                val p = i.toDouble() / n
                val f = 180 * 8.0.pow(p)
                b[i] = noise[i] * 0.8f + (sin(2 * PI * f * i / SR) * p * p * 0.35).toFloat()
            }
        }
        "downer" -> {
            var ph = 0.0
            for (i in 0 until n) {
                val p = i.toDouble() / n
                val f = 900 * (40.0 / 900.0).pow(p)
                ph += 2 * PI * f / SR
                b[i] = (sin(ph) * (1 - p) * 0.8).toFloat()
            }
        }
        "scratch" -> {
            val bp = Biquad()
            for (i in 0 until n) {
                val p = i.toDouble() / n
                if (i % 48 == 0) bp.bandpass(900 + 1800 * abs(sin(p * 11)), 2.5)
                val e = sin(PI * p)
                b[i] = (bp.process(rnd.nextDouble() * 2 - 1) * e * 2.0).toFloat()
            }
        }
        "pop" -> {
            var ph = 0.0
            for (i in 0 until n) {
                val t = i.toDouble() / SR
                ph += 2 * PI * (180 + 600 * exp(-t * 55)) / SR
                b[i] = (sin(ph) * exp(-t * 28)).toFloat()
            }
        }
        "click" -> {
            val hp = Biquad()
            hp.highpass(2500.0, 0.8)
            for (i in 0 until samples(0.03)) {
                val t = i.toDouble() / SR
                b[i] = (hp.process(rnd.nextDouble() * 2 - 1) * exp(-t * 160)).toFloat()
            }
        }
        "notif" -> {
            tone(b, 880.0, 0.0, 0.4, 7.0, 0.5f)
            tone(b, 1318.5, 0.14, 0.6, 6.0, 0.5f)
        }
        "shutter" -> {
            val hp = Biquad()
            hp.highpass(1800.0, 0.8)
            for (k in 0..1) {
                val st = samples(0.02 + k * 0.11)
                for (i in 0 until samples(0.045)) {
                    val t = i.toDouble() / SR
                    if (st + i < n) b[st + i] += (hp.process(rnd.nextDouble() * 2 - 1) * exp(-t * 90)).toFloat()
                }
            }
        }
        "typing" -> {
            val hp = Biquad()
            hp.highpass(1500.0, 0.7)
            var t0 = 0.02
            while (t0 < def.dur - 0.1) {
                val st = samples(t0)
                for (i in 0 until samples(0.04)) {
                    val t = i.toDouble() / SR
                    if (st + i < n) b[st + i] += (hp.process(rnd.nextDouble() * 2 - 1) * exp(-t * 110) * 0.8).toFloat()
                }
                t0 += 0.07 + rnd.nextDouble() * 0.12
            }
        }
        "ding" -> {
            tone(b, 1318.5, 0.0, def.dur, 3.2, 0.6f, harm = false)
            tone(b, 2637.0, 0.0, def.dur, 5.5, 0.25f, harm = false)
        }
        "bell" -> {
            val partials = doubleArrayOf(1.0, 2.0, 2.76, 5.4, 8.93)
            val amps = floatArrayOf(0.6f, 0.4f, 0.3f, 0.2f, 0.1f)
            for (k in partials.indices) tone(b, 523.25 * partials[k], 0.0, def.dur, 1.6 + k * 0.9, amps[k], harm = false)
        }
        "success" -> {
            val notes = doubleArrayOf(523.25, 659.25, 783.99, 1046.5)
            for (k in notes.indices) tone(b, notes[k], k * 0.1, 0.7, 5.0, 0.4f)
        }
        "error" -> {
            for (k in 0..1) {
                val st = samples(k * 0.26)
                for (i in 0 until samples(0.22)) {
                    val t = i.toDouble() / SR
                    val saw = ((190.0 * t) % 1.0) * 2 - 1
                    val env = min(1.0, t / 0.01) * (if (t > 0.18) max(0.0, (0.22 - t) / 0.04) else 1.0)
                    if (st + i < n) b[st + i] += (saw * env * 0.55).toFloat()
                }
            }
        }
        "alarm" -> {
            for (i in 0 until n) {
                val t = i.toDouble() / SR
                val f = if (((t / 0.2).toInt() % 2) == 0) 880.0 else 660.0
                val sq = if (sin(2 * PI * f * t) >= 0) 1.0 else -1.0
                val env = min(1.0, t / 0.01) * (if (t > def.dur - 0.1) max(0.0, (def.dur - t) / 0.1) else 1.0)
                b[i] = (sq * env * 0.4).toFloat()
            }
        }
        "coin" -> {
            tone(b, 987.8, 0.0, 0.12, 9.0, 0.5f)
            tone(b, 1318.5, 0.09, 0.5, 6.0, 0.5f)
        }
        "laser" -> {
            var ph = 0.0
            for (i in 0 until n) {
                val t = i.toDouble() / SR
                ph += 2 * PI * (2400 * exp(-t * 7) + 150) / SR
                val saw = (ph / (2 * PI)) % 1.0 * 2 - 1
                b[i] = ((sin(ph) * 0.6 + saw * 0.3) * exp(-t * 4.5)).toFloat()
            }
        }
        "sparkle" -> {
            var t0 = 0.0
            while (t0 < def.dur - 0.3) {
                val f = 2000 + rnd.nextInt(3500).toDouble()
                tone(b, f, t0, 0.3, 14.0, 0.28f, harm = false)
                t0 += 0.03 + rnd.nextDouble() * 0.09
            }
        }
        "glitch" -> {
            var i = 0
            while (i < n) {
                val len = samples(0.01 + rnd.nextDouble() * 0.06)
                val mode = rnd.nextInt(3)
                val f = 150 + rnd.nextInt(2500).toDouble()
                for (k in 0 until len) {
                    if (i + k >= n) break
                    val v = when (mode) {
                        0 -> if (sin(2 * PI * f * k / SR) >= 0) 0.5 else -0.5
                        1 -> rnd.nextDouble() - 0.5
                        else -> 0.0
                    }
                    b[i + k] = v.toFloat() * (1f - i.toFloat() / n)
                }
                i += len
            }
        }
        "boom" -> {
            val lp = Biquad()
            for (i in 0 until n) {
                val t = i.toDouble() / SR
                if (i % 128 == 0) lp.lowpass(max(80.0, 3500 * exp(-t * 3.5)), 0.7)
                val thump = sin(2 * PI * (55 * exp(-t * 1.2) + 28) * t) * exp(-t * 2.2)
                b[i] = (lp.process(rnd.nextDouble() * 2 - 1) * 2.0 * exp(-t * 2.4) + thump).toFloat()
            }
        }
        "bassdrop" -> {
            var ph = 0.0
            for (i in 0 until n) {
                val t = i.toDouble() / SR
                ph += 2 * PI * (32 + 110 * exp(-t * 3.2)) / SR
                b[i] = (tanh(sin(ph) * 2.5) * exp(-t * 0.9)).toFloat()
            }
        }
        "heart" -> {
            for (k in 0..2) {
                val base = k * 0.8
                for (hit in 0..1) {
                    val st = base + hit * 0.22
                    if (st < def.dur) tone(b, 62.0, st, 0.25, 14.0, if (hit == 0) 0.9f else 0.65f, harm = false)
                }
            }
        }
        "kick" -> b = kickHit().copyOf(n)
        "snare" -> b = snareHit(rnd).copyOf(n)
        "clap" -> b = clapHit(rnd).copyOf(n)
        "applause" -> {
            val lp = Biquad()
            lp.lowpass(4500.0, 0.6)
            val hp = Biquad()
            hp.highpass(500.0, 0.6)
            var env = 0.0
            for (i in 0 until n) {
                val t = i.toDouble() / SR
                if (rnd.nextDouble() < 0.0035) env = 1.0
                env *= 0.9992
                val shape = min(1.0, t / 0.4) * (if (t > def.dur - 1.0) max(0.0, def.dur - t) else 1.0)
                val x = (rnd.nextDouble() * 2 - 1) * (0.25 + env)
                b[i] = (hp.process(lp.process(x)) * shape * 1.6).toFloat()
            }
        }
        "wind" -> {
            val bp = Biquad()
            for (i in 0 until n) {
                val t = i.toDouble() / SR
                if (i % 256 == 0) bp.bandpass(380 + 260 * sin(2 * PI * 0.35 * t) + 120 * sin(2 * PI * 0.9 * t), 1.4)
                val amp = 0.6 + 0.4 * sin(2 * PI * 0.28 * t + 1)
                val edge = min(1.0, t / 0.5) * min(1.0, (def.dur - t) / 0.5)
                b[i] = (bp.process(rnd.nextDouble() * 2 - 1) * amp * edge * 2.4).toFloat()
            }
        }
        "waves" -> {
            val lp = Biquad()
            for (i in 0 until n) {
                val t = i.toDouble() / SR
                val swell = 0.5 + 0.5 * sin(2 * PI * t / 5.0 - 1.2)
                if (i % 256 == 0) lp.lowpass(400 + 2200 * swell * swell, 0.7)
                val edge = min(1.0, t / 0.6) * min(1.0, (def.dur - t) / 0.6)
                b[i] = (lp.process(rnd.nextDouble() * 2 - 1) * (0.25 + swell) * edge * 2.0).toFloat()
            }
        }
    }
    return finalize(b, 0.85f, fadeOutSec = 0.03)
}

// ---------------------------------------------------------------- API pública

object SoundLab {

    val sfx: List<SoundDef> = SFX_LIST.map {
        SoundDef(it.id, it.name, it.category, false, (it.dur * 1000).toLong(), it.premium)
    }

    val music: List<SoundDef> = STYLES.map {
        SoundDef(it.id, it.name, "Música", true, styleDurationMs(it), it.premium)
    }

    val all: List<SoundDef> = sfx + music

    fun find(id: String): SoundDef? = all.firstOrNull { it.id == id }

    /** Devuelve el archivo WAV del sonido, sintetizándolo si todavía no existe. */
    fun fileFor(dir: File, def: SoundDef): File {
        if (!dir.exists()) dir.mkdirs()
        val f = File(dir, "${def.id}.wav")
        if (f.exists() && f.length() > 1000) return f
        val data = if (def.isMusic) {
            renderStyle(STYLES.first { it.id == def.id })
        } else {
            renderSfx(SFX_LIST.first { it.id == def.id })
        }
        val tmp = File(dir, "${def.id}.tmp")
        tmp.writeBytes(toWav(data))
        tmp.renameTo(f)
        return f
    }

    fun toWav(data: FloatArray): ByteArray {
        val dataLen = data.size * 2
        val out = ByteArrayOutputStream(44 + dataLen)
        fun i32(v: Int) {
            out.write(v and 255); out.write((v shr 8) and 255)
            out.write((v shr 16) and 255); out.write((v shr 24) and 255)
        }
        fun i16(v: Int) {
            out.write(v and 255); out.write((v shr 8) and 255)
        }
        out.write("RIFF".toByteArray())
        i32(36 + dataLen)
        out.write("WAVE".toByteArray())
        out.write("fmt ".toByteArray())
        i32(16)
        i16(1)
        i16(1)
        i32(SR)
        i32(SR * 2)
        i16(2)
        i16(16)
        out.write("data".toByteArray())
        i32(dataLen)
        for (v in data) {
            val s = (v * 32767f).toInt().coerceIn(-32768, 32767)
            i16(s)
        }
        return out.toByteArray()
    }
}
