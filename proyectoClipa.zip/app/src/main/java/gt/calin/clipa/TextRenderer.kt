package gt.calin.clipa

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface

/**
 * Dibuja textos y pegatinas. Se usa tanto en la vista previa como al exportar,
 * así lo que ves es exactamente lo que se exporta.
 */
object TextRenderer {

    private val faces = HashMap<TextFont, Typeface>()

    fun face(f: TextFont): Typeface = faces.getOrPut(f) { Typeface.create(f.family, Typeface.BOLD) }

    private class Lay(
        val lines: List<String>,
        val size: Float,
        val lineH: Float,
        val rect: RectF,
        val firstBaseline: Float,
        val cx: Float,
    )

    private fun makePaint(t: TextItem, frameH: Float): Paint {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.textSize = (t.sizeFrac * frameH).coerceAtLeast(4f)
        p.textAlign = Paint.Align.CENTER
        p.typeface = if (t.sticker) Typeface.DEFAULT else face(t.font)
        return p
    }

    private fun layout(t: TextItem, frameW: Float, frameH: Float, p: Paint): Lay {
        val lines = t.text.split("\n")
        val size = p.textSize
        val fm = p.fontMetrics
        val lineH = (fm.descent - fm.ascent) * (if (t.sticker) 1.0f else 1.08f)
        var maxW = 0f
        for (l in lines) maxW = maxOf(maxW, p.measureText(l))
        val padX = if (t.style == TextStyleKind.BOX && !t.sticker) size * 0.35f else size * 0.12f
        val padY = if (t.style == TextStyleKind.BOX && !t.sticker) size * 0.18f else size * 0.06f
        val totalH = lineH * lines.size
        val cx = t.x * frameW
        val cy = t.y * frameH
        val rect = RectF(
            cx - maxW / 2f - padX,
            cy - totalH / 2f - padY,
            cx + maxW / 2f + padX,
            cy + totalH / 2f + padY,
        )
        val first = cy - totalH / 2f - fm.ascent
        return Lay(lines, size, lineH, rect, first, cx)
    }

    /** Rectángulo (en píxeles del cuadro) que ocupa el elemento. */
    fun bounds(t: TextItem, frameW: Float, frameH: Float): RectF {
        val p = makePaint(t, frameH)
        return layout(t, frameW, frameH, p).rect
    }

    private fun lerpWhite(color: Int, k: Float): Int {
        val a = (color ushr 24) and 255
        var r = (color shr 16) and 255
        var g = (color shr 8) and 255
        var b = color and 255
        r = (r + (255 - r) * k).toInt()
        g = (g + (255 - g) * k).toInt()
        b = (b + (255 - b) * k).toInt()
        return (a shl 24) or (r shl 16) or (g shl 8) or b
    }

    private fun isDark(color: Int): Boolean {
        val r = (color shr 16) and 255
        val g = (color shr 8) and 255
        val b = color and 255
        return (0.299f * r + 0.587f * g + 0.114f * b) < 90f
    }

    /** Dibuja el elemento centrado en (x, y) y devuelve su rectángulo. */
    fun draw(canvas: Canvas, t: TextItem, frameW: Float, frameH: Float): RectF {
        val p = makePaint(t, frameH)
        val lay = layout(t, frameW, frameH, p)
        val size = lay.size

        if (t.sticker) {
            p.style = Paint.Style.FILL
            p.color = 0xFFFFFFFF.toInt()
            for ((i, line) in lay.lines.withIndex()) {
                canvas.drawText(line, lay.cx, lay.firstBaseline + i * lay.lineH, p)
            }
            return lay.rect
        }

        when (t.style) {
            TextStyleKind.CLASSIC -> {
                p.style = Paint.Style.FILL
                p.color = t.color
                p.setShadowLayer(size * 0.10f, 0f, size * 0.04f, 0xCC000000.toInt())
                drawLines(canvas, lay, p, 0f, 0f)
            }
            TextStyleKind.OUTLINE -> {
                p.style = Paint.Style.STROKE
                p.strokeWidth = size * 0.16f
                p.strokeJoin = Paint.Join.ROUND
                p.color = if (isDark(t.color)) 0xFFFFFFFF.toInt() else 0xFF000000.toInt()
                drawLines(canvas, lay, p, 0f, 0f)
                p.style = Paint.Style.FILL
                p.color = t.color
                drawLines(canvas, lay, p, 0f, 0f)
            }
            TextStyleKind.BOX -> {
                val bg = if (isDark(t.color)) 0xE6FFFFFF.toInt() else 0xB3000000.toInt()
                val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
                bgPaint.color = bg
                canvas.drawRoundRect(lay.rect, size * 0.28f, size * 0.28f, bgPaint)
                p.style = Paint.Style.FILL
                p.color = t.color
                drawLines(canvas, lay, p, 0f, 0f)
            }
            TextStyleKind.NEON -> {
                p.style = Paint.Style.FILL
                p.color = t.color
                p.setShadowLayer(size * 0.55f, 0f, 0f, t.color)
                drawLines(canvas, lay, p, 0f, 0f)
                p.setShadowLayer(size * 0.22f, 0f, 0f, t.color)
                drawLines(canvas, lay, p, 0f, 0f)
                p.clearShadowLayer()
                p.color = lerpWhite(t.color, 0.7f)
                drawLines(canvas, lay, p, 0f, 0f)
            }
            TextStyleKind.RETRO -> {
                p.style = Paint.Style.FILL
                p.color = 0xFFFF3D8B.toInt()
                val d = size * 0.07f
                drawLines(canvas, lay, p, d, d)
                p.color = 0xFF2B1B5A.toInt()
                drawLines(canvas, lay, p, d * 0.45f, d * 0.45f)
                p.color = t.color
                drawLines(canvas, lay, p, 0f, 0f)
            }
        }
        return lay.rect
    }

    private fun drawLines(canvas: Canvas, lay: Lay, p: Paint, dx: Float, dy: Float) {
        for ((i, line) in lay.lines.withIndex()) {
            canvas.drawText(line, lay.cx + dx, lay.firstBaseline + i * lay.lineH + dy, p)
        }
    }
}
