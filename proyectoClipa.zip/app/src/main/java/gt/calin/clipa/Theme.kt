package gt.calin.clipa

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/** Paleta de Clipa: negro profundo con acento menta y violeta. */
object Pal {
    val Bg = Color(0xFF07070B)
    val Surface = Color(0xFF111117)
    val Surface2 = Color(0xFF1A1A23)
    val Surface3 = Color(0xFF252531)
    val Line = Color(0xFF2F2F3E)
    val Text = Color(0xFFF4F4FA)
    val Muted = Color(0xFF8D8DA3)
    val Accent = Color(0xFF19E3C1)
    val Accent2 = Color(0xFF7C5CFF)
    val Danger = Color(0xFFFF4D6D)
    val Gold = Color(0xFFFFC857)
    val Gold2 = Color(0xFFFF8A3D)
    val Pink = Color(0xFFFF4FA3)

    val Brand = Brush.horizontalGradient(listOf(Accent, Accent2))
    val BrandDiagonal = Brush.linearGradient(listOf(Accent, Accent2))
    val GoldBrush = Brush.horizontalGradient(listOf(Gold, Gold2))
}

@Composable
fun ClipaTheme(content: @Composable () -> Unit) {
    @Suppress("UNUSED_VARIABLE")
    val dark = isSystemInDarkTheme()
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Pal.Accent,
            onPrimary = Color.Black,
            secondary = Pal.Accent2,
            background = Pal.Bg,
            onBackground = Pal.Text,
            surface = Pal.Surface,
            onSurface = Pal.Text,
            surfaceVariant = Pal.Surface2,
            onSurfaceVariant = Pal.Muted,
            error = Pal.Danger,
        ),
        content = content,
    )
}
