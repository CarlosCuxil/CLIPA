package gt.calin.clipa

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlin.math.roundToInt

/** Miniaturas repartidas a lo largo de un video, para dibujar la línea de tiempo. */
class ThumbSet(val intervalMs: Long, val bitmaps: List<Bitmap>) {
    val images: List<ImageBitmap> = bitmaps.map { it.asImageBitmap() }

    fun indexAt(sourceMs: Long): Int {
        if (bitmaps.isEmpty()) return 0
        return (sourceMs / intervalMs).toInt().coerceIn(0, bitmaps.size - 1)
    }
}

object Thumbs {

    private const val HEIGHT = 96

    /** Debe llamarse en un hilo de fondo. */
    fun load(ctx: Context, uri: Uri, durationMs: Long): ThumbSet? {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, uri)
            val vw = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 16
            val vh = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 9
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            val swap = rot == 90 || rot == 270
            val dispW = if (swap) vh else vw
            val dispH = if (swap) vw else vh
            val aspect = dispW.toFloat() / dispH.coerceAtLeast(1)
            val tw = (HEIGHT * aspect).roundToInt().coerceIn(54, 180)

            val n = (durationMs / 1500L).toInt().coerceIn(4, 40)
            val interval = (durationMs / n).coerceAtLeast(1L)
            val list = ArrayList<Bitmap>()
            var last: Bitmap? = null
            for (i in 0 until n) {
                val tUs = (i * interval + interval / 2) * 1000L
                val bmp = try {
                    r.getScaledFrameAtTime(tUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, tw, HEIGHT)
                } catch (e: Exception) {
                    null
                }
                val use = bmp ?: last
                if (use != null) {
                    list.add(use)
                    last = use
                }
            }
            if (list.isEmpty()) return null
            return ThumbSet(interval, list)
        } catch (e: Exception) {
            return null
        } finally {
            r.release()
        }
    }
}
