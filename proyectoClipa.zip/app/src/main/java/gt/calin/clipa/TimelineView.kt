package gt.calin.clipa

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

private class TlMetrics(val d: Float) {
    val ruler = 24f * d
    val video = 58f * d
    val lane = 26f * d
    val gap = 4f * d
    val pad = 8f * d
    val handle = 14f * d
    val laneHandle = 12f * d
    val addW = 46f * d
    val touchPad = 8f * d
}

private class Rows(
    val textLane: Map<Long, Int>,
    val textLanes: Int,
    val audioLane: Map<Long, Int>,
    val audioLanes: Int,
)

private fun computeRows(p: Project): Rows {
    val tl = HashMap<Long, Int>()
    val ends = ArrayList<Long>()
    for (t in p.texts.sortedBy { it.startMs }) {
        var lane = ends.indexOfFirst { it <= t.startMs }
        if (lane < 0) {
            ends.add(t.endMs)
            lane = ends.lastIndex
        } else {
            ends[lane] = t.endMs
        }
        tl[t.id] = lane
    }
    val textLanes = ends.size

    val al = HashMap<Long, Int>()
    val aEnds = ArrayList<Long>()
    for (a in p.audios.sortedBy { it.startMs }) {
        var lane = aEnds.indexOfFirst { it <= a.startMs }
        if (lane < 0) {
            aEnds.add(a.endMs)
            lane = aEnds.lastIndex
        } else {
            aEnds[lane] = a.endMs
        }
        al[a.id] = lane
    }
    return Rows(tl, textLanes, al, aEnds.size)
}

private fun yVideo(m: TlMetrics) = m.ruler + m.pad
private fun yText(m: TlMetrics) = yVideo(m) + m.video + m.pad
private fun yAudio(m: TlMetrics, rows: Rows) =
    yText(m) + rows.textLanes * (m.lane + m.gap) + (if (rows.textLanes > 0) m.pad / 2f else 0f)

private fun contentHeight(m: TlMetrics, rows: Rows) =
    yAudio(m, rows) + rows.audioLanes * (m.lane + m.gap) + m.pad * 2

private sealed interface Hit
private data object HitNone : Hit
private data object HitAdd : Hit
private data class HitClip(val id: Long, val region: Int) : Hit
private data class HitText(val id: Long, val region: Int) : Hit
private data class HitAudio(val id: Long, val region: Int) : Hit

private const val MIN_PPS = 12f
private const val MAX_PPS = 420f

private fun hitTest(
    vm: EditorViewModel,
    m: TlMetrics,
    pps: Float,
    scrollY: Float,
    rows: Rows,
    w: Float,
    p: Offset,
): Hit {
    val ppm = pps / 1000f
    val cx = w / 2f
    val pos = vm.positionMs
    fun xOf(t: Long) = cx + (t - pos) * ppm

    val yv = yVideo(m) - scrollY
    if (p.y >= yv && p.y <= yv + m.video) {
        var off = 0L
        for (c in vm.clips) {
            val x0 = xOf(off)
            val x1 = xOf(off + c.lengthMs)
            if (p.x >= x0 && p.x <= x1) {
                val sel = (vm.selection as? SelClip)?.id == c.id
                if (sel && (x1 - x0) > m.handle * 3) {
                    if (p.x <= x0 + m.handle + m.touchPad) return HitClip(c.id, 1)
                    if (p.x >= x1 - m.handle - m.touchPad) return HitClip(c.id, 2)
                }
                return HitClip(c.id, 0)
            }
            // asa derecha de un clip seleccionado, un poco fuera del borde
            if ((vm.selection as? SelClip)?.id == c.id && p.x > x1 && p.x <= x1 + m.touchPad) {
                return HitClip(c.id, 2)
            }
            off += c.lengthMs
        }
        val ax = xOf(off) + m.pad
        if (p.x >= ax && p.x <= ax + m.addW) return HitAdd
        return HitNone
    }

    val yt = yText(m) - scrollY
    for (t in vm.texts) {
        val lane = rows.textLane[t.id] ?: continue
        val top = yt + lane * (m.lane + m.gap)
        if (p.y < top || p.y > top + m.lane) continue
        val x0 = xOf(t.startMs)
        val x1 = xOf(t.endMs)
        if (p.x < x0 - m.touchPad || p.x > x1 + m.touchPad) continue
        val sel = (vm.selection as? SelText)?.id == t.id
        if (sel && (x1 - x0) > m.laneHandle * 3) {
            if (p.x <= x0 + m.laneHandle + m.touchPad) return HitText(t.id, 1)
            if (p.x >= x1 - m.laneHandle - m.touchPad) return HitText(t.id, 2)
        }
        return HitText(t.id, 0)
    }

    val ya = yAudio(m, rows) - scrollY
    for (a in vm.audios) {
        val lane = rows.audioLane[a.id] ?: continue
        val top = ya + lane * (m.lane + m.gap)
        if (p.y < top || p.y > top + m.lane) continue
        val x0 = xOf(a.startMs)
        val x1 = xOf(a.endMs)
        if (p.x < x0 - m.touchPad || p.x > x1 + m.touchPad) continue
        val sel = (vm.selection as? SelAudio)?.id == a.id
        if (sel && (x1 - x0) > m.laneHandle * 3) {
            if (p.x <= x0 + m.laneHandle + m.touchPad) return HitAudio(a.id, 1)
            if (p.x >= x1 - m.laneHandle - m.touchPad) return HitAudio(a.id, 2)
        }
        return HitAudio(a.id, 0)
    }
    return HitNone
}

private fun audioColor(k: AudioKind): Color = when (k) {
    AudioKind.MUSIC -> Color(0xFF1FA98F)
    AudioKind.SFX -> Color(0xFFE8892B)
    AudioKind.IMPORTED -> Color(0xFF3F7BE8)
}

@Composable
fun TimelineView(
    vm: EditorViewModel,
    onAddClip: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val density = LocalDensity.current.density
    val m = remember(density) { TlMetrics(density) }
    var pxPerSec by remember { mutableFloatStateOf(70f * density) }
    var scrollY by remember { mutableFloatStateOf(0f) }
    val measurer = rememberTextMeasurer()

    Canvas(
        modifier
            .fillMaxWidth()
            .height(158.dp)
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val w = size.width.toFloat()
                    val viewH = size.height.toFloat()
                    val rows = computeRows(vm.project)
                    val hit = hitTest(vm, m, pxPerSec, scrollY, rows, w, down.position)
                    val slop = viewConfiguration.touchSlop

                    // 0 sin decidir, 1 mover tiempo, 2 desplazar vertical, 3 editar objeto, 4 zoom
                    var mode = 0
                    var tdx = 0f
                    var tdy = 0f
                    var accMs = 0f
                    var scrubbing = false

                    while (true) {
                        val event = awaitPointerEvent()
                        val pressed = event.changes.count { it.pressed }
                        if (pressed == 0) break

                        if (pressed >= 2) {
                            val z = event.calculateZoom()
                            if (z != 1f) pxPerSec = (pxPerSec * z).coerceIn(MIN_PPS * density, MAX_PPS * density)
                            mode = 4
                            event.changes.forEach { it.consume() }
                            continue
                        }
                        if (mode == 4) {
                            event.changes.forEach { it.consume() }
                            continue
                        }

                        val ch = event.changes.first { it.pressed }
                        val d = ch.positionChange()
                        tdx += d.x
                        tdy += d.y
                        var dx = d.x
                        var dy = d.y

                        if (mode == 0 && hypot(tdx, tdy) > slop) {
                            val horizontal = abs(tdx) >= abs(tdy)
                            mode = when (hit) {
                                is HitClip -> if (hit.region != 0) 3 else if (horizontal) 1 else 2
                                is HitText -> if (horizontal) 3 else 2
                                is HitAudio -> if (horizontal) 3 else 2
                                else -> if (horizontal) 1 else 2
                            }
                            dx = tdx
                            dy = tdy
                            when (mode) {
                                1 -> {
                                    vm.beginScrub()
                                    scrubbing = true
                                }
                                3 -> {
                                    vm.pause()
                                    when (hit) {
                                        is HitClip -> vm.select(SelClip(hit.id))
                                        is HitText -> vm.select(SelText(hit.id))
                                        is HitAudio -> vm.select(SelAudio(hit.id))
                                        else -> {}
                                    }
                                }
                            }
                        }

                        if (mode == 0) continue
                        ch.consume()
                        val ppm = pxPerSec / 1000f

                        when (mode) {
                            1 -> {
                                accMs += -dx / ppm
                                val whole = accMs.toLong()
                                if (whole != 0L) {
                                    accMs -= whole
                                    vm.scrubTo((vm.positionMs + whole).coerceIn(0L, vm.totalMs))
                                }
                            }
                            2 -> {
                                val maxScroll = max(0f, contentHeight(m, rows) - viewH)
                                scrollY = (scrollY - dy).coerceIn(0f, maxScroll)
                            }
                            3 -> {
                                accMs += dx / ppm
                                val whole = accMs.toLong()
                                if (whole != 0L) {
                                    accMs -= whole
                                    when (hit) {
                                        is HitClip -> {
                                            val c = vm.clips.firstOrNull { it.id == hit.id }
                                            if (c != null) {
                                                if (hit.region == 1) vm.setTrim(c.id, c.startMs + whole, c.endMs)
                                                else vm.setTrim(c.id, c.startMs, c.endMs + whole)
                                            }
                                        }
                                        is HitText -> {
                                            val t = vm.texts.firstOrNull { it.id == hit.id }
                                            if (t != null) {
                                                when (hit.region) {
                                                    1 -> vm.setTextTime(t.id, t.startMs + whole, t.endMs)
                                                    2 -> vm.setTextTime(t.id, t.startMs, t.endMs + whole)
                                                    else -> {
                                                        val dur = t.endMs - t.startMs
                                                        val ns = (t.startMs + whole).coerceIn(0L, (vm.totalMs - dur).coerceAtLeast(0L))
                                                        vm.setTextTime(t.id, ns, ns + dur)
                                                    }
                                                }
                                            }
                                        }
                                        is HitAudio -> {
                                            val a = vm.audios.firstOrNull { it.id == hit.id }
                                            if (a != null) {
                                                when (hit.region) {
                                                    1 -> vm.trimAudio(a.id, whole, 0L)
                                                    2 -> vm.trimAudio(a.id, 0L, whole)
                                                    else -> vm.moveAudio(a.id, a.startMs + whole)
                                                }
                                            }
                                        }
                                        else -> {}
                                    }
                                }
                            }
                        }
                    }

                    if (scrubbing) vm.endScrub()

                    if (mode == 0) {
                        // toque simple
                        val ppm = pxPerSec / 1000f
                        when (hit) {
                            is HitClip -> vm.select(SelClip(hit.id))
                            is HitText -> vm.select(SelText(hit.id))
                            is HitAudio -> vm.select(SelAudio(hit.id))
                            HitAdd -> onAddClip()
                            HitNone -> {
                                if (down.position.y < m.ruler) {
                                    val t = vm.positionMs + ((down.position.x - w / 2f) / ppm).toLong()
                                    vm.pause()
                                    vm.seekTo(t.coerceIn(0L, vm.totalMs))
                                } else {
                                    vm.select(null)
                                }
                            }
                        }
                    }
                }
            }
    ) {
        val rows = computeRows(vm.project)
        drawTimeline(vm, m, pxPerSec, scrollY, rows, measurer)
    }
}

private fun DrawScope.drawTimeline(
    vm: EditorViewModel,
    m: TlMetrics,
    pps: Float,
    scrollY: Float,
    rows: Rows,
    measurer: TextMeasurer,
) {
    val w = size.width
    val h = size.height
    val d = m.d
    val ppm = pps / 1000f
    val cx = w / 2f
    val pos = vm.positionMs
    val total = vm.totalMs
    fun xOf(t: Long) = cx + (t - pos) * ppm

    val labelStyle = TextStyle(color = Pal.Muted, fontSize = 10.sp)
    val blockStyle = TextStyle(color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)

    // Zona fuera del proyecto, más oscura
    val xEnd = xOf(total)
    if (xEnd < w) {
        drawRect(Color(0x33000000), Offset(max(0f, xEnd), 0f), Size(w - max(0f, xEnd), h))
    }

    // Regla de tiempo
    val steps = longArrayOf(500, 1000, 2000, 5000, 10000, 15000, 30000, 60000, 120000, 300000, 600000)
    var step = steps.last()
    for (s in steps) {
        if (s * ppm >= 64f * d) {
            step = s
            break
        }
    }
    val tMin = max(0L, pos - (cx / ppm).toLong() - step)
    val tMax = pos + (cx / ppm).toLong() + step
    var t = (tMin / step) * step
    while (t <= tMax) {
        val x = xOf(t)
        drawLine(Pal.Line, Offset(x, m.ruler - 7f * d), Offset(x, m.ruler - 1f * d), strokeWidth = 1.2f * d)
        drawText(
            textMeasurer = measurer,
            text = formatTime(t),
            topLeft = Offset(x + 3f * d, 2f * d),
            style = labelStyle,
        )
        // marcas pequeñas
        for (k in 1..3) {
            val xm = xOf(t + step * k / 4)
            drawLine(Pal.Line, Offset(xm, m.ruler - 3.5f * d), Offset(xm, m.ruler - 1f * d), strokeWidth = 1f * d)
        }
        t += step
    }

    // ---- Pista de video ----
    val yv = yVideo(m) - scrollY
    var off = 0L
    val selClipId = (vm.selection as? SelClip)?.id
    for (c in vm.clips) {
        val x0 = xOf(off)
        val x1 = xOf(off + c.lengthMs)
        off += c.lengthMs
        if (x1 < -20f || x0 > w + 20f) continue
        val inset = 1.5f * d
        val left = x0 + inset
        val right = x1 - inset
        if (right <= left) continue
        val rr = RoundRect(left, yv, right, yv + m.video, CornerRadius(8f * d, 8f * d))
        val path = Path().apply { addRoundRect(rr) }
        drawPath(path, Pal.Surface3)
        clipPath(path) {
            val set = vm.thumbs[c.uri]
            if (set != null && set.images.isNotEmpty()) {
                val img0 = set.images[0]
                val tileH = m.video
                val tileW = max(8f, tileH * img0.width / img0.height)
                val firstVisible = max(left, 0f)
                val lastVisible = min(right, w)
                var k = max(0, floor((firstVisible - x0) / tileW).toInt())
                while (x0 + k * tileW < lastVisible) {
                    val tx = x0 + k * tileW
                    val inClipMs = (((k + 0.5f) * tileW) / ppm).toLong().coerceIn(0L, c.lengthMs)
                    val img = set.images[set.indexAt(c.startMs + inClipMs)]
                    drawImage(
                        image = img,
                        srcOffset = IntOffset.Zero,
                        srcSize = IntSize(img.width, img.height),
                        dstOffset = IntOffset(tx.roundToInt(), yv.roundToInt()),
                        dstSize = IntSize(tileW.roundToInt() + 1, tileH.roundToInt()),
                    )
                    k++
                }
            }
            drawRect(Color(0x33000000), Offset(left, yv), Size(right - left, m.video))
            // etiqueta de duración
            if (right - left > 46f * d) {
                drawText(
                    textMeasurer = measurer,
                    text = "%.1fs".format(c.lengthMs / 1000f),
                    topLeft = Offset(left + 6f * d, yv + m.video - 16f * d),
                    style = blockStyle,
                    overflow = TextOverflow.Clip,
                    maxLines = 1,
                )
            }
            if (c.look.hasColor || c.look.fx != Fx.NONE) {
                drawCircle(Pal.Accent, 4f * d, Offset(right - 9f * d, yv + 9f * d))
            }
        }
        if (c.id == selClipId) {
            drawPath(path, Color.White, style = Stroke(width = 2f * d))
            if (right - left > m.handle * 3) {
                val hw = m.handle
                drawRoundRect(Color.White, Offset(left, yv), Size(hw, m.video), CornerRadius(6f * d, 6f * d))
                drawRoundRect(Color.White, Offset(right - hw, yv), Size(hw, m.video), CornerRadius(6f * d, 6f * d))
                val gy0 = yv + m.video * 0.3f
                val gy1 = yv + m.video * 0.7f
                drawLine(Color(0xFF333344), Offset(left + hw / 2f, gy0), Offset(left + hw / 2f, gy1), strokeWidth = 2f * d)
                drawLine(Color(0xFF333344), Offset(right - hw / 2f, gy0), Offset(right - hw / 2f, gy1), strokeWidth = 2f * d)
            }
        }
    }

    // Botón de agregar clip
    run {
        val ax = xOf(total) + m.pad
        if (ax < w) {
            drawRoundRect(Pal.Surface3, Offset(ax, yv), Size(m.addW, m.video), CornerRadius(8f * d, 8f * d))
            translate(ax + (m.addW - 22f * d) / 2f, yv + (m.video - 22f * d) / 2f) {
                drawGlyph(Ic.Plus, Color.White, 22f * d)
            }
        }
    }

    // ---- Textos y pegatinas ----
    val yt = yText(m) - scrollY
    val selTextId = (vm.selection as? SelText)?.id
    for (tx in vm.texts) {
        val lane = rows.textLane[tx.id] ?: continue
        val x0 = xOf(tx.startMs)
        val x1 = xOf(tx.endMs)
        if (x1 < -10f || x0 > w + 10f) continue
        val top = yt + lane * (m.lane + m.gap)
        val color = if (tx.sticker) Color(0xFFD9962A) else Color(0xFF7C5CFF)
        drawRoundRect(color, Offset(x0, top), Size(max(4f, x1 - x0), m.lane), CornerRadius(7f * d, 7f * d))
        clipPath(Path().apply { addRect(androidx.compose.ui.geometry.Rect(x0, top, x1, top + m.lane)) }) {
            drawText(
                textMeasurer = measurer,
                text = tx.text.replace("\n", " "),
                topLeft = Offset(x0 + 8f * d, top + 5f * d),
                style = blockStyle,
                overflow = TextOverflow.Clip,
                maxLines = 1,
            )
        }
        if (tx.id == selTextId) {
            drawRoundRect(Color.White, Offset(x0, top), Size(max(4f, x1 - x0), m.lane), CornerRadius(7f * d, 7f * d), style = Stroke(2f * d))
            if (x1 - x0 > m.laneHandle * 3) {
                drawRoundRect(Color.White, Offset(x0, top), Size(m.laneHandle * 0.7f, m.lane), CornerRadius(5f * d, 5f * d))
                drawRoundRect(Color.White, Offset(x1 - m.laneHandle * 0.7f, top), Size(m.laneHandle * 0.7f, m.lane), CornerRadius(5f * d, 5f * d))
            }
        }
    }

    // ---- Audio ----
    val ya = yAudio(m, rows) - scrollY
    val selAudioId = (vm.selection as? SelAudio)?.id
    for (a in vm.audios) {
        val lane = rows.audioLane[a.id] ?: continue
        val x0 = xOf(a.startMs)
        val x1 = xOf(a.endMs)
        if (x1 < -10f || x0 > w + 10f) continue
        val top = ya + lane * (m.lane + m.gap)
        val color = audioColor(a.kind)
        val bw = max(4f, x1 - x0)
        drawRoundRect(color, Offset(x0, top), Size(bw, m.lane), CornerRadius(7f * d, 7f * d))
        clipPath(Path().apply { addRect(androidx.compose.ui.geometry.Rect(x0, top, x1, top + m.lane)) }) {
            // ondas decorativas
            val barStep = 4f * d
            var bx = max(x0 + 2f * d, floor(max(0f, x0) / barStep) * barStep)
            var idx = ((bx - x0) / barStep).toInt()
            val seed = (a.id % 97).toFloat()
            val cyMid = top + m.lane / 2f
            while (bx < min(x1, w)) {
                val hh = (0.25f + 0.75f * abs(sin(idx * 0.9f + seed) * cos(idx * 0.37f + seed * 0.7f))) * m.lane * 0.62f
                drawLine(Color(0x55FFFFFF), Offset(bx, cyMid - hh / 2f), Offset(bx, cyMid + hh / 2f), strokeWidth = 2f * d)
                bx += barStep
                idx++
            }
            drawText(
                textMeasurer = measurer,
                text = a.name,
                topLeft = Offset(max(x0, 0f) + 8f * d, top + 5f * d),
                style = blockStyle,
                overflow = TextOverflow.Clip,
                maxLines = 1,
            )
        }
        if (a.id == selAudioId) {
            drawRoundRect(Color.White, Offset(x0, top), Size(bw, m.lane), CornerRadius(7f * d, 7f * d), style = Stroke(2f * d))
            if (x1 - x0 > m.laneHandle * 3) {
                drawRoundRect(Color.White, Offset(x0, top), Size(m.laneHandle * 0.7f, m.lane), CornerRadius(5f * d, 5f * d))
                drawRoundRect(Color.White, Offset(x1 - m.laneHandle * 0.7f, top), Size(m.laneHandle * 0.7f, m.lane), CornerRadius(5f * d, 5f * d))
            }
        }
    }

    // ---- Cabezal ----
    drawLine(Color.White, Offset(cx, 0f), Offset(cx, h), strokeWidth = 2f * d)
    drawCircle(Color.White, 4.5f * d, Offset(cx, 4f * d))
}
